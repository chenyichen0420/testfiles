#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
struct edge {
	int l, r, v;
	edge(int li = 0, int ri = 0, int vi = 0) :l(li), r(ri), v(vi) {};
	inline bool operator<(const edge& r) {
		return v > r.v;
	}
}; vector<edge>e;
struct node {
	int p, v;
	node(int pi = 0, int vi = 0) :p(pi), v(vi) {};
}; vector<node>son[100005];
int n, m, k, f[10005][15], v[10005][15], d[10005]; bool nat[10005];
struct mss {
	int f[10005];
	inline void set() {
		for (int i = 1; i <= n; ++i) f[i] = i;
	}
	inline int find(int p) {
		return f[p] != p ? f[p] = find(f[p]) : p;
	}
	inline bool merge(int l, int r) {
		l = find(l); r = find(r);
		if (l == r) return 0;
		return f[l] = r, 1;
	}
}ms;
inline void tmin(int& l, const int r) { (l > r) && (l = r); }
inline void dfs(int p, int fa, int fv) {
	f[p][0] = fa; v[p][0] = fv; d[p] = d[fa] + 1; nat[p] = 1;
	for (int i = 1; i <= 14; ++i)
		f[p][i] = f[f[p][i - 1]][i - 1],
		v[p][i] = min(v[p][i - 1], v[f[p][i - 1]][i - 1]);
	for (const node& sp : son[p])
		if (sp.p != fa) dfs(sp.p, p, sp.v);
}
inline int lcv(int l, int r) {
	if (ms.find(l) != ms.find(r)) return -1;
	if (d[l] < d[r]) swap(l, r); int ret = 1e9;
	for (int i = 14; i >= 0; i--)
		if (d[f[l][i]] >= d[r])
			tmin(ret, v[l][i]), l = f[l][i];
	if (l == r) return ret;
	for (int i = 14; i >= 0; i--)
		if (f[l][i] != f[r][i])
			tmin(ret, min(v[l][i], v[r][i])),
			l = f[l][i], r = f[r][i];
	return min({ ret,v[l][0],v[r][0] });
}
signed main() {
	if (online)
		freopen("truck.in", "r", stdin),
		freopen("truck.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1, l, r, v; i <= m; ++i)
		cin >> l >> r >> v, e.emplace_back(l, r, v);
	sort(e.begin(), e.end()); ms.set();
	memset(v, 0x3f, sizeof v); cin >> k;
	for (const edge& ev : e)
		if (ms.merge(ev.l, ev.r))
			son[ev.l].emplace_back(ev.r, ev.v),
			son[ev.r].emplace_back(ev.l, ev.v);
	for (int i = 1; i <= n; ++i)
		if (!nat[i])dfs(i, 0, 0);
	for (int i = 1, l, r; i <= k; ++i)
		cin >> l >> r, cout << lcv(l, r) << endl;
}
