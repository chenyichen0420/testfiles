#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
int n, m; char ty[100005]; vector<int>son[100005];
int f[100005][18], t[100005][18], ct, d[100005]; char cc;
inline void dfs(int p, int fa) {
	f[p][0] = fa; d[p] = d[fa] + 1;
	t[p][0] = 1ll << (ty[p] != 'H');
	for (int i = 1; i <= 17; ++i)
		f[p][i] = f[f[p][i - 1]][i - 1],
		t[p][i] = t[p][i - 1] | t[f[p][i - 1]][i - 1];
	for (int sp : son[p]) if (sp != fa) dfs(sp, p);
}
inline int lcv(int l, int r) {
	if (d[l] < d[r]) swap(l, r); int ret = 0;
	for (int i = 17; i >= 0; i--)
		(d[f[l][i]] >= d[r]) && (ret |= t[l][i], l = f[l][i]);
	if (l == r) return ret | t[l][0];
	for (int i = 17; i >= 0; i--)
		if (f[l][i] != f[r][i])
			ret |= t[l][i] | t[r][i],
			l = f[l][i], r = f[r][i];
	return ret | t[l][1] | t[r][1];
}
signed main() {
	if (online)
		freopen("milk.in", "r", stdin),
		freopen("milk.out", "w", stdout);
	ios::sync_with_stdio(0); 
	cin >> n >> m >> (ty + 1);
	for (int i = 1, l, r; i != n; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	dfs(1, 0);
	for (int i = 1, l, r; i <= m; ++i)
		cin >> l >> r >> cc, ct = 1ll << (cc != 'H'),
		putchar(lcv(l, r) & ct ? '1' : '0');
}
