#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
int n, op[1000005];
vector<int>son[10005];
struct mass {
    bool vis[1000005]; int pc[100005], pt;
    inline bool at(int p) {
        if (vis[p]) return 0;
        return vis[pc[++pt] = p] = 1;
    }
    inline void clear() {
        while (pt) vis[pc[pt--]] = 0;
    }
}vis;
inline bool dfs(int p) {
    for (int sp : son[p])
        if (vis.at(sp))
            if (!op[sp] || dfs(op[sp])) {
                op[sp] = p; return 1;
            }
    return 0;
}
signed main() {
    if (online)
        freopen("game.in", "r", stdin),
        freopen("game.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin >> n;
    for (int i = 1, l, r; i <= n; ++i)
        cin >> l >> r,
        son[l].emplace_back(i),
        son[r].emplace_back(i);
    for (int i = 1;; ++i)
        if (vis.clear(), !dfs(i))
            return cout << i - 1, 0;
}
