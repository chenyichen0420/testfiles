#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 0;
#define int long long
#ifdef _WIN32
#define getchar_unlocked _getchar_nolock
#define putchar_unlocked _putchar_nolock
#endif
inline int read() {
	int r = 0; char c = getchar_unlocked();
	while (c < '0' || c>'9') c = getchar_unlocked();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar_unlocked();
	return r;
}
constexpr int mod = 1e9 + 7, iv2 = (mod + 1) / 2, iv4 = (mod + 1) / 4;
struct fen {
	int h, w, p;
	inline bool operator<(const fen& r) {
		return h > r.h;
	}
}v[100005];
int n, ans;
set<int>vis; unordered_map<int, int>l, r;
inline void mad(int& l, const int r) {
	l = (r + l) % mod;
}
inline void calc(int sl, int sr, int h) {
	mad(ans, sl * sr % mod * h % mod * (h - 1) % mod * iv2);
	mad(ans, sl * sr % mod * h);
}
inline void casc(int s, int h) {
	mad(ans, s * h % mod * (s - 1) % mod * (h - 1) % mod * iv4);
	mad(ans, s * h % mod * (h - 1) % mod * iv2);
	mad(ans, h * s % mod * (s - 1) % mod * iv2);
	mad(ans, h * s);
}
inline void add(const fen& v) {
	int nl = v.p, nr = v.p + v.w - 1;
	int ty = vis.count(nl - 1) * 2 + vis.count(nr + 1);
	if (ty == 3) {
		r[l[nl - 1]] = r[nr + 1];
		l[r[nr + 1]] = l[nl - 1];
		int vl = nl - l[nl - 1];
		int vr = r[nr + 1] - nr;
		int vm = v.w;
		vl %= mod; vr %= mod;
		calc(vl, vm, v.h);
		calc(vl, vr, v.h);
		calc(vr, vm, v.h);
		casc(vm, v.h);
	}
	else if (ty & 2) {
		l[nr] = l[nl - 1];
		r[l[nl - 1]] = nr;
		int vl = nl - l[nl - 1];
		int vm = v.w; vl %= mod;
		calc(vl, vm, v.h);
		casc(vm, v.h);
	}
	else if (ty & 1) {
		r[nl] = r[nr + 1];
		l[r[nr + 1]] = nl;
		int vr = r[nr + 1] - nr;
		int vm = v.w; vr %= mod;
		calc(vr, vm, v.h);
		casc(vm, v.h);
	}
	else {
		l[nr] = nl;
		r[nl] = nr;
		int vm = v.w;
		casc(vm, v.h);
	}
	vis.emplace(nl);
	vis.emplace(nr);
	//cerr << ans << " " << ty << endl;
}
signed main() {
	if (online)
		freopen("fence.in", "r", stdin),
		freopen("fence.out", "w", stdout);
	ios::sync_with_stdio(0); n = read();
	for (int i = 1; i <= n; ++i) v[i].h = read();
	for (int i = 1; i <= n; ++i) v[i].w = read();
	for (int i = 1; i <= n; ++i)
		v[i].p = v[i - 1].p + v[i - 1].w,
		l[i] = r[i] = i;
	sort(v + 1, v + n + 1);
	for (int i = 1; i <= n; ++i) add(v[i]);
	cout << ans << endl;
	return 0;
}
//˽��è�Ǥ�
/*
1 2 2
9
*/
//16:48 pass big
