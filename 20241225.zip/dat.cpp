#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("race.in","w",stdout);
	ios::sync_with_stdio(0);
	srand((unsigned)time(0));
	cout<<"250000\n";
	for(int i=1;i<=125000;++i){
		cout<<i<<" "<<99<<endl;
	}
	for(int i=125001;i<=250000;++i){
		cout<<i+5e5<<" "<<1<<endl;
	}
	return 0;
}
