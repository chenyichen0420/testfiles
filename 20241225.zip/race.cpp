#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 0;
int n, p[250005], v[250005], ans;
inline double get(int l, int r) {
	return double(p[r] - p[l]) / (v[l] - v[r]);
}
struct node {
	int l, r; double t, p;
	node(int li = 0, int ri = 0) :l(li), r(ri) {
		t = get(l, r); p = ::p[l] + t * v[l];
	}
	friend bool operator<(const node& l, const node& r) {
		return l.t != r.t ? l.t < r.t : l.p < r.p;
	}
}tp; priority_queue<node>pq; stack<node>an;
vector<int>ps[100]; double ltt;
signed main() {
	if (online)
		freopen("race.in", "r", stdin),
		freopen("race.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n; ltt = 1e18;
	for (int i = 1; i <= n; ++i) {
		cin >> p[i] >> v[i];
		ps[v[i]].emplace_back(i);
		for (int j = v[i] + 1; j < 100; ++j) {
			ans = (ans + ps[j].size()) % 1000000;
			for (int p = ps[j].size() - 1; p >= 0; p--) {
				tp = node(ps[j][p], i);
				if (tp.t > ltt) break;
				pq.emplace(tp);
			}
			if (pq.size() >= 10000) {
				while (pq.size() > 10000) pq.pop();
				ltt = pq.top().t;
			}
		}
	}
	cout << ans << endl;
	while (pq.size()) an.emplace(pq.top()), pq.pop();
	while (an.size()) cout << an.top().l << " " << an.top().r << endl, an.pop();
	return 0;
}
//˽��è�Ǥ�
/*
---
�ٶȾ�����ͻ�ƿڡ�
û�������
---
*/
