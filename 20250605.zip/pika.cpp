#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
int n, m, k, pc[205], d[205], ans, cd[205]; bool vis[205];
struct node {
	int p, v;
	node(int pi = 0, int vi = 0) :p(pi), v(vi) {};
	friend bool operator<(const node& l, const node& r) {
		return l.v > r.v;
	}
}tmp; vector<node>son[205]; priority_queue<node>pq;
inline int mind(int sp) {
	memset(d, 0x3f, sizeof d);
	memset(vis, 0, sizeof vis);
	pq.emplace(sp, d[sp] = 0);
	int rep = n + 1;
	while (pq.size()) {
		tmp = pq.top(); pq.pop();
		if (pc[tmp.p] && rep > n) rep = tmp.p;
		if (vis[tmp.p] || tmp.p > sp) continue;
		vis[tmp.p] = 1;
		for (const node& sp : son[tmp.p])
			if (d[sp.p] > d[tmp.p] + sp.v)
				pq.emplace(sp.p, d[sp.p] = d[tmp.p] + sp.v);
	}
	return rep;
}
signed main() {
	if (online)
		freopen(R"(pika.in)", "r", stdin),
		freopen(R"(pika.out)", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n >> m >> k;
	for (int i = 1, l, r, v; i <= m; ++i)
		cin >> l >> r >> v,
		son[l].emplace_back(r, v),
		son[r].emplace_back(l, v);
	pc[0] = k;
	for (int i = 1; i <= n; ++i) {
		int cp = mind(i);
		pc[cp]--; pc[i]++; ans += d[cp];
		memcpy(cd, d, sizeof cd);
		int ap = mind(i + 1);
		if (ap == i) continue;
		int cv1 = cd[cp] + d[ap];
		int cv2 = cd[ap] + d[cp];
		if (cv1 < cv2) continue;
		pc[cp]++; pc[i]--; ans -= d[cp];
		pc[ap]--; pc[i]++; ans += d[ap];
	}
	cout << ans << endl;
}
