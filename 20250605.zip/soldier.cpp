#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
constexpr bool EDS = 0;
int n, m, s, t, k, ans, mic, a[105], b[105]; 
bool vis[105][105];
struct dinic {
	struct node { int p, v; }tmp;
	vector<node>e; vector<int>h[205];
	inline void ins(int l, int r, int v) {
		h[l].emplace_back(e.size());
		tmp.p = r; tmp.v = v;
		e.emplace_back(tmp);
		h[r].emplace_back(e.size());
		tmp.p = l; tmp.v = v * EDS;
		e.emplace_back(tmp);
	}
	int d[205]; bool vis[205];
	inline bool bfs() {
		memset(vis, 0, sizeof vis);
		queue<int>q; q.emplace(s); vis[s] = 1;
		while (q.size()) {
			int tp = q.front(); q.pop();
			for (int i : h[tp]) {
				const node& sp = e[i];
				if (sp.v && !vis[sp.p])
					d[sp.p] = d[tp] + 1,
					vis[sp.p] = 1, q.emplace(sp.p);
			}
		}
		return vis[t];
	}
	int hp[205];
	inline int dfs(int p, int f) {
		if (p == t || !f) return f; int ret = 0, tv;
		for (int& i = hp[p]; i != h[p].size(); ++i) {
			node& sp = e[h[p][i]];
			if ((d[sp.p] == d[p] + 1) && (tv = dfs(sp.p, min(sp.v, f)))) {
				e[h[p][i] ^ 1].v += tv; ret += tv; sp.v -= tv;
				if (!(f -= tv)) return ret;
			}
		}
		return ret;
	}
	inline int mxf() {
		ans = 0;
		while (bfs())
			memset(hp, 0, sizeof hp),
			ans += dfs(s, 2e9);
		return ans;
	}
}din;
int sa, sb;
signed main() {
	if (online)
		freopen(R"(soldier.in)", "r", stdin),
		freopen(R"(soldier.out)", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n >> m >> k; s = n + m + 1, t = s + 1;
	for (int i = 1; i <= n; ++i) cin >> a[i]; 
	for (int i = 1; i <= m; ++i) cin >> b[i]; 
	for (int i = 1, l, r; i <= k; ++i)
		cin >> l >> r, vis[l][r] = 1,
		a[l]++, b[r]++;
	for (int i = 1; i <= n; ++i)
		if (a[i] > m) return cout << "JIONG!\n", 0;
		else din.ins(s, i, m - a[i]);
	for (int i = 1; i <= m; ++i)
		if (b[i] > n) return cout << "JIONG!\n", 0;
		else din.ins(i + n, t, n - b[i]);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			if (!vis[i][j]) din.ins(i, j + n, 1);
	cout << n * m - k - din.mxf() << endl;
}
