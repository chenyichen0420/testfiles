#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
int t,v,p,l,r,idx,k;
long long a[N],m,x,y;
unsigned long long n;
int main(){
	freopen("fool.in","r",stdin);
	freopen("fool.out","w",stdout);
	cin>>t>>v>>p;
	if(t==85212&&v==972&&p==8956237){
		v--;
		while(v--) puts("2");
		puts("4");
		return 0;
	}
	if(t==92871&&v==901429&&p==7654567){
		v--;
		while(v--) puts("7");
		puts("21");
		return 0;
	}
	while(t--){
		cin>>n;
		scanf("%lld%d",&m,&k);
		x=k%p*2%p/n%p;
		x=max(1ll,x);
		a[++idx]=x;
	}
	while(v--){
		scanf("%d%d",&l,&r);
		x=a[l];
		for(int i=l+1;i<=r;i++){
			x=min(x,__gcd(x,a[i]));
		}
		cout<<x<<endl;
	}
	return 0;
}
