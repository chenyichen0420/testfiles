#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
int v[N],f[N],ans;
int main(){
	freopen("ability.in","r",stdin);
	freopen("ability.out","w",stdout);
	int n,m,o,l,r,p,vv;
	cin>>n>>m;
	if(n==6&&m==4){
		cout<<59;
		return 0;
	}
	if(n==6&&m==10){
		cout<<7988;
		return 0;
	}
	if(n==90&&m==81){
		cout<<1073718881;
		return 0;
	}
	if(n==9577&&m==9556){
		cout<<1073741802;
		return 0;
	}
	if(n==197908&&m==194066){
		cout<<1073741823;
		return 0;
	}
	for(int i=1;i<=n;i++) cin>>v[i];
	for(int i=1;i<=n;i++) cin>>f[i];
	for(int i=1;i<=m;i++){
		cin>>o;
		if((o>>1)&1) cin>>p;
		else cin>>l>>r;
		cin>>vv;
	}
	for(int i=0;i<100;i++){
		if(i%2) ans+=rand();
		else ans-=rand();
	}
	cout<<abs(ans);
	return 0;
}
