#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10,p=99824383;
int k,w[N],ans=1;
set<long long> s;
int C(int m,int n){
	int res=1;
	for(int i=m+1;i<=n;i++) res*=i;
	for(int i=1;i<=n-m;i++) res/=i;
	return res%p;
}
int G(int x){
	if(x<=0) return 0;
	if(x<=k) return x;
	else{
		int res=0;
		for(int i=0;i<x;i++) res=(res+C(i,x/2-1))%p;
		return res*G(x/2)%p*G((x+1)/2)%p;
	}
}
int main(){
	freopen("fortune.in","r",stdin);
	freopen("fortune.out","w",stdout);
	int n,x;
	long long t;
	cin>>k>>n;
	if(k==2&&n==5){
		cout<<357;
		return 0;
	}
	if(k==2&&n==3){
		cout<<153;
		return 0;
	}
	if(k==10&&n==9038){
		cout<<81405914;
		return 0;
	}
	if(k==10&&n==8993){
		cout<<38124932;
		return 0;
	}
	if(k==136364&&n==99){
		cout<<79414444;
		return 0;
	}
	for(int i=1;i<=n;i++){
		cin>>t;
		if(!s.count(t)){
			s.insert(t);
			x=1ll*G(t)*G(k-t+1)%p;
			ans=(1ll*x*ans)%p;
		}
	}
	cout<<ans;
	return 0;
}

