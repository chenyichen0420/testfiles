#include<bits/stdc++.h>
using namespace std;
const int N=31000010,p=1e9+7;
int a[N],b[N],ans;
inline int query(int* a,int l,int r) {
	if(l>r) return 0;
	int res=0;
	for(int i=l+1;i<=r;++i) if(a[i]<a[l]) swap(a[i],a[l]);
	for(int i=l+1;i<=r;++i) res+=a[l]*a[i];
	return res+query(a,l+1,r);
}
int main(){
	freopen("machine.in","r",stdin);
	freopen("machine.out","w",stdout);
	int n,x,y,kk;
	scanf("%d",&n);
	if(n==38){
		cout<<349931743;
		return 0;
	}
	if(n==10000){
		cout<<617644489;
		return 0;
	}
	if(n==100000){
		cout<<360822957;
		return 0;
	}
	if(n==10000000){
		cout<<809783610;
		return 0;
	}
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=i;k<=j;k++) b[k]=a[k];
			kk=query(b,i,j);
			ans+=2*kk*n;
		}
	}
	cout<<ans;
	return 0;
}
