#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,a[10010],psum[10010],ans,b[100010];
const int mod=1000000007;
int query(int* a, int l, int r) {
	if (l > r) return 0;
	int ret = 0;
	for (int i = l + 1; i <= r; ++i)
		if (a[i] < a[l]) swap(a[i], a[l]);
	for (int i = l + 1; i <= r; ++i)
		ret += a[l] * a[i];
	return ret + query(a, l + 1, r);
}
int ksm(int a,int b,int mod){
	if(b==1)return a;
	if(b==0)return 1;
	int nans=ksm(a,b/2,mod);
	nans*=nans;nans%=mod;
	if(b&1)return (nans*a)%mod;
	return nans;
} 
signed main(){
	freopen("machine.in","r",stdin);
	freopen("machine.out","w",stdout);
	ios::sync_with_stdio(0);
	cin>>n;
	for(int i = 1;i<=n;i++)cin>>a[i];
	for(int l = 1;l<=n;l++){
		for(int r = l+1;r<=n;r++){
			for(int i = l;i<=r;i++)b[i]=a[i];
			ans+=query(a,l,r);
			for(int i = l;i<=r;i++)a[i]=b[i];
		}
	}
	cout<<((ans*ksm(n*(n-1)/2,mod-2,mod))%mod)<<endl;
}
