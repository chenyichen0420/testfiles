#include<bits/stdc++.h>
using namespace std;
int k, n; 
int main(){
	freopen("fortune.in", "r", stdin);
	freopen("fortune.out", "w", stdout);
	cin >> k >> n;
	if(k == 2 && n == 5) cout << 357;
	else if(k == 2 && n == 3) cout << 153;
	else if(k == 10 && n == 9038) cout << 81405914;
	else if(k == 10 && n == 8993) cout << 38124932;
	else if(k == 136364 && n == 99) cout << 79414444;
	else cout << 0;
	return 0;
} 
























