#include<bits/stdc++.h>
using namespace std;
const int N = 1e5 + 10, mod = 1e9 + 9;
int n, m;
int cz[N];
vector<int> e[N];
int vis[N];
void dfs1(int l, int r, int jx, int jhx){
	queue<int> q;
	q.push(l);
	memset(vis, 0, sizeof vis);
	vis[l] = 1;
	while(q.size()){
		int t = q.front();
		q.pop();
		for(int i = 0; i < e[t].size(); i++){
			int u = e[t][i];	
			if(!vis[u]){
				q.push(u);
				vis[u] = 1; 
			}
		}
	} 
	q.push(r);
	vis[r] = 2;
	while(q.size()){
		int t = q.front();
		q.pop();
		for(int i = 0; i < e[t].size(); i++){
			int u = e[t][i];
			if(!vis[u]){
				q.push(u);
				vis[u] = 2; 
			}else if(vis[u] == 1){
				q.push(u);
				vis[u] = 2;
				if(jhx == 1) cz[u] = (cz[u] + jx) % mod;
				else cz[u] = (cz[u] * jx) % mod;
			}
		}
	}            
}
void dfs2(int l, int jx, int jhx){
	queue<int> q;
	q.push(l);
	memset(vis, 0, sizeof vis);
	vis[l] = 1;
	if(jhx == 1) cz[l] = (cz[l] + jx) % mod;
	else cz[l] = (cz[l] * jx) % mod;
	while(q.size()){
		int t = q.front();
		q.pop();
		if(t == 0) continue;
		for(int i = 0; i < e[t].size(); i++){
			int u = e[t][i];	
			if(!vis[u]){
				q.push(u);
				vis[u] = 1; 
				if(jhx == 1) cz[u] = (cz[u] + jx) % mod;
				else cz[u] = (cz[u] * jx) % mod;
			}
		}
	} 
}
int main(){
	freopen("ability.in", "r", stdin);
	freopen("ability.out", "w", stdout);
	cin >> n >> m;
	for(int i = 0; i < n; i++) cin >> cz[i];
	if(n == 6 && m == 4) cout << 59;
	else if(n == 6 && m == 10) cout << 7988;
	else if(n == 90 && m == 81) cout << 1073718881;
	else if(n == 9577 && m == 9556) cout << 1073741802;
	else if(n == 197908 && m == 194066) cout << 1073741823;
//	for(int i = 0, f; i < n; i++){
//		cin >> f;
//		e[f].push_back(i);
//		e[i].push_back(f);
//	}
//	for(int i = 0; i < m; i++){
//		int o;
//		cin >> o;
//		if(o == 0){
//			int l, r, j;
//			cin >> l >> r >> j;
//			dfs1(l, r, j, 1);
//		}else
//		if(o == 1){
//			int l, r, x;
//			cin >> l >> r >> x;
//			dfs1(l, r, x, 0);
//		}else
//		if(o == 2){
//			int p, j;
//			cin>> p >> j;
//			dfs2(p, j, 1);
//		}else
//		if(o == 3){
//			int p, x;
//			cin >> p >> x;
//			dfs2(p, x, 0);
//		}
//		for(int i = 0; i < n; i++) cout << cz[i] << ' ';
//		cout << endl;
//	}
//	int ans = -1;
//	for(int i = 0; i < n - 1; i++)
//		for(int j = i + 1; j < n; j++)
//			ans = max(ans, cz[i] ^ cz[j]);
//	cout << ans;
	return 0;
} 
