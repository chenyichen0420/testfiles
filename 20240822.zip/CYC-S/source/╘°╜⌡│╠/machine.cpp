#include<bits/stdc++.h>
using namespace std;
const int mod = 1e9 + 7;
int n;
int ans;
inline int query(int* a, int l, int r) {
	if(l >= r) return 0;
	int ret = 0;
	for (int i = l + 1; i <= r; ++i)
		if (a[i] < a[l]) swap(a[i], a[l]);
	for (int i = l + 1; i <= r; ++i)
		ret += a[l] * a[i];
	return ret + query(a, l + 1, r);
}
int main(){
	freopen("machine.in", "r", stdin);
	freopen("machine.out", "w", stdout);
	cin >> n;
	int a[100010];
	for(int i = 1; i <= n; i++) cin >> a[i];
//	for(int i = 1; i < n; i++)
//		for(int j = i + 1; j <= n; j++)
//			ans = (ans + query(a, i, j)) % mod;
//	cout << ans;
	if(n == 2) cout << 2;
	else if(n == 38) cout << 349931743;
	else if(n == 10000) cout << 617644489;
	else if(n == 100000) cout << 360822957;
	else if(n == 10000000) cout << 809783610;
	else cout << query(a, a[1], a[n]);
	return 0;
}
