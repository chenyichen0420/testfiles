#include<bits/stdc++.h>
using namespace std;

signed main(){
	freopen("fortune.in","r",stdin);
	freopen("fortune.out","w",stdout);
	return 0;
}
