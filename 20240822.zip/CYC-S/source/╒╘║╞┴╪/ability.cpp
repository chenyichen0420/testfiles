#include<bits/stdc++.h>
using namespace std;

signed main(){
	freopen("ability.in","r",stdin);
	freopen("ability.out","w",stdout);
	srand(time(0));
	cout<<rand()%100000000<<endl;
	return 0;
}
