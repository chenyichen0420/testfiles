#include<bits/stdc++.h>
using namespace std;

signed main(){
	freopen("fool.in","r",stdin);
	freopen("fool.out","w",stdout);
	return 0;
}
