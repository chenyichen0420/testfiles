#include<bits/stdc++.h>
#define int long long
using namespace std;
int mod=1e9+7;
int n,a[100010],an=0,ans=0;
bool v[100010];
int ksm(int a,int b){
	int t=a,res=1;
	while(b){
		if(b&1)res=(res*t)%mod;
		t=t*t%mod;
		b>>=1;
	}
	return res;
}
inline int query(int* a,int l,int r,int t,int now){
	if(now==t)return 0;
	if (l>r) return 0;
	int ret=0;
	int mn=INT_MAX,m=0;
	for (int i=l;i<=r;++i){
		if(a[i]<mn&&!v[i]){
			//cout<<i<<' '<<a[i]<<endl;
			mn=a[i];
			m=i;
		}
	}
	v[m]=1;
	//cout<<m<<' '<<l<<' '<<r<<endl;
	for(int i=l;i<=r;++i)if(i!=m&&!v[i])ret=(ret+mn*a[i])%mod;
	//cout<<ret<<endl;
	return ret+query(a,l,r,t,now+1);
}

signed main(){
	freopen("machine.in","r",stdin);
	freopen("machine.out","w",stdout);
	scanf("%lld",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	an=n*(n-1)/2;
	//cout<<query(a,1,n,n,0)<<endl;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			//cout<<i<<' '<<j<<endl;
			memset(v,0,sizeof(v));
			ans+=query(a,i,j,j-i+1,0);
			ans%=mod;
		}
	}
	//cout<<ans<<endl;
	cout<<(int)ans/an<<endl;
	return 0;
}
