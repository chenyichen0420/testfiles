#include<bits/stdc++.h>
using namespace std;
constexpr int mod=1e9+9;
int n,m,v[100000+5],f[100000+5],dep[100000+5],opt,l,r,V;
vector<int>son[100000+5];
void dfs(int x){
	for(int y:son[x]){
		dep[y]=dep[x]+1;
		dfs(y);
	}
}
void Dep(int x,int y,int val,bool mode){
	if(dep[x]<dep[y]) swap(x,y);
	while(dep[x]^dep[y]){
		if(mode) v[x]*=val;
		else v[x]+=val;
		v[x]%=mod;
		x=f[x];
	}
	while(x^y){
		if(mode) v[x]*=val;
		else v[x]+=val;
		v[x]%=mod;
		x=f[x];
		if(mode) v[y]*=val;
		else v[y]+=val;
		v[y]%=mod;
		y=f[y];
	}
	if(mode) v[x]*=val;
	else v[x]+=val;
	v[x]%=mod;
}
void Dfs(int x,int val,bool mode){
	if(mode) v[x]*=val;
	else v[x]+=val;
	v[x]%=mod;
	for(int y:son[x]){
		Dfs(y,val,mode);
	}
}
void Wid(int x,int val,bool mode){
	while(dep[x]^2) x=f[x];
	Dfs(x,val,mode);
}
int main(){
	freopen("ability.in","r",stdin);
	freopen("ability.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin>>n>>m;
	for(int i=1;i<=n;++i) cin>>v[i];
	for(int i=1;i<=n;++i) cin>>f[i],son[f[i]].push_back(i);
	dep[son[0][0]]=1;
	dfs(son[0][0]);
	while(m--){
		cin>>opt;
		bitset<2>bt;
		bt=opt;
//		cerr<<(bt[1]?"BFS":"DFS")<<" with mode "<<(bt[0]?"*=":"+=")<<endl;
		if(!bt[1]) cin>>l>>r>>V,Dep(l,r,V,bt[0]);
		else cin>>l>>V,Wid(l,V,bt[0]);
//		for(int i=1;i<=n;++i) cout<<v[i]<<' ';cout<<endl;
	}
	int mx=0;
	for(int i=1;i<=n;++i)
		for(int j=i+1;j<=n;++j)
			mx=max(mx,v[i]^v[j]);
	cout<<mx<<endl;
	return 0;
}
