#include<bits/stdc++.h>
using namespace std;
using ll=long long;
constexpr int mod=1e9+7;
#ifdef _WIN32
#define getchar_unlocked getchar
#define putchar_unlocked putchar
#endif
inline void read(int& r) {
	r = 0; char c = getchar_unlocked();
	while (c < '0' || c>'9') c = getchar_unlocked();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar_unlocked();
	return;
}
inline void read(short& r) {
	r = 0; char c = getchar_unlocked();
	while (c < '0' || c>'9') c = getchar_unlocked();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar_unlocked();
	return;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar_unlocked(x % 10 ^ 48);
	return;
}
int n;
short a[31000005],b[31000005];
ll poww(ll a,ll x){ 
	if(x==0) return 1;
	ll t=poww(a,x/2);
	t=(t*t)%mod;
	if(x%2==1) t=(t*a)%mod;
	return t;
}
namespace debug{
	inline int query(short* a, int l, int r) {
		if (l > r) return 0;
		int ret = 0;
		for (int i = l + 1; i <= r; ++i)
			if (a[i] < a[l])
				swap(a[i], a[l]);
		for (int i = l + 1; i <= r; ++i)
			ret += a[l] * a[i];
		return ret + query(a, l + 1, r);
	}
}
int main(){
	freopen("machine.in","r",stdin);
	freopen("machine.out","w",stdout);
//	ios_base::sync_with_stdio(false);
	read(n);
	for(int i=1;i<=n;++i) read(a[i]),b[i]=a[i];
	long long ans=0;
	for(int i=1;i<=n;++i){
		memcpy(b,a,sizeof a);
		for(int j=i+1;j<=n;++j){
			ans+=debug::query(b,i,j);
			ans%=mod;
//			for(int k=i;k<=j;++k) b[k]=a[k];
		}
	}
	write(ans*poww(((n-1)*n/2),mod-2)%mod);
	return 0;
} 
