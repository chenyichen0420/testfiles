#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("fool.in","r",stdin);
	freopen("fool.out","w",stdout);
	ios_base::sync_with_stdio(false);
	int t,v,p; cin>>t>>v>>p;
	while(v--) cout<<1<<'\n';
	return 0;
}
