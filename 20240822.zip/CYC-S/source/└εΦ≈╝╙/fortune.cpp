#include<bits/stdc++.h>
using namespace std;
using ll=long long;
constexpr int p=99824383;
int n,k,inv[200000+5];
inline ll C(int n,int m){
	if(m>n)return 0;
	if(n>p&&m<p&&n-m<p)return 0;
	if(n<p){
		ll tmp=1;
		for(int i=m+1;i<=n;++i)if(i>n-m)tmp*=i,tmp%=p;
		for(int i=1;i<=n-m;++i)if(i<=m)tmp*=inv[i],tmp%=p;
		return tmp;
	}
	return C(n/p,m/p)%p*C(n%p,m%p)%p;
}
int y[200000+5];
ll G(int x){
	if(x<=0) return 0;
	if(x==1) return 1;
	if(y[x]) return y[x];
	ll tot=0;
	for(int i=0;i<=x-1;++i) tot+=C(i,x/2-1),tot%=p;
	return y[x]=tot*G(x/2)%p*G(ceil(x/2.0))%p;
}
unordered_map<int,ll>h;
ll S(int x){
	if(x<=k) return 1;
	if(h[x]) return h[x];
	for(int i=1;i<x;++i) h[x]+=S(i)*G(k-(x-i)+1),h[x]%=p;
	return h[x];
}
int main(){
	freopen("fortune.in","r",stdin);
	freopen("fortune.out","w",stdout);
	ios_base::sync_with_stdio(false);
	inv[0]=inv[1]=1;
	for(int i=2;i<=200000;++i)
		inv[i]=1ll*(p-p/i)*inv[p%i]%p;
	cin>>k>>n;
	cerr<<k<<' '<<n<<endl;
	ll ans=1;
	while(n--){
		int v;
		cin>>v;
		ll cur=S(v);
		ans*=cur;
		ans%=p;
	}
	cout<<ans<<endl;
	return 0;
}
