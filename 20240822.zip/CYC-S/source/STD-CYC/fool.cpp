#include<bits/stdc++.h>
using namespace std;
#define int long long
inline int read() {
	int r = 0; char c = getchar();
	while (c < '0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar();
	return r;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar(x % 10 ^ 48);
	return;
}
inline void writi(int args) {
	write(args); putchar(10);
}
int t, m, k, p, n, jcb[15], ant, jcbny[15], v, l, r;
string tn; int st[100005][22], lg[100005];
inline void readn() {
	n = 0; char c = getchar();
	while (c < '0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9')
		n = n * 10 + (c ^ 48),
		c = getchar(), n %= p - 1;
}
inline int qpow(int a, int b) {
	if (b == 0) return 1;
	int tmp = 1; a %= p;
	while (b) {
		if (b & 1) tmp *= a, tmp %= p;
		a *= a; a %= p; b >>= 1;
	}
	return tmp;
}
inline int cvl(int n, int m, int p) {
	if (n < m) return 0;
	return jcb[n] * jcbny[m] % p * jcbny[n - m] % p;
}
inline int gcd(int _Ax, int _Bx) {
	while (_Bx) {
		const int _Ax2 = _Ax;
		_Ax = _Bx;
		_Bx = _Ax2 % _Bx;
	}
	return _Ax;
}
signed main() {
	freopen("fool.in","r",stdin); 
	freopen("fool.out","w",stdout);
	t = read(), v = read(), p = read(); jcb[0] = jcbny[0] = 1;
	for (int i = 1; i <= 10; ++i)
		jcb[i] = jcb[i - 1] * i % p,
		jcbny[i] = qpow(jcb[i], p - 2);
	for (int w = 1; w <= t; ++w) {
		readn(); m = read(); k = read(); ant = 0;
		for (int i = 0; i <= k; ++i)
			ant += (i & 1 ? -1 : 1) * qpow(m - i, n) * cvl(k, i, p) % p, ant %= p;
		st[w][0] = (ant + p) % p;
		lg[w] = lg[w - 1] + (1ll << lg[w - 1] == w);
	}
	for (int i = 1; i <= lg[t]; ++i)
		for (int j = 1; j + (1ll << i) <= t + 1; ++j)
			st[j][i] = gcd(st[j][i - 1], st[j + (1ll << i - 1)][i - 1]);
	for (int i = 1; i <= t; ++i) lg[i]--;
	for (int i = 1; i <= v; ++i) {
		l = read(), r = read(); int le = lg[r - l + 1];
		writi(gcd(st[l][le], st[r - (1ll << le) + 1][le]));
	}
	return 0;
}
