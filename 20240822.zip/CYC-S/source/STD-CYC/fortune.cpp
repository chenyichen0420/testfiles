#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int mod = 99824383, brf = 0;
int k, n, v[10005], jcv[500005], ans[500005], ap = 1;
struct mat {
	int v[10][10], n, m;
	mat(int ni = 0, int mi = 0) :n(ni), m(mi) {
		memset(v, 0, sizeof v);
	}
	inline mat operator*(const mat& r) {
		mat tmp(n, r.m);
		for (int k = 0; k < m; ++k)
			for (int i = 0; i < n; ++i)
				for (int j = 0; j < r.m; ++j)
					tmp.v[i][j] = (tmp.v[i][j] + v[i][k] * r.v[k][j]) % mod;
		return tmp;
	}
}an, go, tmp, emp;
inline void mpow(mat m, int tm) {
	tmp = emp;
	for (; tm; tm >>= 1, m = m * m)
		if (tm & 1) tmp = tmp * m;
}
signed main() {
	freopen("fortune.in","r",stdin); 
	freopen("fortune.out","w",stdout);
	ios::sync_with_stdio(0);
	cin >> k >> n;
	for (int i = 1; i <= n; ++i) cin >> v[i];
	sort(v + 1, v + n + 1); jcv[0] = 1;
	for (int i = 1; i <= k; ++i) jcv[i] = jcv[i - 1] * i % mod;
	if (k > 10) {
		for (int i = 0; i <= k; ++i) ans[i] = 1;
		int np = k;
		for (int i = 1; i <= n; ++i) {
			while (np < v[i]) {
				np++; ans[k] = 0;
				for (int j = 0; j < k; ++j)
					ans[k] = (ans[k] + ans[j] * jcv[j + 1]) % mod;
				for (int j = 1; j <= k; ++j) ans[j - 1] = ans[j];
			}
			ap *= ans[k], ap %= mod;
		}
		cout << ap << endl;
		return 0;
	}
	go = emp = mat(k, k); an = mat(1, k);
	for (int i = 0; i < k; ++i) emp.v[i][i] = 1;
	for (int i = 0; i < k; ++i) an.v[0][i] = 1;
	for (int i = 0; i < k; ++i) go.v[i][0] = jcv[k - i];
	for (int i = 1; i < k; ++i) go.v[i - 1][i] = 1;
	int tp = 0, np = k;
	while (v[tp] <= k && tp <= n) tp++;
	while (tp <= n) {
		int dif = v[tp] - np; np = v[tp]; tp++;
		if (dif)mpow(go, dif), an = an * tmp;
		ap = ap * an.v[0][0] % mod;
	}
	cout << ap << endl;
}
