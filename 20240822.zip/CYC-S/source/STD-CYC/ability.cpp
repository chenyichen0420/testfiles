#include<bits/stdc++.h>
using namespace std;
#ifdef _WIN32
#define getchar_unlocked getchar
#define putchar_unlocked putchar
#endif
inline int read() {
	int r = 0; char c = getchar_unlocked();
	while (c < '0' || c>'9') c = getchar_unlocked();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar_unlocked();
	return r;
}
constexpr int siz = 2e5 + 5, mod = 1e9 + 9;
vector<int>son[siz]; using cir = const int&;
int n, m, v[siz], f[siz], o, l, r, vt, rt, cnt, dp[siz];
int sz[siz], hs[siz], lnk[siz], nid[siz], nvl[siz], ans;
inline void spl_lnk(cir p) {
	sz[p] = 1; dp[p] = dp[f[p]] + 1;
	for (cir sp : son[p])
		if (sp != f[p]) {
			spl_lnk(sp), sz[p] += sz[sp];
			if (sz[sp] > sz[hs[p]]) hs[p] = sp;
		}
}
inline void down_he(cir p, cir f) {
	lnk[p] = f; nid[p] = ++cnt; nvl[cnt] = v[p];
	if (!hs[p]) return; down_he(hs[p], f);
	for (cir sp : son[p])
		if (sp != ::f[p] && sp != hs[p]) down_he(sp, sp);
}
inline void ttop(int& p) {
	while (lnk[p] != rt && f[lnk[p]] != rt) p = f[lnk[p]];
	p = (lnk[p] == rt ? hs[rt] : lnk[p]);
}
#define mid (re[p].l + re[p].r >> 1)
class seg_tree {
	struct node {
		int l, r;long long la, lt;
	}re[siz << 2];
	inline node& lc(cir p) { return re[p << 1]; }
	inline node& rc(cir p) { return re[p << 1 | 1]; }
	inline void pud(cir p) {
		lc(p).lt *= re[p].lt; rc(p).lt *= re[p].lt;
		lc(p).la *= re[p].lt; rc(p).la *= re[p].lt;
		lc(p).la += re[p].la; rc(p).la += re[p].la;
		lc(p).lt %= mod; rc(p).lt %= mod;
		lc(p).la %= mod; rc(p).la %= mod;
		re[p].lt = 1; re[p].la = 0;
	}
public:
	inline void build(cir l, cir r, cir p) {
		re[p].l = l; re[p].r = r; re[p].lt = 1;
		if (l == r) return;
		build(mid + 1, r, p << 1 | 1);
		build(l, mid, p << 1);
	}
	inline void add(cir l, cir r, cir v, cir p) {
		if (l <= re[p].l && r >= re[p].r) {
			re[p].la = (re[p].la + v) % mod; return;
		}
		pud(p);
		if (r > mid) add(l, r, v, p << 1 | 1);
		if (l <= mid) add(l, r, v, p << 1);
	}
	inline void mul(cir l, cir r, cir v, cir p) {
		if (l <= re[p].l && r >= re[p].r) {
			re[p].la *= v; re[p].lt *= v;
			re[p].la %= mod; re[p].lt %= mod;
			return;
		}
		pud(p);
		if (r > mid) mul(l, r, v, p << 1 | 1);
		if (l <= mid) mul(l, r, v, p << 1);
	}
	inline void down(cir p) {
		if (re[p].l == re[p].r)
			v[re[p].l] = (nvl[re[p].l] * re[p].lt + re[p].la) % mod;
		else pud(p), down(p << 1), down(p << 1 | 1);
	}
}sgt;
inline void alk(int l, int r, cir cv) {
	while (lnk[l] ^ lnk[r]) {
		if (dp[f[lnk[l]]] < dp[f[lnk[r]]]) swap(l, r);
		sgt.add(nid[lnk[l]], nid[l], cv, 1); l = f[lnk[l]];
	}
	if (dp[l] > dp[r])swap(l, r);
	sgt.add(nid[l], nid[r], cv, 1);
}
inline void mlk(int l, int r, cir cv) {
	while (lnk[l] ^ lnk[r]) {
		if (dp[f[lnk[l]]] < dp[f[lnk[r]]]) swap(l, r);
		sgt.mul(nid[lnk[l]], nid[l], cv, 1); l = f[lnk[l]];
	}
	if (dp[l] > dp[r])swap(l, r);
	sgt.mul(nid[l], nid[r], cv, 1);
}
class trie {
	int p[siz * 32][2], cnt;
public:
	inline void ins(const int& v) {
		int np = 0;
		for (int i = 30; i >= 0; i--)
			if (p[np][(v >> i) & 1]) np = p[np][(v >> i) & 1];
			else np = p[np][(v >> i) & 1] = ++cnt;
	}
	inline int que(const int& v) {
		int np = 0, ret = 0;
		for (int i = 30; i >= 0; i--)
			if (!p[np][((v >> i) & 1) ^ 1]) np = p[np][(v >> i) & 1];
			else np = p[np][((v >> i) & 1) ^ 1], ret |= (1ll << i);
		return ret;
	}
}re;
int main() {
	freopen("ability.in","r",stdin); 
	freopen("ability.out","w",stdout);
	n = read(); m = read();
	for (int i = 1; i <= n; ++i) v[i] = read();
	for (int i = 1; i <= n; ++i)
		son[f[i] = read()].emplace_back(i);
	spl_lnk(rt = son[0][0]); down_he(rt, rt); sgt.build(1, n, 1);
	while (m--)
		if ((o = read()) == 0) l = read(), r = read(), alk(l, r, read());
		else if (o == 1) l = read(), r = read(), mlk(l, r, read());
		else if (o == 2) l = read(), ttop(l), sgt.add(nid[l], nid[l] + sz[l] - 1, read(), 1);
		else l = read(), ttop(l), sgt.mul(nid[l], nid[l] + sz[l] - 1, read(), 1);
	sgt.down(1);
	for (int i = 1; i <= n; ++i) re.ins(v[i]), ans = max(ans, re.que(v[i]));
	cout << ans << endl;
}
