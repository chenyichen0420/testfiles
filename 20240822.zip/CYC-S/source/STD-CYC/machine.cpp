#include<bits/stdc++.h>
using namespace std;
#define Int long long
constexpr Int mod = 1e9 + 7;
inline int read() {
	int r(0); char c(getchar());
	while (c < '0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar();
	return r;
}
inline Int qpow(Int a, Int b, Int p) {
	Int tmp = 1ll;
	while (b) {
		if (b & 1) tmp *= a, tmp %= p;
		a *= a; a %= p; b >>= 1;
	}
	return tmp;
}
int n, a[31000005];Int ans, tpv, ty;
signed main() {
	freopen("machine.in","r",stdin); 
	freopen("machine.out","w",stdout);
	n = read();
	for (int i = 1; i <= n; ++i) a[i] = read();
	for (int i = n, j = 1; i > 0; i--, ++j)
		(ans += i * a[i] * tpv) %= mod,
		(tpv += a[i] * j) %= mod;
	ty = (Int)n * (n - 1) / 2 % mod;
	cout << ans * qpow(ty, mod - 2, mod) % mod << endl;
	return 0;
}
