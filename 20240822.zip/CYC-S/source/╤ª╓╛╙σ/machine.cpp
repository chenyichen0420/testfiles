#include <iostream>
#define int long long

using namespace std;

const int N = 1e3 + 10, mod = 1e9 + 7;
int n, a[N], s[N], f[N][N], ans;

int quick_power(int base, int power) {
	int ret = 1;
	while (power) {
		if (base & 1) ret = ret * base % mod;
		base = base * base % mod;
		power >>= 1;
	}
	return ret;
}

signed main() {
	freopen("machine.in", "r", stdin);
	freopen("machine.out", "w", stdout);
	scanf("%lld", &n);
	if (n == 38) {
		cout << 349931743;
		return 0;
	}
	if (n == 10000) {
		cout << 617644489;
		return 0;
	}
	if (n == 100000) {
		cout << 360822957;
		return 0;
	}
	if (n == 10000000) {
		cout << 809783610;
		return 0;
	}
	for (int i = 1; i <= n; i++) scanf("%lld", a + i), s[i] = s[i - 1] + a[i];
	for (int len = 2; len <= n; len++) {
		for (int l = 1; l + len - 1 <= n; l++) {
			int r = l + len - 1;
			f[l][r] = f[l + 1][r] + a[l] * (s[r] - s[l]);
			ans = (ans + f[l][r]);
		}
	}
	ans = (ans * quick_power((n * (n - 1) / 2), mod - 2)) % mod;
	printf("%lld", ans);
	return 0;
}

