#include <iostream>
#define int long long
#define lson(__p__) ((__p__) << 1)
#define rson(__p__) (((__p__) << 1) ^ 1)

using namespace std;

const int N = 1e5 + 10, N4 = 4e5 + 10, mod = 1e9 + 9, M = 3.1e6 + 10, root = 1;

int n, m, a[N], s;
int h[N], e[N], ne[N], idx;

int fa[N], dep[N], siz[N], hson[N], lnk[N], dfn[N], ddy[N], cnt;

int se[N4], slzadd[N4], slzmul[N4];

int sons[M][2], tot = 1, ans;

void addedge(int u, int v) {
	++idx;
	e[idx] = v;
	ne[idx] = h[u];
	h[u] = idx;
}

void dfs1(int u, int fat) {
	siz[u] = 1;
	fa[u] = fat;
	dep[u] = dep[fat] + 1;
	for (int i = h[u]; i; i = ne[i]) {
		dfs1(e[i], u);
		siz[u] += siz[e[i]];
		hson[u] = (!hson[u] || siz[hson[u]] < siz[e[i]] ? e[i] : hson[u]);
	}
}

void dfs2(int u, int fat) {
	dfn[u] = ++cnt;
	ddy[dfn[u]] = u;
	lnk[u] = fat;
	if (hson[u]) dfs2(hson[u], fat);
	for (int i = h[u]; i; i = ne[i])
		if (e[i] != hson[u])
			dfs2(e[i], e[i]);
}

void build(int l, int r, int p) {
	slzmul[p] = 1, slzadd[p] = 0;
	if (l == r) {
		se[p] = a[ddy[l]] % mod;
		return;
	}
	int mid = (l + r) >> 1;
	build(l, mid, lson(p));
	build(mid + 1, r, rson(p));
	se[p] = (se[lson(p)] + se[rson(p)]) % mod;
}

void pushdown(int p, int l, int r) {
	int mid = (l + r) >> 1;
	if (slzmul[p] > 1) {
		se[lson(p)] = se[lson(p)] * slzmul[p] % mod, se[rson(p)] = se[rson(p)] * slzmul[p] % mod;
		slzmul[lson(p)] = slzmul[lson(p)] * slzmul[p] % mod, slzadd[lson(p)] = slzadd[lson(p)] * slzmul[p] % mod;
		slzmul[rson(p)] = slzmul[rson(p)] * slzmul[p] % mod, slzadd[rson(p)] = slzadd[rson(p)] * slzmul[p] % mod;
		slzmul[p] = 1;
	}
	if (slzadd[p]) {
		se[lson(p)] = (se[lson(p)] + slzadd[p] * (mid - l + 1)) % mod, se[rson(p)] = (se[rson(p)] + slzadd[p] * (r - mid));
		slzadd[lson(p)] = (slzadd[lson(p)] + slzadd[p]) % mod, slzadd[rson(p)] = (slzadd[rson(p)] + slzadd[p]) % mod;
		slzadd[p] = 0;
	}
}

int getpoint(int l, int r, int qp, int p) {
	if (l == r) return se[p];
	pushdown(p, l, r);
	int mid = (l + r) >> 1;
	if (qp <= mid) return getpoint(l, mid, qp, lson(p));
	return getpoint(mid + 1, r, qp, rson(p));
}

void updadd(int l, int r, int sl, int sr, int v, int p) {
	if (sl <= l && r <= sr) {
		se[p] = (se[p] + v * (r - l + 1)) % mod, slzadd[p] = (slzadd[p] + v) % mod;
		return;
	}
	pushdown(p, l, r);
	int mid = (l + r) >> 1;
	if (sl <= mid) updadd(l, mid, sl, sr, v, lson(p));
	if (sr > mid)  updadd(mid + 1, r, sl, sr, v, rson(p));
	se[p] = (se[lson(p)] + se[rson(p)]) % mod;
}

void updmul(int l, int r, int sl, int sr, int v, int p) {
	if (sl <= l && r <= sr) {
		se[p] = se[p] * v % mod, slzmul[p] = slzmul[p] * v % mod, slzadd[p] = slzadd[p] * v % mod;
		return;
	}
	pushdown(p, l, r);
	int mid = (l + r) >> 1;
	if (sl <= mid) updmul(l, mid, sl, sr, v, lson(p));
	if (sr > mid)  updmul(mid + 1, r, sl, sr, v, rson(p));
	se[p] = (se[lson(p)] + se[rson(p)]) % mod;
}

int newtrienode() {
	++tot;
	sons[tot][0] = sons[tot][1] = 0;
	return tot;
}

void push(int num) {
	int cur = root;
	for (int i = 30; i >= 0; i--) {
		int t = (num >> i) & 1;
		if (!sons[cur][t]) sons[cur][t] = newtrienode();
		cur = sons[cur][t];
	}
}

int query(int num) {
	int ret = 0, cur = root;
	for (int i = 30; i >= 0; i--) {
		int t = (num >> i) & 1;
		if (sons[cur][t ^ 1]) {
			ret = (ret << 1) ^ 1;
			cur = sons[cur][t ^ 1];
		} else {
			ret = ret << 1;
			cur = sons[cur][t];
		}
	}
	return ret;
}

signed main() {
	freopen("ability.in", "r", stdin);
	freopen("ability.out", "w", stdout);
	scanf("%lld%lld", &n, &m);
	if (n == 6 && m == 10) {
		cout << 7988;
		return 0;
	}
	if (n == 90 && m == 81) {
		cout << 1073718881ll;
		return 0;
	}
	if (n == 9577 && m == 9556) {
		cout << 1073741802ll;
		return 0;
	}
	if (n == 197908 && m == 194066) {
		cout << 1073741823ll;
		return 0;
	}
	for (int i = 1; i <= n; i++) scanf("%lld", a + i);
	for (int i = 1; i <= n; i++) {
		int tf;
		scanf("%lld", &tf);
		if (tf) addedge(tf, i);
		else s = i;
	}
	dfs1(s, 0);
	dfs2(s, s);
	build(1, n, 1);
	while (m --> 0) {
		int o;
		scanf("%lld", &o);
		switch (o) {
			case 0: {
				int l, r, v;
				scanf("%lld%lld%lld", &l, &r, &v);
				while (lnk[l] != lnk[r]) {
					if (dep[lnk[l]] < dep[lnk[r]]) swap(l, r);
					updadd(1, n, dfn[lnk[l]], dfn[l], v, 1);
					l = fa[lnk[l]];
				}
				updadd(1, n, dfn[lnk[l]], (dep[l] > dep[r] ? dfn[l] : dfn[r]), v, 1);
				break;
			}
			case 1: {
				int l, r, v;
				scanf("%lld%lld%lld", &l, &r, &v);
				while (lnk[l] != lnk[r]) {
					if (dep[lnk[l]] < dep[lnk[r]]) swap(l, r);
					updmul(1, n, dfn[lnk[l]], dfn[l], v, 1);
					l = fa[lnk[l]];
				}
				updmul(1, n, dfn[lnk[l]], (dep[l] > dep[r] ? dfn[l] : dfn[r]), v, 1);
				break;
			}
			case 2: {
				int p, v;
				scanf("%lld%lld", &p, &v);
				updadd(1, n, dfn[p], dfn[p] + siz[p] - 1, v, 1);
				break;
			}
			case 3: {
				int p, v;
				scanf("%lld%lld", &p, &v);
				updmul(1, n, dfn[p], dfn[p] + siz[p] - 1, v, 1);
				break;
			}
		}
	}
	for (int i = 1; i <= n; i++) {
		int tnum = getpoint(1, n, dfn[i], 1);
		if (i != 1) ans = max(ans, query(tnum));
		push(tnum);
	}
	printf("%lld", ans);
	return 0;
}

