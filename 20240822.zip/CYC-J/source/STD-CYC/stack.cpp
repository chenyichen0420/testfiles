#include<bits/stdc++.h>
using namespace std;
struct node {
	char s[6];
	node(char si[6]) {
		memcpy(s, si, sizeof s);
	}
};
int n, vl; char s[6]; stack<int>v; 
stack<list<node> >ls; list<node>emp;
signed main() {
	freopen("stack.in","r",stdin);
	freopen("stack.out","w",stdout);
	ios::sync_with_stdio(0);
	cin >> n;
	while (n--) {
		if (cin >> s, s[1] == 'u') {
			cin >> s >> vl;
			if (ls.empty() || v.top() != vl) ls.push(emp),v.push(vl);
			ls.top().push_back(node(s));
		}
		else {
			puts(ls.top().front().s);
			ls.top().pop_front();
			if (ls.top().empty()) ls.pop(),v.pop();
		}
	}
	return 0;
}
