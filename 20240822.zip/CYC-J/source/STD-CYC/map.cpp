#include<bits/stdc++.h>
using namespace std;
inline int read() {
	int r = 0; char c = getchar();
	while (c < '0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar();
	return r;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar(x % 10 ^ 48);
	return;
}
inline void writi(int args) {
	write(args); putchar(10);
}
vector<int>son[1000005];
int n, m, fa[1000005][22], rt, lg[1000005], dep[1000005], a, b, cf[1000005];
inline void dfs(int pos) {
	dep[pos] = dep[fa[pos][0]] + 1;
	for (int i = 1; i <= lg[dep[pos]]; ++i)
		fa[pos][i] = fa[fa[pos][i - 1]][i - 1];
	for (int i = 0; i != son[pos].size(); ++i)
		if (son[pos][i] != fa[pos][0]) dfs(son[pos][i]);
}
inline int getlca(int lp, int rp) {
	if (lp == rp) return lp;
	if (dep[lp] < dep[rp]) swap(lp, rp);
	while (dep[lp] > dep[rp]) lp = fa[lp][lg[dep[lp] - dep[rp]] - 1];
	if (lp == rp) return lp;
	for (int k = lg[dep[lp]] - 1; ~k; k--)
		if (fa[lp][k] != fa[rp][k]) lp = fa[lp][k], rp = fa[rp][k];
	return fa[lp][0];
}
inline void dss(int pos) {
	for (int i = 0; i != son[pos].size(); ++i)
		if (son[pos][i] != fa[pos][0])
			dss(son[pos][i]), cf[pos] += cf[son[pos][i]];
}
#define int long long
inline int qpow(int b){
	if(b==0) return 1;
	int tmp=1,a=2,p=9324853;
	while(b){
		if(b&1) tmp*=a,tmp%=p;
		a*=a; a%=p; b>>=1;
	}
	return tmp;
}
#undef int
int main() {
	freopen("map.in","r",stdin);
	freopen("map.out","w",stdout);
	n = read(); m = read();
	for (int i = 1; i <= n; ++i)
		son[fa[i][0] = read()].emplace_back(i),
		lg[i] = lg[i - 1] + (i == 1ll << lg[i - 1]);
	for (int i = 1; i <= n; ++i) if (!fa[i][0]) { dfs(rt = i); break; }
	for (int i = 1; i <= m; ++i) {
		int lc = getlca(a = read(), b = read());
		cf[a]++, cf[b]++; cf[lc]--, cf[fa[lc][0]]--;
	}
	dss(rt);
	for (int i = 1; i <= n; ++i) writi(qpow(cf[i]));
	return 0;
}
