#include<bits/stdc++.h>
using namespace std;
inline int read() {
	int r = 0; char c = getchar();
	while (c < '0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar();
	return r;
}
inline void write(const int& x) {
	if (x > 26) write(x / 27);
	putchar(x % 27 + 'a' - 1);
	return;
}
struct node {
	int s, v;
	node(int si = 0, int vi = 0) :s(si), v(vi) {};
	friend bool operator<(const node& l, const node& r) {
		return (l.v != r.v ? l.v < r.v : l.s > r.s);
	}
}; priority_queue<node>pq; int qt, cn;
int n, v, s; char c[5]; bitset<4569770>inq;
int str[3000005]; bitset<3000008>vis;
inline int tint() {
	int tmp = 0;
	for (int i = 0; i != strlen(c); ++i)
		tmp *= 27, tmp += c[i] - 'a' + 1;
	return tmp;
}
signed main() {
	freopen("prq.in","r",stdin);
	freopen("prq.out","w",stdout);
	n = read();
	for (int p = 1; p <= n; ++p)
		if (scanf("%s", c) && c[0] == 'u') {
			scanf("%s", c); v = read(); s = tint();
			if (inq[s]) puts("I");
			else {
				puts("O"); inq[s] = 1;
				str[++cn] = s;
				pq.push(node(cn, v));
			}
		}
		else if (c[1] == 'i') {
			while (vis[pq.top().s]) pq.pop();
			int ps = pq.top().s; pq.pop();
			vis[ps] = 1; write(str[ps]);
			putchar('\n');
			inq[str[ps]] = 0;
		}
		else {
			while (vis[++qt]);
			vis[qt] = 1; write(str[qt]);
			putchar('\n');
			inq[str[qt]] = 0;
		}
}
