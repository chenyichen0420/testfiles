#include<bits/stdc++.h>
using namespace std;
#define int long long
inline int read() {
	int r = 0; char c = getchar();
	while (c < '0' || c>'9') c = getchar();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar();
	return r;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar(x % 10 ^ 48);
	return;
}
int n,m,a,b,qs[1000005];unsigned sm[1000005];
signed main(){
	freopen("pair.in","r",stdin);
	freopen("pair.out","w",stdout);
	ios::sync_with_stdio(0);
	n=read(); m=read();
	for(int i=1;i<=n;++i)
		a=read(),
		sm[i]=sm[i-1]+a,
		qs[i]=qs[i-1]+a*a;
	while(m--){
		a=read(),b=read();
		int tp1,tp2;
		tp2=(b-a+1)*(b-a);
		if(!tp2){
			puts("0");
			continue;
		}
		tp1=(sm[b]-sm[a-1])*1ll*(sm[b]-sm[a-1]);
		tp1-=qs[b]-qs[a-1];
		int tmp=__gcd(tp1,tp2);
		tp1/=tmp,tp2/=tmp;
		if(tp2==1) write(tp1),putchar('\n');
		else write(tp1),putchar('/'),write(tp2),putchar('\n');
	}
} 
