#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 0;
int n, m, s, t, ans, mxf;
struct SSP {
	struct node { int p, f, v; }tmp;
	vector<node>e; vector<int>h[405];
	inline void ins(int l, int r, int f, int v) {
		h[l].emplace_back(e.size());
		tmp.p = r; tmp.f = f; tmp.v = v;
		e.emplace_back(tmp);
		h[r].emplace_back(e.size());
		tmp.p = l; tmp.f = 0; tmp.v = -v;
		e.emplace_back(tmp);
	}
	int d[405]; bool vis[405];
	inline bool spfa() {
		memset(d, 0x0f, sizeof d);
		queue<int>q; q.emplace(s); vis[s] = 1; d[s] = 0;
		while (q.size()) {
			int np = q.front(); q.pop(); vis[np] = 0;
			for (int i : h[np]) {
				node& sp = e[i];
				if (sp.f && d[sp.p] > d[np] + sp.v)
					if (d[sp.p] = d[np] + sp.v, !vis[sp.p])
						vis[sp.p] = 1, q.emplace(sp.p);
			}
		}
		return d[t] <= 1e12;
	}
	int th[405];
	inline int dfs(int p, int a) {
		if (p == t || !a) return a;
		int ret = 0, f; vis[p] = 1;
		for (int& i = th[p];i != h[p].size();++i) {
			node& sp = e[h[p][i]];
			if (sp.f && d[sp.p] == d[p] + sp.v && !vis[sp.p]) {
				f = dfs(sp.p, min(a, sp.f));
				if (!f) d[sp.p] = 0x0f0f0f0f0f0f0f0f;
				ret += f; a -= f; sp.f -= f;
				e[h[p][i] ^ 1].f += f; mxf += f * sp.v;
				if (!a) break;
			}
		}
		vis[p] = 0; return ret;
	}
	inline int micmaxf() {
		while (spfa())
			memset(th, 0, sizeof th),
			ans += dfs(s, 1e8);
		return ans;
	}
}ssp;
signed main() {
	if (online)
		freopen("run.in", "r", stdin),
		freopen("run.out", "w", stdout);
	//4s - 64M
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1, l, r, v;i <= m;++i)
		cin >> l >> r >> v, ssp.ins(l, r + n, 1, v);
	for (int i = 1;i <= n;++i) ssp.ins(i + n, i, 1, 0);
	s = 1; t = n * 2;
	cout << ssp.micmaxf() << " ";
	cout << mxf << endl;
}
