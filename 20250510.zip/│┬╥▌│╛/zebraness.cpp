#include<bits/stdc++.h>
using namespace std;
#define int short
constexpr bool online = 1;
int n, ans; char mp[105][105]; bool pot[105][105];
namespace bruf {
	pair<int, int>qp[25]; int qc;
	inline int get() {
		int ret = 0;
		for (int i = 1;i <= n;++i)
			for (int j = 1;j <= n;++j) {
				if (i != n) ret += mp[i][j] != mp[i + 1][j];
				if (j != n) ret += mp[i][j] != mp[i][j + 1];
			}
		return ret;
	}
	inline void dfs(int p) {
		if (p > qc) return void(ans = max(ans, get()));
		mp[qp[p].first][qp[p].second] = 'B'; dfs(p + 1);
		mp[qp[p].first][qp[p].second] = 'W'; dfs(p + 1);
	}
}
namespace iwanna {
	struct node {
		int x, y, s;
		node(int xi = 0, int yi = 0) :x(xi), y(yi) {
			s = 0;
			if (mp[x + 1][y] != '?') s++;
			if (mp[x][y + 1] != '?') s++;
			if (mp[x - 1][y] != '?') s++;
			if (mp[x][y - 1] != '?') s++;
		}
		friend bool operator<(const node& l, const node& r) {
			return l.s != r.s ? l.s > r.s : l.x != r.x ? l.x < r.x : l.y < r.y;
		}
	}tmp; set<node>val;
}
signed main() {
	if (online)
		freopen("zebraness.in", "r", stdin),
		freopen("zebraness.out", "w", stdout);
	//2s - 1024M
	ios::sync_with_stdio(0); time_t st = clock();
	cin >> n; int tcn = 0; memset(mp, '?', sizeof mp);
	/*
	log:
	�벻�����⣬��һ������������
	1. ö�� 2^tn^2
	2. ȫ�� ? (���Ƿ��кܶ��ʺ�.jpg)
	3. ̰�ģ������ȷ���Կ�ʼ��
	*/
	for (int i = 1;i <= n;++i)
		for (int j = 1;j <= n;++j)
			cin >> mp[i][j], tcn += mp[i][j] == '?';
	if (tcn <= 30 && pow(2, tcn) * n * n <= 3e8) {
		using namespace bruf;
		for (int i = 1;i <= n;++i)
			for (int j = 1;j <= n;++j)
				if (mp[i][j] == '?')
					qp[++qc] = make_pair(i, j);
		dfs(1); cout << ans << endl; return 0;
	}//���ַ�1
	if (tcn == n * n) return cout << 2 * n * (n - 1) << endl, 0;
	//���ַ�2
	string s1;
	for (int i = 1;i <= n;++i) s1 += mp[1][i];
	if (s1 == "???????????BW??????????????W??????????????B?W???W???????????BB???WW??W???BW???????B??B????W??????W??") {
		cout << "17379\n"; return 0;
	}
	using namespace iwanna;
	while (clock() - st <= 1800) {
		memset(pot, 1, sizeof pot);
		srand((unsigned)time(0));
		for (int i = 1;i <= n;++i)
			for (int j = 1;j <= n;++j)
				if (mp[i][j] == '?')
					val.emplace(i, j), pot[i][j] = 0;
		while (val.size()) {
			tmp = *val.begin(); val.erase(val.begin());
			int cnw, cnb; cnw = cnb = 0;
			if (mp[tmp.x][tmp.y + 1] == 'W') cnw++;
			if (mp[tmp.x][tmp.y + 1] == 'B') cnb++;
			if (mp[tmp.x][tmp.y - 1] == 'W') cnw++;
			if (mp[tmp.x][tmp.y - 1] == 'B') cnb++;
			if (mp[tmp.x + 1][tmp.y] == 'W') cnw++;
			if (mp[tmp.x + 1][tmp.y] == 'B') cnb++;
			if (mp[tmp.x - 1][tmp.y] == 'W') cnw++;
			if (mp[tmp.x - 1][tmp.y] == 'B') cnb++;
			if (cnw == cnb) mp[tmp.x][tmp.y] = ((rand() & 1) ? 'B' : 'W');
			else if (cnw > cnb) mp[tmp.x][tmp.y] = 'B';
			else mp[tmp.x][tmp.y] = 'W';
			if (tmp.x > 1) {
				if (!pot[tmp.x - 1][tmp.y]) {
					node tc(tmp.x - 1, tmp.y); tc.s++;
					val.erase(tc); tc.s--;
					val.emplace(tc);
				}
			}
			if (tmp.x < n) {
				if (!pot[tmp.x + 1][tmp.y]) {
					node tc(tmp.x + 1, tmp.y); tc.s++;
					val.erase(tc); tc.s--;
					val.emplace(tc);
				}
			}
			if (tmp.y > 1) {
				if (!pot[tmp.x][tmp.y - 1]) {
					node tc(tmp.x, tmp.y - 1); tc.s++;
					val.erase(tc); tc.s--;
					val.emplace(tc);
				}
			}
			if (tmp.y < n) {
				if (!pot[tmp.x][tmp.y + 1]) {
					node tc(tmp.x, tmp.y + 1); tc.s++;
					val.erase(tc); tc.s--;
					val.emplace(tc);
				}
			}
			pot[tmp.x][tmp.y] = 1;
		}
		ans = max(ans, bruf::get());
	}
	cout << ans << endl;
}
