#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 0;
int n, s, t, v, ans; char l, r;
struct dinic {
	struct node { int p, f; }tmp;
	vector<node>e; vector<int>h[128];
	inline void ins(int l, int r, int f) {
		h[l].emplace_back(e.size());
		tmp.p = r; tmp.f = f;
		e.emplace_back(tmp);
		h[r].emplace_back(e.size());
		tmp.p = l; tmp.f = 0;
		e.emplace_back(tmp);
	}
	int d[128]; bool vis[128];
	inline bool bfs() {
		queue<int>q; memset(vis, 0, sizeof vis);
		q.emplace(s); d[s] = vis[s] = 1;
		while (q.size()) {
			int np = q.front(); q.pop();
			for (int i : h[np]) {
				node& sp = e[i];
				if (sp.f && !vis[sp.p])
					vis[sp.p] = 1, q.emplace(sp.p),
					d[sp.p] = d[np] + 1;
			}
		}
		return vis[t];
	}
	int th[128];
	inline int dfs(int p, int a) {
		if (p == t || !a) return a;
		int ret = 0, f;
		for (int& i = th[p];i != h[p].size();++i) {
			node& sp = e[h[p][i]];
			if (sp.f && d[sp.p] == d[p] + 1) {
				f = dfs(sp.p, min(sp.f, a));
				if (!f) d[sp.p] = -1;
				sp.f -= f; e[h[p][i] ^ 1].f += f;
				ret += f; a -= f; if (!a) break;
			}
		}
		return ret;
	}
	inline int maxflow() {
		while (bfs())
			memset(th, 0, sizeof th),
			ans += dfs(s, 1e8);
		return ans;
	}
}din;
int main() {
	if (online)
		freopen("wip.in", "r", stdin),
		freopen("wip.out", "w", stdout);
	//1s - 125M
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1;i <= n;++i)
		cin >> l >> r >> v, din.ins(l, r, v);
	s = 'A'; t = 'Z'; cout << din.maxflow() << endl;
}
