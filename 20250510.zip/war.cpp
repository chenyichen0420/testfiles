#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 1;
int n, m, a[55], b[55], s, t, ans, c[55][55], sa;
struct SSP {
	struct node { int p, f; }tmp;
	vector<node>e; vector<int>h[105];
	inline void ins(int l, int r, int f) {
		h[l].emplace_back(e.size());
		tmp.p = r; tmp.f = f;
		e.emplace_back(tmp);
		h[r].emplace_back(e.size());
		tmp.p = l; tmp.f = 0;
		e.emplace_back(tmp);
	}
	int d[105]; bool vis[105];
	inline bool bfs() {
		queue<int>q; memset(vis, 0, sizeof vis);
		q.emplace(s); d[s] = vis[s] = 1;
		while (q.size()) {
			int np = q.front(); q.pop();
			for (int i : h[np]) {
				node& sp = e[i];
				if (sp.f && !vis[sp.p])
					vis[sp.p] = 1, q.emplace(sp.p),
					d[sp.p] = d[np] + 1;
			}
		}
		return vis[t];
	}
	int th[105];
	inline int dfs(int p, int a) {
		if (p == t || !a) return a;
		int ret = 0, f;
		for (int& i = th[p];i != h[p].size();++i) {
			node& sp = e[h[p][i]];
			if (sp.f && d[sp.p] == d[p] + 1) {
				f = dfs(sp.p, min(sp.f, a));
				if (!f) d[sp.p] = -1;
				sp.f -= f; e[h[p][i] ^ 1].f += f;
				ret += f; a -= f; if (!a) break;
			}
		}
		return ret;
	}
	inline int maxflow() {
		while (bfs())
			memset(th, 0, sizeof th),
			ans += dfs(s, 1e8);
		return ans;
	}
	inline void clear(int sz) {
		for (int i = 1;i <= sz;++i) h[i].clear();
		e.clear();
	}
}din;
inline bool check(double lin) {
	din.clear(t + 2); ans = 0;
	for (int i = 1;i <= m;++i)
		for (int j = 1;j <= n;++j)
			if (c[i][j]) din.ins(i, j + m, a[j]);
	for (int i = 1;i <= n;++i) din.ins(i + m, t, a[i]);
	for (int i = 1;i <= m;++i) din.ins(s, i, b[i] * lin);
	return din.maxflow() == sa;
}
signed main() {
	if (online)
		freopen("war.in", "r", stdin),
		freopen("war.out", "w", stdout);
	//1s - 125M
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1;i <= n;++i)
		cin >> a[i], a[i] *= 1e5, sa += a[i];
	for (int i = 1;i <= m;++i) cin >> b[i], b[i] *= 1e5;
	for (int i = 1;i <= m;++i)
		for (int j = 1;j <= n;++j) cin >> c[i][j];
	s = n + m + 1; t = n + m + 2;
	double l = 0, r = 1e9, mid;
	while (r - l > 1e-10) {
		mid = (l + r) / 2;
		if (check(mid)) r = mid;
		else l = mid;
	}
	printf("%.6lf", l);
}
