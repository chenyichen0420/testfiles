#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 0;
int n, a[5005], m, k[5005], v, an[5005], mk;
inline int gcd(int a, int b) {
	if (b == 0) return a;
	return gcd(b, a % b);
}
signed main() {
	if (online)
		freopen("algebraic.in", "r", stdin),
		freopen("algebraic.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 0; i != n; ++i) cin >> a[i]; cin >> m;
	for (int i = 1; i <= m; ++i)
		cin >> k[i], mk = max(mk, k[i] / gcd(k[i], n));
	if (mk <= 1) {
		sort(a, a + n); reverse(a, a + n);
		for (int i = 1; i <= m; ++i) {
			int k = ::k[i]; memset(an, 0, sizeof an); v = 0;
			if (k == 0) {
				for (int i = 0; i != n; ++i) v += a[i] * a[i];
				cout << v << endl; continue;
			}
			if (k == 1) {
				an[0] = a[0];
				for (int j = 1, k = n - 1, l = 1; l != n; ++l)
					if (l & 1) an[k] = a[l], k--;
					else an[j] = a[l], j++;
			}
			else {
				int idx = 0;
				for (int p = 0; p != k; ++p) {
					an[p] = a[idx]; idx++;
					for (int l = p + k, r = p + n - k; idx != (p + 1) * n / k; ++idx)
						if (idx & 1) an[l] = a[idx], l += k;
						else an[r] = a[idx], r -= k;
				}
			}
			for (int i = 0; i != n; ++i)
				v += an[i] * an[(i + k) % n];
			cout << v << endl;
		}
	}//5,6; 20pts
	if (n <= 10) {
		for (int j = 1; j <= m; ++j) {
			sort(a, a + n); v = 0;
			do {
				mk = 0;
				for (int i = 0; i != n; ++i)
					mk += a[i] * a[(i + k[j]) % n];
				v = max(v, mk);
			} while (next_permutation(a, a + n));
			cout << v << endl;
		}
	}//1; 10pts
}
