#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 0;
int n, l[100005], r[100005];
long double ans;
inline long double gexp(int al, int ar, int bl, int br) {
	if (ar <= bl) return 0; if (al >= br) return 1;
	if (al <= bl && bl <= ar && ar <= br) {
		return (long double)(ar - bl) * (ar - bl) / (br - bl) / (ar - al) / 2;
	}
	if (bl <= al && al <= br && br <= ar) {
		return ((long double)(br - al) * (br - al) / (br - bl) / (ar - al) / 2 + (long double)(ar - br) / (ar - al) + (long double)(al - bl) / (br - bl) - (long double)(ar - br) / (ar - al) * (al - bl) / (br - bl));
	}
	if (al <= bl && ar >= br) {
		return ((long double)(br - bl) * (br - bl) / (br - bl) / (ar - al) / 2 + (long double)(ar - br) / (ar - al));
	}
	if (bl <= al && br >= ar) {
		return ((long double)(ar - al) * (ar - al) / (ar - al) / (br - bl) / 2 + (long double)(al - bl) / (br - bl));
	}
	return -1;
}
signed main() {
	if (online)
		freopen("exams.in", "r", stdin),
		freopen("exams.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n;
	for (int i = 1; i <= n; ++i)
		cin >> l[i] >> r[i];
	for (int i = 1; i <= n; ++i) {
		ans = 1;
		for (int j = 1; j <= n; ++j)
			if (i != j) {
				long double id = gexp(l[j], r[j], l[i], r[i]);
				//cerr << j << " win " << i << ": " << id << endl;
				assert(id != -1); ans += id;
			}
		printf("%.8Lf\n", ans);
	}
}
/*
hack: 
3
1 3
2 3
2 4
*/
