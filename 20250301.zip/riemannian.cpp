#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 0;
constexpr int mod = 998244353;
int t, n, ana, anb;
struct node {
	int ata, atb, bta, btb, ada, adb;
	node() { atb = btb = ata = bta = ada = adb = 0; }
}rec,wt[100005]; bool prewd[100005];
inline node ret(int p) {
	if (p <= 1e5 && prewd[p]) return wt[p];
	node ret, tmp = ret(p >> 1); bool moad = p&1;
	ret.ata = (tmp.ata * tmp.ata + tmp.atb * tmp.bta) % mod;
	ret.bta = (tmp.bta * tmp.btb + tmp.bta * tmp.ata) % mod;
	ret.ada = (tmp.ada * tmp.ata + tmp.adb * tmp.bta + tmp.ada) % mod;
	ret.atb = (tmp.atb * tmp.ata + tmp.atb * tmp.btb) % mod;
	ret.btb = (tmp.btb * tmp.btb + tmp.bta * tmp.atb) % mod;
	ret.adb = (tmp.ada * tmp.atb + tmp.adb * tmp.btb + tmp.adb) % mod;
	if (moad) {
		node rep = ret;
		ret.ada = (rep.adb * 2 + 1) % mod;
		ret.ata = (rep.atb * 2) % mod;
		ret.bta = (rep.btb * 2) % mod;
		ret.adb = (2 * rep.adb + rep.ada + 2) % mod;
		ret.atb = (rep.atb * 2 + rep.ata) % mod;
		ret.btb = (rep.btb * 2 + rep.bta) % mod;
	}
	return ret;
}
signed main() {
	if (online)
		freopen("riemannian.in", "r", stdin),
		freopen("riemannian.out", "w", stdout);
	ios::sync_with_stdio(0);
	node rett;
	rett.ada = 1; rett.adb = 2;
	rett.ata = 0; rett.atb = 1;
	rett.bta = 2; rett.btb = 2;
	wt[1]=rett; prewd[1]=1;
	for(int i=2;i<=1e5;++i)
		wt[i]=ret(i), prewd[i]=1;
	for (cin >> t; t; t--) {
		cin >> n; rec = ret(n);
		ana ^= rec.ada; anb ^= rec.adb;
	}
	cout << ana << " " << anb << endl;
}
