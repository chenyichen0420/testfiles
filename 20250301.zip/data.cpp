#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen(R"(riemannian.in)","w",stdout);
	ios::sync_with_stdio(0);
	cout<<"1200000\n";
	for(int i=1;i<=1200000;++i){
		cout<<(long long)(1e12)<<endl;
	}
	return 0;
}
