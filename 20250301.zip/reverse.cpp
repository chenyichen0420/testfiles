#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 0;
constexpr int mod = 998244353;
int t, n, m, a[22], b[22], ans, mit[22];
vector<int>cn;
inline void get(int p) {
	for (int i = 0; i != cn.size(); ++i)
		if (p >> i & 1) reverse(a + 1, a + cn[i] + 1);
	for (int i = 1; i <= n; ++i)
		if (a[i] < mit[i]) {
			memcpy(mit, a, sizeof mit);
			break;
		}
		else if (a[i] > mit[i]) break;
	for (int i = cn.size() - 1; i != -1; --i)
		if (p >> i & 1) reverse(a + 1, a + cn[i] + 1);
}
signed main() {
	if (online)
		freopen("reverse.in", "r", stdin),
		freopen("reverse.out", "w", stdout);
	ios::sync_with_stdio(0);
	for (cin >> t; t; t--) {
		cin >> n >> m;
		memset(a,0,sizeof a); memset(b,0,sizeof b);
		for (int i = 1; i <= n; ++i) cin >> a[i];
		for (int j = 1; j <= m; ++j) cin >> b[j];
		sort(b + 1, b + m + 1); cn.clear();
		memset(mit, 0x3f, sizeof mit); 
		for (int i = 1, j = 1; i <= n; ++i)
			if (i == b[j]) j++;
			else cn.emplace_back(i);
		for (int i = 0; i != 1ll << cn.size(); ++i) get(i);
		ans = 0;
		for (int i = 1, j = 1; i <= n; ++i, j = j * 37 % mod)
			ans = (ans + j * mit[i]) % mod;
		cout << ans << endl;
	}
}
