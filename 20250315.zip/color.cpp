#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 1;
constexpr int mod = 998244353, hm = 1e9 + 7;
vector<int>nsn[505], son[505];
int n, m, h[505], ny[505];
inline int cmp(int l, int r) {
	return h[l] < h[r];
}
inline void tfa(int p, int f) {
	for (int sp : nsn[p])
		if (sp != f) tfa(sp, p),
			son[p].emplace_back(sp);
}
inline void hashv(int p) {
	h[p] = 1;
	for (int sp : son[p]) hashv(sp);
	sort(son[p].begin(), son[p].end(), cmp);
	for (int sp : son[p])
		h[p] = (h[p] * 131 + h[sp]) % mod;
}
inline int cvl(int a, int b) {
	if (a < b) return 0;
	int ret = 1;
	for (int i = 0;i != b;++i)
		ret = ret * (a - i) % mod,
		ret = ret * ny[i + 1] % mod;
	return ret;
}
inline int dfs(int p) {
	map<int, int>cnt, fp, ans; int ret = 1;
	for (int sp : son[p])
		cnt[h[sp]]++, fp[h[sp]] = sp;
	for (pair<int, int>sp : fp)
		ans[sp.first] = dfs(sp.second);
	for (pair<int, int>sp : cnt) {
		//hash Ϊ sp.first ������������ sp.second ��
		//������������ ans[sp.first] �ֱ��ʲ�ͬ�ķ���
		int tmp = 0, pv = ans[sp.first];
		for (int i = 1;i <= sp.second;++i)
			tmp = (tmp + cvl(sp.second - 1, i - 1) * cvl(pv, i)) % mod;
		ret = ret * tmp % mod;
	}
	return ret * m % mod;
}
inline int qpow(int a, int b = mod - 2, int p = mod) {
	int ret = 1;
	for (;b;b >>= 1, a = a * a % p)
		(b & 1) && (ret = ret * a % p);
	return ret;
}
signed main() {
	if (online)
		freopen("color.in", "r", stdin),
		freopen("color.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1, l, r;i != n;++i)
		cin >> l >> r,
		nsn[l].emplace_back(r),
		nsn[r].emplace_back(l),
		ny[i] = qpow(i);
	tfa(1, 0); hashv(1);
	cout << dfs(1) << endl;
}
