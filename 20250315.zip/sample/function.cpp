#include<bits/stdc++.h>

using namespace std;

const int MAXN = 15010;
#define REP(i, a, b) for ( int i = (a), _end_ = (b); i <= _end_; ++ i ) 

int n, m, it = 1;
int a[MAXN];
int X[MAXN], Y[MAXN], now;

int read() {
	int a = 0, f = 1;
	char c = getchar();
	while (!isdigit(c) && c != 'x') {
		if (c == '-') f = -1;
		c = getchar();
	}
	while (isdigit(c) || c == 'x') {
		if(c == 'x') {
			a = -1;
			c = getchar();
			continue;
		}
		a = a * 10 + c - 48;
		c = getchar();
	}
	return a * f;
}

void out1(int pos)
{
	if ( a[pos] == -1 ) printf("s(s(x))");
	else 
	{
		if ( a[pos] == 1 ) printf("%d", a[pos]);
		else if ( a[pos] <= 3 ) printf("s(%d)", a[pos]);
		else printf("s(s(%d))", a[pos]);
	}
}

void print(int l, int r)
{
	if ( l > r ) return ; 
	printf("s(s(s(s(s(s(s(");
	REP(i, l, r) 
	{
		if ( a[i] == -1 ) printf("x");
		else printf("%d", a[i]);
		if ( i < r ) printf("+");
	}
	printf(")))))))");
}

void FindK(int k)
{
	printf("(");
	REP(i, 1, k)
	{
		out1(now);
		if ( i < k ) printf("+");
		now ++;
	}
	printf(")");
}

void Get2()
{
	if ( a[now] == 2 ) { printf("%d", 2); ++ now; return ; } 
	if ( a[now] >= 4 && a[now] < 9 ) { printf("s(%d)", a[now]); ++ now; return ; } 
	printf("(");
	out1(now ++);	
	printf("+");
	out1(now ++);
	printf(")");
}

void Get2K(int k)
{
	if ( k == 0 ) out1(now ++);
	else
	{
		REP(j, 1, k)
		{
			if ( j != 1 ) printf("*");
			Get2();
		}
	}
}


void GetK(int k)
{
	if ( k == 0 ) 
	{
		printf("(");
		out1(now ++);
		printf("-");
		out1(now ++);
		printf(")");
		return ;
	}

	bool ok = false;
	printf("(");
	REP(i, 0, 30) if ( (k >> i) & 1 ) 
	{
		if ( ok == true ) printf("+");
		Get2K(i);
		ok = true;
	}
	printf(")");
}

void FindX()
{
	int beg = now;
	while ( a[now] != -1 ) ++ now;
	print(beg, now - 1);
	if ( beg > now - 1 ) printf("x");
	else printf("*x");
	++ now;
}

void FindXK(int k)
{
	printf("(");
	FindX();
	printf("-");
	FindK(k);
	printf(")");
}

void IfXK(int k)
{
	int cnt = 0;
	printf("s(s(s(s(s(s(s(");
	REP(i, 1, 9) if ( i != k ) 
	{
		++ cnt;
		FindXK(i);
		if ( cnt < 8 ) printf("*");
	}
	printf(")))))))");
}

void outfk()
{
	printf("(");
	out1(now ++);
	printf("-");
	Get2();
	printf(")");
}

signed main() {
	freopen("function.in","r",stdin); 
	freopen("functoin.out","w",stdout); 
	n = read();
	for(int i = 1; i <= n; ++i) a[i] = read();
	m = read();
	for(int i = 1; i <= m; ++i) scanf("%d%d", &X[i], &Y[i]);


	now = 1;

	printf("(");
	REP(i, 1, m)
	{
		printf("(");
		IfXK(X[i]);
		printf("*");
		if ( Y[i] < 0 )  
		{
			Y[i] = -Y[i];
			outfk();
			printf("*");
		}
		GetK(Y[i]);
		printf(")");
		if ( i < m ) printf("+");
	}
	printf(")");

	printf("*");
	print(now, n);

	return 0;
}

