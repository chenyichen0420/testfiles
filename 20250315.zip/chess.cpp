#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 1;
int n, ans; bool vis[130]; pair<int, int>ps[130];
bool ext[15][15];
inline bool hs(int i, int j) {
	if (i < 1 || i>n * 2 || j < 1 || j>n * 2) return 0;
	if (ext[i][j]) return 1; return 0;
}
int dx[] = { 2,2,1,1,1,1,1,0,0,-1,-1,-1,-1,-1,-2,-2 };
int dy[] = { -1,1,-2,-1,0,1,2,-1,1,-2,-1,0,1,2,-1,1 };
inline bool check() {
	memset(ext, 0, sizeof ext);
	for (int i = 1;i <= n * n * 4;++i)
		if (vis[i]) ext[ps[i].first][ps[i].second] = 1;
	for (int i = 1;i <= n * 2;++i)
		for (int j = 1;j <= n * 2;++j)
			if (ext[i][j])
				for (int k = 0;k != 16;++k)
					if (hs(i + dx[k], j + dy[k]))
						return 0;
	return 1;
}
inline void dfs(int p, int d) {
	if (d == n * n) {
		if (check()) ans++;
		return;
	}
	if (p == n * n * 4 + 1) return;
	for (int i = p;i <= n * n * 4;++i)
		vis[i] = 1, dfs(i + 1, d + 1), vis[i] = 0;
}
signed main() {
	if (online)
		freopen("chess.in", "r", stdin),
		freopen("chess.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n;
	if (n == 1) return cout << "4\n", 0;
	if (n == 2) return cout << "25\n", 0;
	if (n == 3) return cout << "120\n", 0;
	for (int i = 1;i <= n << 1;++i)
		for (int j = 1;j <= n << 1;++j)
			ps[(i - 1) * (n << 1) + j] = make_pair(i, j);
	dfs(1, 0); cout << ans << endl;
}
