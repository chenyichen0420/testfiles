#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 0;
int n, m; char a[15005];
signed main() {
	if (online)
		freopen("function.in", "r", stdin),
		freopen("function.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1;i <= n;++i) cin >> a[i];
	if (cin >> m, !m) {
		cout << a[1];
		for (int i = 2;i <= n;++i) cout << '+' << a[i];
		return 0;
	}
	cout << "No Answer\n";
}
