#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 0;
constexpr int N = 1e9;
unsigned int x = 123456789, y = 362436069;
unsigned int n, m, z, a[10000005], f[10000005];
long long ans, ant;
unsigned int gen(){
	unsigned int t;
	x ^= x << 16; x ^= x >> 5; x ^= x << 1;
	t = x; x = y; y = z; z = t ^ x ^ y;
	return z % N + 1;
}
inline int find(int p) {
	return f[p] != p ? f[p] = find(f[p]) : p;
}
signed main() {
	if (online)
		freopen("change.in", "r", stdin),
		freopen("change.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n >> m >> z; f[n + 1] = n + 1;
	for (int i = 1; i <= n; ++i)
		a[i] = gen(), f[i] = i;
	for (int i = 1; i <= m; ++i){
		int l = gen() % n + 1, r = gen() % n + 1;
		if (l > r) swap(l, r); ans = 0;
		while (1) {
			l = find(l); if (l > r) break;
			ans += a[l]; f[l] = l + 1;
		}
		ant ^= ans;
	}
	cout << ant << endl; //8:34 passed big
}
//10 10 2448275055
//562797736
