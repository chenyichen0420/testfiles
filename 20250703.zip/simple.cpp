#include<bits/stdc++.h>
using namespace std;
constexpr bool online=1;
struct node{ int t,x,y,v,p; }q[200005];
int n,o,a,b,c,d,qc,ac,ans[200005];
struct tree_array{
	int v[500005];
	inline void ins(int p,int t){
		do v[p]+=t; while((p+=p&-p)<=n);
	}
	inline int que(int p){
		int t=0; do t+=v[p]; while(p&=p-1); return t;
	}
}ta;
inline bool cmp(const node&l,const node&r){
	return l.x!=r.x?l.x<r.x:l.y<r.y;
}
inline bool cpp(const node&l,const node&r){
	return l.p<r.p;
}
inline void cdq(int l,int r){
	if(l==r) return;
	int mid=l+r>>1,i,j; cdq(l,mid);
	sort(q+l,q+mid+1,cmp);
	sort(q+mid+1,q+r+1,cmp);
	for(i=l,j=mid+1;j<=r;++j){
		while(i<=mid&&q[i].x<=q[j].x) {
			if(!q[i].t) ta.ins(q[i].y,q[i].v);
			i++;
		}
		if(q[j].t) ans[q[j].v]+=q[j].t*ta.que(q[j].y);
	}
	while(--i>=l) if(!q[i].t) ta.ins(q[i].y,-q[i].v);
	sort(q+mid+1,q+r+1,cpp); cdq(mid+1,r);
}
signed main(){
	if(online)
		freopen("simple.in","r",stdin),
		freopen("simple.out","w",stdout);
	ios::sync_with_stdio(0); cin>>n;
	memset(q,0,sizeof q);
	memset(ans,0,sizeof ans);
	memset(ta.v,0,sizeof ta.v);
	while(cin>>o,o!=3)
		if(cin>>a>>b>>c,o==1) q[++qc]={0,a,b,c,0};
		else cin>>d,a--,b--,++ac,q[++qc]={1,a,b,ac,0};
	for(int i=1;i<=qc;++i) q[i].p=i;
	cdq(1,qc); ac=qc=0; cin.seekg(0); cin>>n;
	while(cin>>o,o!=3)
		if(cin>>a>>b>>c,o==1) q[++qc]={0,a,b,c,0};
		else cin>>d,a--,b--,++ac,q[++qc]={-1,a,d,ac,0};
	for(int i=1;i<=qc;++i) q[i].p=i;
	cdq(1,qc); ac=qc=0; cin.seekg(0); cin>>n;
	while(cin>>o,o!=3)
		if(cin>>a>>b>>c,o==1) q[++qc]={0,a,b,c,0};
		else cin>>d,a--,b--,++ac,q[++qc]={-1,c,b,ac,0};
	for(int i=1;i<=qc;++i) q[i].p=i;
	cdq(1,qc); ac=qc=0; cin.seekg(0); cin>>n;
	while(cin>>o,o!=3)
		if(cin>>a>>b>>c,o==1) q[++qc]={0,a,b,c,0};
		else cin>>d,a--,b--,++ac,q[++qc]={1,c,d,ac,0};
	for(int i=1;i<=qc;++i) q[i].p=i;
	cdq(1,qc); for(int i=1;i<=ac;++i) cout<<ans[i]<<endl;
}
