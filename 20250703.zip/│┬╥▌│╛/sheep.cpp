#include<bits/stdc++.h>
using namespace std;
constexpr bool online=1;
#define bk(v) (v / sz)
int n,a[200005],l[200005],t[200005],br[200005],sz,m;
inline int que(int p){
	int ret=0;
	while(p<n) ret+=t[p],p=l[p];
	return ret;
}
inline void chg(int p){
	for(int i=min(n-1,(p+1)*sz-1);i>=0&&bk(i)==p;--i)
		if(i+a[i]>=br[i]) l[i]=i+a[i],t[i]=1;
		else l[i]=l[i+a[i]],t[i]=t[i+a[i]]+1;
}
signed main(){
	if(online)
		freopen("sheep.in","r",stdin),
		freopen("sheep.out","w",stdout);
	ios::sync_with_stdio(0); cin>>n; sz=sqrt(n);
	for(int i=0;i!=n;++i) cin>>a[i];
	for(int i=0;i!=n;++i) br[i]=min(n,(bk(i)+1)*sz);
	for(int i=n-1;i>=0;--i)
		if(i+a[i]>=br[i]) l[i]=i+a[i],t[i]=1;
		else l[i]=l[i+a[i]],t[i]=t[i+a[i]]+1;
	cin>>m;
	for(int i=1,o,l;i<=m;++i)
		if(cin>>o>>l,o&1) cout<<que(l)<<endl;
		else cin>>a[l],chg(bk(l));
	return 0;
} 
