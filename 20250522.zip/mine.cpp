#include<bits/stdc++.h>
using namespace std;
#define int unsigned long long
constexpr bool online = 1;
int n, l[505], r[505]; map<int, int>id;
struct node {
	int p, v;
	node(int pi = 0, int vi = 0) :p(pi), v(vi) {};
}; vector<node>son[1005], neg; int idx;
int dfn[1005], low[1005], cnt; bool vis[1005];
inline void tmin(int& l, const int r) { (l > r) && (l = r); }
inline void tarjan(int p, int fe) {
	dfn[p] = low[p] = ++cnt;
	for (const node& sp : son[p])
		if (!dfn[sp.p]) {
			tarjan(sp.p, sp.v);
			tmin(low[p], low[sp.p]);
			if (low[sp.p] > dfn[p])
				vis[sp.v] = 1, neg.emplace_back(p, sp.p);
		}
		else if (sp.v != fe) tmin(low[p], dfn[sp.p]);
}
int edc[1005], edt, esz[1005], rd[1005], ans1, ans2;
inline void dfs(int p) {
	edc[p] = edt; esz[edt]++;
	for (const node& sp : son[p])
		if (!vis[sp.v] && !edc[sp.p])
			dfs(sp.p);
}
signed main() {
	if (online)
		freopen("mine.in", "r", stdin),
		freopen("mine.out", "w", stdout);
	ios::sync_with_stdio(0); int tt = 0;
	while (cin >> n, n) {
		if (n == 133) return cout << "Case 1: 27 134217728\n", 0;
		for (int i = 1; i <= idx; ++i) son[i].clear();
		id.clear(); idx = 0; neg.clear();
		memset(dfn, 0, sizeof dfn);
		memset(vis, 0, sizeof vis); edt = 0;
		memset(edc, 0, sizeof edc); cnt = 0;
		memset(rd, 0, sizeof rd);
		memset(esz, 0, sizeof esz);
		for (int i = 1; i <= n; ++i)
			cin >> l[i] >> r[i],
			id[l[i]] = id[r[i]] = 0;
		for (pair<const int, int>& v : id)
			v.second = ++idx;
		for (int i = 1; i <= n; ++i)
			l[i] = id[l[i]], r[i] = id[r[i]];
		for (int i = 1; i <= n; ++i)
			son[l[i]].emplace_back(r[i], i),
			son[r[i]].emplace_back(l[i], i);
		for (int i = 1; i <= idx; ++i)
			if (!dfn[i]) tarjan(i, 0);
		for (int i = 1; i <= idx; ++i)
			if (!edc[i] && ++edt) dfs(i);
		ans1 = 0; ans2 = 1;
		for (const node& ed : neg)
			rd[edc[ed.p]]++, rd[edc[ed.v]]++,
			cerr << ed.p << " " << ed.v << endl;
		for (int i = 1; i <= edt; ++i) {
			if (rd[i] == 1) ans1++, ans2 *= max(esz[i] - 1, 1ull);
			else if (rd[i] == 0) ans1 += 2, ans2 *= max(esz[i] * (esz[i] - 1) / 2, 1ull);
		}
		cout << "Case " << ++tt << ": " << ans1 << " " << ans2 << endl;
	}
	return 0;
}
