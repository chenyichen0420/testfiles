#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 1;
int n, m, s[105], v[105], d[105];
vector<int>son[105]; stack<int>t;
int dfn[105], low[105], cnt, scc[105], sct;
inline void tmin(int& l, const int r) { (l > r) && (l = r); }
inline void tarjan(int p) {
	dfn[p] = low[p] = ++cnt; t.emplace(p);
	for (int sp : son[p])
		if (!dfn[sp]) tarjan(sp), tmin(low[p], low[sp]);
		else if (!scc[sp]) tmin(low[p], dfn[sp]);
	if (dfn[p] == low[p] && ++sct) {
		while (t.top() != p) scc[t.top()] = sct, t.pop();
		scc[t.top()] = sct, t.pop();
	}
}
vector<int>tsn[105];
int dp[105][505], rd[105], ns[105], nv[105], tmp[105][505];
inline void tmax(int& l, const int r) { (l < r) && (l = r); }
inline void dps(int p, int f) {
	if (ns[p] <= m) dp[p][ns[p]] = nv[p];
	for (int sp : tsn[p])
		if (sp != f) {
			dps(sp, p);
			memcpy(tmp[p], dp[p], sizeof tmp[0]);
			memset(dp[p], 0xcf, sizeof dp[0]);
			for (int i = 0; i <= m; ++i)
				for (int j = 0; j + i <= m; ++j)
					tmax(dp[p][i + j], tmp[p][i] + dp[sp][j]);
		}
	dp[p][0] = 0;
}
signed main() {
	if (online)
		freopen("software.in", "r", stdin),
		freopen("software.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1; i <= n; ++i) cin >> s[i];
	for (int i = 1; i <= n; ++i) cin >> v[i];
	for (int i = 1; i <= n; ++i)
		if (cin >> d[i], d[i]) son[d[i]].emplace_back(i);
	for (int i = 1; i <= n; ++i)
		if (!dfn[i]) tarjan(i);
	for (int i = 1; i <= n; ++i) {
		for (int j : son[i])
			if (scc[i] != scc[j])
				tsn[scc[i]].emplace_back(scc[j]),
				rd[scc[j]]++;
		ns[scc[i]] += s[i];
		nv[scc[i]] += v[i];
	}
	scc[0] = sct + 1;
	for (int i = 1; i <= sct; ++i)
		if (!rd[i]) tsn[scc[0]].emplace_back(i);
	memset(dp, 0xcf, sizeof dp);
	dps(scc[0], 0);
	for (int i = 1; i <= m; ++i)
		tmax(dp[scc[0]][0], dp[scc[0]][i]);
	cout << dp[scc[0]][0] << endl;
	return 0;
}
/*
4 7
3 4 3 3
1 4 7 2
1 1 0 1
*/
