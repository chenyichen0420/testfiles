#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 0;
#define int long long
#ifdef _MSC_VER
#define __gcd _Gcd
#endif
int t, mod, n, m, r, ans;
signed main() {
	if (online)
		freopen("b.in", "r", stdin),
		freopen("b.out", "w", stdout);
	ios::sync_with_stdio(0);
	for (cin >> t >> mod; t; t--) {
		cin >> n >> m;
		for (int i = n - 1; i > 0; i--) n *= i;
		for (int i = m - 1; i > 0; i--) m *= i;
		for (int i = 1; i <= n; ++i)
			if (__gcd(i, m) == 1) ans++;
		cout << ans % mod << endl;
	}
}
