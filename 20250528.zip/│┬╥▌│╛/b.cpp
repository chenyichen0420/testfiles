#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
#define int long long
int t, mod, n, m, jcn, jcm , p[1000005], pc[10000005], cnt, ans; bool isp[10000005];
inline int qpow(int a, int b, int p) {
	int ret = 1;
	for (; b; b >>= 1, a = a * a % p)
		(b & 1) && (ret = ret * a % p);
	return ret;
}
inline void tmod(int& l, const int r) { l = (l % mod + mod) % mod; }
signed main() {
	if (online)
		freopen("b.in", "r", stdin),
		freopen("b.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> t >> mod; isp[1] = 1;
	for (int i = 2; i <= 1e7; ++i) {
		if (!isp[i]) p[++cnt] = i;
		for (int j = 1; j <= cnt && i * p[j] <= 1e7; ++j)
			if (isp[i * p[j]] = 1, i% p[j] == 0) break;
	}
	for (int i = pc[0] = 1; i <= 1e7; ++i)
		if (!isp[i]) pc[i] = pc[i - 1] * qpow(i, mod - 2, mod) % mod * (i - 1) % mod;
		else pc[i] = pc[i - 1];
	while(t--) {
		cin >> n >> m;
		for (int i = jcn = 1; i <= n; ++i) jcn = jcn * i % mod;
		for (int i = jcm = 1; i <= m; ++i) jcm = jcm * i % mod;
		ans = jcn * pc[m] % mod;
		cout << ans << endl;
	}
}
