#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
#define int long long
struct node {
	int p, v;
	node(int pi = 0, int vi = 0) :p(pi), v(vi) {};
	friend bool operator<(const node& l, const node& r) {
		return l.v > r.v;
	}
}tmp; vector<node>son[100005]; priority_queue<node>pq;
int n, a[4], mv, d[100005]; bool vis[100005];
inline int solve(int p) {
	int ret = 0;
	for (int i = 0; i != mv; ++i)
		if (d[i] <= 1e18 && d[i] <= p)
			ret += (p - d[i]) / mv + 1;
	return ret;
}
signed main() {
	if (online)
		freopen("a.in", "r", stdin),
		freopen("a.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n >> a[1] >> a[2] >> a[3];
	mv = min({ a[1],a[2],a[3]});
	for (int i = 0; i != mv; ++i)
		for (int j = 1; j <= 3; ++j)
			if (a[j] % mv) son[i].emplace_back((i + a[j]) % mv, a[j]);
	memset(d, 0x0f, sizeof d);
	pq.emplace(0, d[0] = 0);
	while (pq.size()) {
		tmp = pq.top(); pq.pop();
		if (vis[tmp.p]) continue;
		vis[tmp.p] = 1;
		for (const node& sp : son[tmp.p])
			if (d[sp.p] > d[tmp.p] + sp.v)
				pq.emplace(sp.p, d[sp.p] = d[tmp.p] + sp.v);
	}
	cout << solve(n - 1) << endl;
}
