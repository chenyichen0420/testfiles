#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, m, mix, miy; char c[100005][80];
int vx[85], vy[100005], cp[100005], ap[100005];
namespace hash2 { int vx[85], vy[100005], cp[100005]; }
constexpr int p = 37, p2 = 131, md = 1e9 + 7;
mt19937 mt(time(0));
inline int random(int l, int r) {
	int tmp;
	do tmp = mt() % (r - l + 1) + l;
	while (tmp<l || tmp>r);
	return tmp;
}
inline int qpow(int a, int b = md - 2, int p = md) {
	int ret = 1;
	for (; b; b >>= 1, a = a * a % p)
		(b & 1) && (ret = ret * a % p);
	return ret;
}
inline bool cmpx(int ll, int lr, int rl, int rr) {
	for (int i = ll, j = rl; i <= lr && j <= rr; ++i, ++j)
		if (vx[i] != vx[j] || hash2::vx[i] != hash2::vx[j]) return 0;
	return 1;
}
inline bool cmpy(int ll, int lr, int rl, int rr) {
	if (rl > rr) return 1;
	if (lr - ll == rr - rl) {
		int vll = (vy[lr] - vy[ll - 1] * cp[lr - ll + 1] % md + md) % md;
		int vlr = (vy[rr] - vy[rl - 1] * cp[rr - rl + 1] % md + md) % md;
		int vll2 = (hash2::vy[lr] - hash2::vy[ll - 1] * hash2::cp[lr - ll + 1] % md + md) % md;
		int vlr2 = (hash2::vy[rr] - hash2::vy[rl - 1] * hash2::cp[rr - rl + 1] % md + md) % md;
		return vll == vlr && vll2 == vlr2;
	}//ȫ�ģ�ֱ������Ԫ
	lr = ll + rr - rl;
	int vll = (vy[lr] - vy[ll - 1] * cp[lr - ll + 1] % md + md) % md;
	int vlr = (vy[rr] - vy[rl - 1] * cp[rr - rl + 1] % md + md) % md;
	int vll2 = (hash2::vy[lr] - hash2::vy[ll - 1] * hash2::cp[lr - ll + 1] % md + md) % md;
	int vlr2 = (hash2::vy[rr] - hash2::vy[rl - 1] * hash2::cp[rr - rl + 1] % md + md) % md;
	return vll == vlr && vll2 == vlr2;
}
signed main() {
	ios::sync_with_stdio(0);
	cin >> n >> m; cp[0] = 1;
	for (int i = 1; i <= 1e5; ++i) cp[i] = cp[i - 1] * p % md;
	for (int i = 1; i <= 1e5; ++i) hash2::cp[i] = hash2::cp[i - 1] * p2 % md;
	for (int i = 1; i <= 1e5; ++i) ap[i] = random(3, p - 1);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			cin >> c[i][j], c[i][j] -= 'A';
	for (int i = 0; i <= n; ++i) vy[i] = 1;
	for (int j = 0; j <= m; ++j) vx[j] = 1;
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			vx[j] = (vx[j] + ((c[i][j] + ap[i]) * cp[i])) % md,
			vy[i] = (vy[i] + ((c[i][j] + ap[j]) * cp[j])) % md,
			hash2::vx[j] = (hash2::vx[j] + ((c[i][j] + ap[i]) * hash2::cp[i])) % md,
			hash2::vy[i] = (hash2::vy[i] + ((c[i][j] + ap[j]) * hash2::cp[j])) % md;
	for (int i = 1; i <= n; ++i) vy[i] = (vy[i - 1] * p + vy[i]) % md;
	for (int i = 1; i <= n; ++i) hash2::vy[i] = hash2::vy[i - 1] * hash2::vy[i] % md;
	cerr << vy[130] << ' ' << vy[1] << endl;
	for (int i = 1; i <= m; ++i) {
		int ll = 1, lr = i, rl = i + 1, rr = 2 * i;
		bool cn = 1;
		while (cn) {
			rr = min(rr, m);
			cn &= cmpx(ll, lr, rl, rr);
			if (rr == m) break;
			rl += i, rr += i;
		}
		if (cn) { mix = i; break; }
	}
	cerr << mix << endl;
	for (int i = 1; i <= n; ++i) {
		int ll = 1, lr = i, rl = i + 1, rr = 2 * i;
		bool cn = 1;
		while (cn) {
			rr = min(rr, n);
			cn &= cmpy(ll, lr, rl, rr);
			if (rr == n) break;
			rl += i, rr += i;
		}
		if (cn) { miy = i; break; }
	}
	cerr << miy << endl;
	cout << mix * miy << endl;
}
