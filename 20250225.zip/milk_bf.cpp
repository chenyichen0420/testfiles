#include<bits/stdc++.h>
using namespace std;
char c[100005][80]; int n,m;
inline bool cmp(int l,int r){
	for(int i=0;i<=129;++i)
		for(int j=1;j<=75;++j)
			if(c[l+i][j]!=c[r+i][j]&&r+i<=1e5){
				cerr<<"diff at "<<l+i<<","<<j<<" and "<<r+i<<","<<j<<endl;
				return 1;
			}
}
int main() {
	ios::sync_with_stdio(0);
	cin>>n>>m;
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			cin>>c[i][j];
	for(int i=130;i<=1e5;i+=129)
		if(cmp(1,i)) return 1;
	return 0;
}
