#include<bits/stdc++.h>
using namespace std;
//#define int long long
int n, p[300005][26], cnt; bool ed[300005];
string s[300005]; vector<string>ans;
vector<int>son[26]; int rd[26]; queue<int>q;
inline void tnum(string& s) {
	for (char& c : s) c -= 'a';
}
inline void tchr(const string& s) {
	for (char c : s) cout << (char)(c + 'a');
	cout << endl;
}
inline void ins(const string& s) {
	for (int i = 0, lp = 0; i != s.size(); ++i) {
		if (p[lp][s[i]]) lp = p[lp][s[i]];
		else lp = p[lp][s[i]] = ++cnt;
		if (i == s.size() - 1) ed[lp] = 1;
	}
}
inline void clear() {
	for (int i = 0; i != 26; ++i)
		son[i].clear(), rd[i] = 0;
}
inline bool check() {
	for (int i = 0; i != 26; ++i)
		if (!rd[i]) q.emplace(i);
	while (q.size()) {
		int tp = q.front(); q.pop();
		for (int sp : son[tp])
			if (!--rd[sp]) q.emplace(sp);
	}
	for (int i = 0; i != 26; ++i)
		if (rd[i]) return 0;
	return 1;
}
inline bool prob(const string& s) {
	clear();
	for (int i = 0, lp = 0; i != s.size(); ++i) {
		for (int j = 0; j != 26; ++j)
			if (j != s[i] && p[lp][j])
				son[s[i]].emplace_back(j), rd[j]++;
		lp = p[lp][s[i]]; if (ed[lp] && i != s.size() - 1) return 0;
	}
	return check();
}
signed main() {
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1; i <= n; ++i)
		cin >> s[i], tnum(s[i]), ins(s[i]);
	for (int i = 1; i <= n; ++i)
		if (prob(s[i])) ans.emplace_back(s[i]);
	cout << ans.size() << endl;
	for (const string& s : ans) tchr(s);
}
