#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
#define int long long
int n, a[100005], tc, sv;
signed main() {
	if (online)
		freopen("boxes.in", "r", stdin),
		freopen("boxes.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1; i <= n; ++i) 
		cin >> a[i], sv += a[i];
	tc = n * (n + 1) / 2;
	if (sv % tc) return cout << "NO\n", 0;
	sv /= tc; a[n + 1] = a[1];
	for (int i = 2; i <= n; ++i) {
		int pv = a[i] - a[i - 1];
		int av = sv - pv;
		if (av < 0 || av % n) return cout << "NO\n", 0;
	}
	cout << "YES\n";
}
