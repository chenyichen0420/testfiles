#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
#define int long long
int n, k, a[20], t[20], f;
inline int ty1() {
	memset(t, 0, sizeof t); f = 0;
	for (int i = 0;; ++i) {
		int mv = 1e9, mp = 0;
		for (int j = 1; j <= n; ++j)
			if (i % (2 * a[j]) < a[j])
				if (t[j] < mv) mv = t[j], mp = j;
		if (mp && ++t[mp] == k)
			if (++f == n) return i + 1;
	}
}
inline int ty2() {
	memset(t, 0, sizeof t); f = 0;
	for (int i = 0;; ++i) {
		int mv = 1e9, mp = 0;
		for (int j = n; j >= 1; --j)
			if (i % (2 * a[j]) < a[j])
				if (t[j] < mv) mv = t[j], mp = j;
		if (mp && ++t[mp] == k)
			if (++f == n) return i + 1;
	}
}
signed main() {
	if (online)
		freopen("medals.in", "r", stdin),
		freopen("medals.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n >> k;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	sort(a + 1, a + n + 1);
	cout << min(ty1(), ty2()) << endl;
	return 0;
}
