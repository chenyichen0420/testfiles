#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 1;
int n, m, a[50005]; vector<int>son[50005];
int sz[50005], hs[50005], f[50005], idc;
inline void spl_lnk(int p, int fa) {
	f[p] = fa; sz[p] = 1;
	for (int sp : son[p]) if (sp != fa)
		spl_lnk(sp, p), sz[p] += sz[sp],
		(sz[sp] > sz[hs[p]]) && (hs[p] = sp);
}
int lnk[50005], d[50005], na[50005], nid[50005];
inline void down_he(int p, int t) {
	lnk[p] = t; d[p] = d[f[p]] + 1; na[nid[p] = ++idc] = a[p];
	if (!hs[p]) return; down_he(hs[p], t);
	for (int sp : son[p]) if (!lnk[sp]) down_he(sp, sp);
}
struct val {
	int mi, mx, mv;
	inline void set(int v) { mi = mx = v; mv = 0; }
	inline void add(int v) { mi += v, mx += v; }
	inline val operator+(const val& r) {
		val ret = { 0 };
		ret.mv = max({ mv,r.mv, r.mx - mi });
		ret.mi = min(mi, r.mi);
		ret.mx = max(mx, r.mx);
		return ret;
	}
}vl, vr;
struct seg_tree_dn {
	struct node { int l, r, t; val v; }re[50005 << 2];
	inline void pup(int p) { re[p].v = re[p << 1].v + re[p << 1 | 1].v; }
	inline void pud(int p) {
		int& t = re[p].t; if (!t) return;
		re[p << 1 | 1].v.add(t);
		re[p << 1 | 1].t += t;
		re[p << 1].v.add(t);
		re[p << 1].t += t; t = 0;
	}
	inline void build(int l, int r, int p) {
		re[p].l = l; re[p].r = r;
		if (l == r) return re[p].v.set(na[l]);
		build((l + r >> 1) + 1, r, p << 1 | 1);
		build(l, (l + r >> 1), p << 1); pup(p);
	}
	inline void ins(int l, int r, int v, int p) {
		if (re[p].l >= l && re[p].r <= r)
			return re[p].t += v, re[p].v.add(v);
		pud(p);
		if (l <= re[p << 1].r) ins(l, r, v, p << 1);
		if (r > re[p << 1].r) ins(l, r, v, p << 1 | 1);
		pup(p);
	}
	inline val que(int l, int r, int p) {
		if (re[p].l >= l && re[p].r <= r) return re[p].v;
		if (pud(p), r <= re[p << 1].r) return que(l, r, p << 1);
		if (l > re[p << 1].r) return que(l, r, p << 1 | 1);
		return que(l, r, p << 1) + que(l, r, p << 1 | 1);
	}
}sgtd;
struct seg_tree_up {
	struct node { int l, r, t; val v; }re[50005 << 2];
	inline void pup(int p) { re[p].v = re[p << 1 | 1].v + re[p << 1].v; }
	inline void pud(int p) {
		int& t = re[p].t; if (!t) return;
		re[p << 1 | 1].v.add(t);
		re[p << 1 | 1].t += t;
		re[p << 1].v.add(t);
		re[p << 1].t += t; t = 0;
	}
	inline void build(int l, int r, int p) {
		re[p].l = l; re[p].r = r;
		if (l == r) return re[p].v.set(na[l]);
		build((l + r >> 1) + 1, r, p << 1 | 1);
		build(l, (l + r >> 1), p << 1); pup(p);
	}
	inline void ins(int l, int r, int v, int p) {
		if (re[p].l >= l && re[p].r <= r)
			return re[p].t += v, re[p].v.add(v);
		pud(p);
		if (l <= re[p << 1].r) ins(l, r, v, p << 1);
		if (r > re[p << 1].r) ins(l, r, v, p << 1 | 1);
		pup(p);
	}
	inline val que(int l, int r, int p) {
		if (re[p].l >= l && re[p].r <= r) return re[p].v;
		if (pud(p), r <= re[p << 1].r) return que(l, r, p << 1);
		if (l > re[p << 1].r) return que(l, r, p << 1 | 1);
		return que(l, r, p << 1 | 1) + que(l, r, p << 1);
	}
}sgtu;
inline int que(int l, int r) {
	vl.set(0); vr.set(0);
	vl.mi = vr.mi = 1e12;
	while (lnk[l] != lnk[r])
		if (d[lnk[l]] > d[lnk[r]])
			vl = vl + sgtu.que(nid[lnk[l]], nid[l], 1),
			l = f[lnk[l]];
		else
			vr = sgtd.que(nid[lnk[r]], nid[r], 1) + vr,
			r = f[lnk[r]];
	if (d[l] < d[r]) return (vl + sgtd.que(nid[l], nid[r], 1) + vr).mv;
	else return (vl + sgtu.que(nid[r], nid[l], 1) + vr).mv;
}
inline void chg(int l, int r, int v) {
	while (lnk[l] != lnk[r]) {
		if (d[lnk[l]] < d[lnk[r]]) swap(l, r);
		sgtd.ins(nid[lnk[l]], nid[l], v, 1);
		sgtu.ins(nid[lnk[l]], nid[l], v, 1);
		l = f[lnk[l]];
	}
	if (d[l] > d[r]) swap(l, r);
	sgtd.ins(nid[l], nid[r], v, 1);
	sgtu.ins(nid[l], nid[r], v, 1);
}
signed main() {
	if (online)
		freopen("travel.in", "r", stdin),
		freopen("travel.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	for (int i = 1, l, r; i != n; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	spl_lnk(1, 0); down_he(1, 1); cin >> m;
	sgtd.build(1, n, 1); sgtu.build(1, n, 1);
	for (int i = 1, l, r, v; i <= m; ++i)
		cin >> l >> r >> v, chg(l, r, v),
		cout << que(l, r) << endl;
}
