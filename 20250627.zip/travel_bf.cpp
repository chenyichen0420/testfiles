#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
int n, a[105], d[105], f[105], m, ans, mi;
vector<int>p, p2, son[105];
inline void go(int l, int r, int v) {
	p.clear(); p2.clear();
	while (d[l] > d[r]) p.emplace_back(l), a[l] += v, l = f[l];
	while (d[r] > d[l]) p2.emplace_back(r), a[r] += v, r = f[r];
	while (l != r)
		p.emplace_back(l), a[l] += v, l = f[l],
		p2.emplace_back(r), a[r] += v, r = f[r];
	p.emplace_back(l); a[l] += v;
	while (p2.size())
		p.emplace_back(p2.back()),
		p2.pop_back();
}
inline void dfs(int p, int fa) {
	f[p] = fa; d[p] = d[fa] + 1;
	for (int sp : son[p])
		if (sp != fa) dfs(sp, p);
}
signed main() {
	if (online)
		freopen("travel.in", "r", stdin),
		freopen("travel.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	for (int i = 1, l, r; i != n; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	dfs(1, 0); cin >> m;
	for (int i = 1, l, r, v; i <= m; ++i) {
		cin >> l >> r >> v;
		go(l, r, v); ans = 0; mi = 1e9;
		for (int j : p)
			ans = max(ans, a[j] - mi),
			mi = min(mi, a[j]);
		cout << ans << endl;
	}
}
