#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
int n, m, k, f[100005], ans[100005]; set<int>s[100005];
inline int find(int p) {
	return f[p] != p ? f[p] = find(f[p]) : p;
}
inline void merge(int l, int r, int t) {
	l = find(l); r = find(r);
	if (l == r) return;
	if (s[l].size() < s[r].size()) swap(l, r);
	for (int i : s[r])
		if (s[l].count(i)) ans[i] = t;
		else s[l].emplace(i);
	f[r] = l;
}
signed main() {
	if (online)
		freopen("pictionary.in", "r", stdin),
		freopen("pictionary.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n >> m >> k;
	for (int i = 1; i <= n; ++i) f[i] = i;
	for (int i = 1, l, r; i <= k; ++i)
		cin >> l >> r, s[l].emplace(i), s[r].emplace(i);
	for (int i = m; i >= 1; i--)
		for (int j = 2; j * i <= n; ++j)
			merge(i, j * i, m - i + 1);
	for (int i = 1; i <= k; ++i) cout << ans[i] << endl;
}