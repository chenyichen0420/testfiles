#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 1;
int n, m, a[12], o, p;
inline bool iscn(int v) {
	int ret = 0, vp = 1;
	for (int i = 0; i <= n; ++i)
		ret = ret + vp * a[i], vp *= v;
	return ret == 0;
}
inline void get() {
	if (n == 1 && a[1] == 0) {
		cout << "0\n\n";
		return;
	}
	if (n == 1 || n == 2 && a[2] == 0) {
		int ans = -a[0] / a[1];
		if (ans * a[1] + a[0] == 0)
			cout << "1\n" << ans << endl;
		else cout << "0\n\n";
		return;
	}
	if (n == 2) {
		int val = a[1] * a[1] - 4 * a[0] * a[2];
		if (val < 0) {
			cout << "0\n\n";
			return;
		}
		long double delta = sqrt(val);
		long double ans1 = (-a[1] + delta) / (2 * a[2]);
		long double ans2 = (-a[1] - delta) / (2 * a[2]);
		int an1 = ans1, an2 = ans2, cn;
		cn = iscn(an1) + iscn(an2) - (an1 == an2);
		cout << cn << endl;
		if (an1 > an2) swap(an1, an2);
		if (iscn(an1)) cout << an1 << " ";
		if (iscn(an2) && an1 != an2) cout << an2 << " ";
		cout << endl;
	}
}
signed main() {
	if (online)
		freopen("deepseek.in", "r", stdin),
		freopen("deepseek.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 0; i <= n; ++i) cin >> a[i];
	for (int i = 1; i <= m; ++i)
		if (cin >> o, o & 2) get();
		else cin >> p, cin >> a[p];
}
