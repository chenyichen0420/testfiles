#include<bits/stdc++.h>
using namespace std;
#define int __int128
constexpr bool online = 1;
constexpr long long mod = 1e9 + 9;
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar(x % 10 ^ 48);
}
inline void writi(int args) {
	write(args); putchar(10);
}
inline void mad(int& l, const int r) { l = (l + r) % mod; }
int n, m, ans; long long nt, mt;
signed main() {
	if (online)
		freopen("flower.in", "r", stdin),
		freopen("flower.out", "w", stdout);
	ios::sync_with_stdio(0);
	while (cin >> nt >> mt) {
		n = nt; m = mt;
		ans = n * (n + 1) / 2 % mod * (m - 1) % mod;
		n--; m--;
		for (int l = 1, r = 0; l <= n && l <= m; l = r + 1) {
			r = min(n / (n / l), m); int vl = n / l % mod;
			int t = (vl * (vl - 1) >> 1) % mod;
			int s = ((r + l) * (r - l + 1) >> 1) % mod;
			mad(ans, t * s);
			int cl = (n + 1) * (r - l + 1) * vl;
			mad(ans, cl);
			int cr = vl * vl * s % mod;
			mad(ans, mod - cr);
		}
		writi(ans);
	}
	return 0;
}
