#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
inline void write(int v) {
	if (v > 9) write(v / 10);
	putchar(v % 10 ^ 48);
}
inline void write(int v, char c) {
	write(v); putchar(c);
}
struct node {
	int a, b, c;
	node(int x, int y, int z) :a(x), b(y), c(z) {};
	friend bool operator<(const node& l, const node& r) {
		return l.a != r.a ? l.a < r.a : l.b != r.b ? l.b < r.b : l.c < r.c;
	}
}; set<node>hs;
int n, m;
signed main() {
	if (online)
		freopen("building.in", "r", stdin),
		freopen("building.out", "w", stdout);
	ios::sync_with_stdio(0);
	/*
	�������� (i,j,k) ֮��
	(i,j); (j,k); (i,k)
	���� i=j=k ��ֻ��Ҫһ��
	���������ֵ��Ⱦ���Ҫ�������ֻ�һ��
	������ǲ��о���Ҫ������
	������ m �� 1 �� m^3-m ����
	*/
	cin >> n >> m;
	for (int i = 1; i <= m && n > 5; ++i)
		for (int j = 1; j <= m && n > 5; ++j)
			for (int k = 1; k <= m && n > 5; ++k)
				if (i != j && j != k && k != i)
					if (!hs.count(node(i, j, k)))
						write(i, ' '), write(j, ' '), write(k, '\n'),
						write(i, ' '), write(k, ' '), write(j, '\n'),
						write(j, ' '), write(i, ' '), write(k, '\n'),
						write(j, ' '), write(k, ' '), write(i, '\n'),
						write(k, ' '), write(i, ' '), write(j, '\n'),
						write(k, ' '), write(j, ' '), write(i, '\n'),
						hs.insert(node(i, j, k)),
						hs.insert(node(i, k, j)),
						hs.insert(node(j, i, k)),
						hs.insert(node(j, k, i)),
						hs.insert(node(k, i, j)),
						hs.insert(node(k, j, i)),
						n -= 6;
	if (!n) return 0;
	for (int i = 1; i <= m && n > 2; ++i)
		for (int j = 1; j <= m && n > 2; ++j)
			for (int k = 1; k <= m && n > 2; ++k)
				if (i == j || j == k || k == i)
					if (i != j || j != k || k != i)
						if (!hs.count(node(i, j, k)))
							write(i, ' '), write(j, ' '), write(k, '\n'),
							write(j, ' '), write(k, ' '), write(i, '\n'),
							write(k, ' '), write(i, ' '), write(j, '\n'),
							hs.insert(node(i, j, k)),
							hs.insert(node(j, k, i)),
							hs.insert(node(k, i, j)),
							n -= 3;
	if (!n) return 0;
	for (int i = 1; i <= n; ++i)
		write(i, ' '), write(i, ' '), write(i, '\n');
}
