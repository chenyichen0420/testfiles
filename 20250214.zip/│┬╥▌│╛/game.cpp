#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
int a; double b, c, d, e;
long double dp[10005], ans, dp2[10005], ant;
signed main() {
	if (online)
		freopen("game.in", "r", stdin),
		freopen("game.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> a >> b >> c >> d >> e;
	if (e == 0) {
		dp[0] = 1;
		for (int i = 1; i <= 1e4; ++i)
			if (i < a)
				dp[i] = dp[i - 1] * (1 - d),
				ans += i * dp[i - 1] * d;
			else
				dp[i] = dp[i - 1] * max(1 - d - (i - a + 1) * b, 0.0),
				ans += i * dp[i - 1] * min(1.0, d + (i - a + 1) * b);
		printf("%.5Lf\n", ans);
		return 0;
	}
	dp[0] = 1; dp2[0] = 1;
	for (int i = 1; i <= 1e4; ++i)
		if (i < a)
			dp[i] = dp[i - 1] * (1 - d),
			ans += i * dp[i - 1] * d;
		else
			dp[i] = dp[i - 1] * max(1 - d - (i - a + 1) * b, 0.0),
			ans += i * dp[i - 1] * min(1.0, d + (i - a + 1) * b);
	for (int i = 1; i <= 1e4; ++i) {
		if (i < a)
			dp2[i] = dp2[i - 1] * (1 - d),
			ant += dp2[i - 1] * d * (1 - c) * i,
			ant += dp2[i - 1] * d * c * (ans + i);
		else
			dp2[i] = dp2[i - 1] * max(1 - d - (i - a + 1) * b, 0.0),
			ant += dp2[i - 1] * min(1.0, d + (i - a + 1) * b) * (1 - c) * i,
			ant += dp2[i - 1] * min(1.0, d + (i - a + 1) * b) * c * (ans + i);
	}
	printf("%.5Lf\n", ant);
}
