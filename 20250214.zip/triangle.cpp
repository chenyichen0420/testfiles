#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 0;
double lv[3], lnx;
struct pos {
	double x, y;
	pos(int xi = 0, int yi = 0) :x(xi), y(yi) {};
}cp[3];
struct line {
	int k, b;
	line(int ki = 0, int bi = 0) :k(ki), b(bi) {};
}lp[3];
inline void getcp(line l, line r, int id) {
	int ct = l.k - r.k, cn = r.b - l.b;
	cp[id].x = double(cn) / ct;
	cp[id].y = cp[id].x * l.k + l.b;
}
inline double getdis(pos l, pos r) {
	return sqrt((l.x - r.x) * (l.x - r.x) + (l.y - r.y) * (l.y - r.y));
}
int n, a[405], b[405], ans, lar; set<pair<int, int>>ps;
signed main() {
	if (online)
		freopen("triangle.in", "r", stdin),
		freopen("triangle.out", "w", stdout);
	ios::sync_with_stdio(0);
	for (int i = 0; i != 3; ++i)
		cin >> lp[i].k >> lp[i].b;
	getcp(lp[0], lp[1], 0);
	getcp(lp[2], lp[1], 1);
	getcp(lp[2], lp[0], 2);
	lv[0] = getdis(cp[0], cp[1]);
	lv[1] = getdis(cp[0], cp[2]);
	lv[2] = getdis(cp[1], cp[2]);
	lnx = lv[0] + lv[1] + lv[2]; lnx /= 2;
	printf("%.3lf\n", sqrt(lnx * (lnx - lv[0]) * (lnx - lv[1]) * (lnx - lv[2])));
	cin >> n;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	for (int i = 1; i <= n; ++i) cin >> b[i];
	sort(a + 1, a + n + 1);
	sort(b + 1, b + n + 1);
	for (int i = 1; i <= n; ++i) {
		int pl = a[i] - b[1], pr = a[i] + b[1], md, l, r;
		l = pl; r = pr;
		while (l != r) {
			md = l + r >> 1;
			if (md + b[n] >= a[n]) r = md;
			else l = md + 1;
		}
		int tl = l;
		l = pl; r = pr;
		while (l != r) {
			md = l + r + 1 >> 1;
			if (md - b[n] <= a[n]) l = md;
			else r = md - 1;
		}
		int tr = l;
		ps.emplace(make_pair(tl, tr));
	}
	lar = -1e18 - 5;
	for (pair<int, int>p : ps) {
		if (p.first > p.second) continue;
		if (p.second <= lar) continue;
		if (p.first < lar) p.first = lar + 1;
		ans += p.second - p.first + 1;
		lar = p.second; 
	}
	printf("%lld\n", ans);
}
