#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 0;
inline void write(int v) {
	if (v > 9) write(v / 10);
	putchar(v % 10 ^ 48);
}
inline void write(int v, char c) {
	write(v); putchar(c);
}
struct node {
	bool ext[165][165][165];
	inline bool count(int a,int b,int c){
		return ext[a][b][c];
	}
	inline void insert(int a,int b,int c){
		ext[a][b][c]=1;
	}
}hs;
int n, m;
signed main() {
	if (online)
		freopen("building.in", "r", stdin),
		freopen("building.out", "w", stdout);
	ios::sync_with_stdio(0);
	/*
	�������� (i,j,k) ֮��
	(i,j); (j,k); (i,k)
	���� i=j=k ��ֻ��Ҫһ��
	���������ֵ��Ⱦ���Ҫ�������ֻ�һ��
	������ǲ��о���Ҫ������
	������ m �� 1 �� m^3-m ����
	*/
	cin >> n >> m;
	for (int i = 1; i <= m && n > 5; ++i)
		for (int j = 1; j <= m && n > 5; ++j)
			for (int k = 1; k <= m && n > 5; ++k)
				if (i != j && j != k && k != i)
					if (!hs.count(i, j, k))
						write(i, ' '), write(j, ' '), write(k, '\n'),
						write(i, ' '), write(k, ' '), write(j, '\n'),
						write(j, ' '), write(i, ' '), write(k, '\n'),
						write(j, ' '), write(k, ' '), write(i, '\n'),
						write(k, ' '), write(i, ' '), write(j, '\n'),
						write(k, ' '), write(j, ' '), write(i, '\n'),
						hs.insert(i, j, k),
						hs.insert(i, k, j),
						hs.insert(j, i, k),
						hs.insert(j, k, i),
						hs.insert(k, i, j),
						hs.insert(k, j, i),
						n -= 6;
	if (!n) return 0;
	for (int i = 1; i <= m && n > 2; ++i)
		for (int j = 1; j <= m && n > 2; ++j)
			for (int k = 1; k <= m && n > 2; ++k)
				if (i == j || j == k || k == i)
					if (i != j || j != k || k != i)
						if (!hs.count(i, j, k))
							write(i, ' '), write(j, ' '), write(k, '\n'),
							write(j, ' '), write(k, ' '), write(i, '\n'),
							write(k, ' '), write(i, ' '), write(j, '\n'),
							hs.insert(i, j, k),
							hs.insert(j, k, i),
							hs.insert(k, i, j),
							n -= 3;
	if (!n) return 0;
	for (int i = 1; i <= n; ++i)
		write(i, ' '), write(i, ' '), write(i, '\n');
}
