#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 0;
constexpr int md = 3499999;
constexpr int mxto = 1e6;
int n, a, t[1000005], sm[1000005], mu[1000005];
int p[1000005], cnt, ans; bool isp[1000005];
inline void prec() {
	for (int dp = 1; dp <= mxto; ++dp)
		for (int i = 1; i * dp <= mxto; ++i)
			sm[dp] = (sm[dp] + i * t[i * dp]) % md;
}
inline void liner() {
	mu[1] = 1;
	for (int i = 2; i <= mxto; ++i) {
		if (!isp[i]) p[++cnt] = i, mu[i] = -1;
		for (int j = 1; j <= cnt && i * p[j] <= mxto; ++j) {
			isp[i * p[j]] = 1; mu[i * p[j]] = -mu[i];
			if (i % p[j] == 0) { mu[i * p[j]] = 0; break; }
		}
	}
}
inline int qpow(int a, int b) {
	int ret = 1;
	for (; b; b >>= 1, a = a * a % md)
		(b & 1) && (ret = ret * a % md);
	return ret;
}
inline int get(int v) {
	int ret = 0;
	while (v) ret = ret + v % 10, v /= 10;
	return ret;
}
signed main() {
	if (online)
		freopen("name.in", "r", stdin),
		freopen("name.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1; i <= n; ++i) cin >> a, t[a]++;
	prec(); liner();
	for (int p = 1; p <= mxto; ++p) {
		if (mu[p] != 0)
			for (int d = 1; p * d <= mxto; ++d)
				ans = (ans + d * p * p % md * mu[p] * (sm[d * p] * sm[d * p] % md)) % md;
	}
	for (int i = 1; i <= mxto; ++i)
		ans = (ans - t[i] * i) % md;
	ans = (ans + md) * qpow(2, md - 2) % md;
	cout << ans << endl;
	ans++; int mxv = get(ans);
	for (int i = 2; i != 1e8; ++i)
		mxv = min(mxv, get(ans * i));
	//cout << mxv << endl;
}
