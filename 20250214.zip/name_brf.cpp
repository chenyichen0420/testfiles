#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr int md = 3499999;
signed main(){
	ios::sync_with_stdio(0); 
	int n; cin >> n;
	int a[85] = { 0 }, ans = 0;
	for (int i = 1; i <= n; ++i)
		cin >> a[i];
	for (int i = 1; i <= n; ++i)
		for (int j = i + 1; j <= n; ++j)
			ans += a[i] * a[j] / __gcd(a[i], a[j]),
			ans %= md;
	cout << ans % md << endl;
	return 0;
}
