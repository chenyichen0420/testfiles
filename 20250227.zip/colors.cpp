#include<bits/stdc++.h>
using namespace std;
int n, m, f[200005], c[200005]; set<int>son[200005];
bool dit; vector<int>nt; queue<int>q;
inline int find(int p) {
	return f[p] != p ? f[p] = find(f[p]) : p;
}
inline bool merge(int l, int r) {
	l = find(l), r = find(r);
	if (l == r) return 0;
	if (son[l].size() < son[r].size()) swap(l, r);
	f[r] = l;
	for (int v : son[r]) son[l].emplace(v);
	son[r].clear();
	return 1;
}
signed main() {
	ios::sync_with_stdio(0); cin >> n >> m; 
	for (int i = 1, a, b; i <= m; ++i)
		cin >> a >> b, son[a].emplace(b);
	for (int i = 1; i <= n; ++i) f[i] = i;
	for (int i=1;i<=n;++i){
		if(son[i].size()>1) q.emplace(i);
		son[i].emplace(i); 
	}
	while (q.size()) {
		int i=q.front();q.pop(); nt.clear();
		for (int s : son[i]) nt.emplace_back(find(s));
		nt.erase(unique(nt.begin(), nt.end()), nt.end());
		for (int j = 1; j < nt.size(); ++j)
			dit |= merge(nt[j], nt[0]);
		son[i].clear();
		for (int v : nt) son[i].emplace(v);
	} //Ӳ������
	for(int i=1,v=0;i<=n;++i)
		if(c[find(i)]) cout<<c[f[i]]<<endl;
		else cout<<(c[f[i]]=++v)<<endl; 
}
