#include<bits/stdc++.h>
using namespace std;
#define int long long
int n, m, a[200005], l[200005], r[200005], ans, tns; map<int, int>cnt;
vector<pair<int, int>>vl; vector<int>vc, vs, ts; int tc = 0;
inline int sum(int l, int r) {
	return (l + r) * (r - l + 1) / 2;
}
signed main() {
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1; i <= n; ++i)
		cin >> a[i], cnt[a[i]]++;
	cin >> m;
	for (int i = 1; i <= m; ++i)
		cin >> l[i] >> r[i], cnt[r[i]] += 0;
	for (const pair<int, int>& v : cnt)
		vc.emplace_back(sum(tc + 1, tc + v.second) * v.first),
		vs.emplace_back(v.first * v.second),
		ts.emplace_back(tc + v.second),
		vl.emplace_back(v),
		tc += v.second,
		ans += vc.back();
	for (int i = 1; i != vs.size(); ++i)
		vs[i] += vs[i - 1];
	for (int i = 1; i <= m; ++i)
		if (a[l[i]] < r[i]) {
			pair<int, int>tmp = make_pair(r[i], 0);
			int rp = lower_bound(vl.begin(), vl.end(), tmp) - vl.begin();
			tmp = make_pair(a[l[i]], 0);
			int lp = lower_bound(vl.begin(), vl.end(), tmp) - vl.begin();
			tns = ans - (vs[rp - 1] - vs[lp]);
			tns -= ts[lp] * vl[lp].first;
			tns += vl[rp].first * ts[rp - 1];
			cout << tns << endl;
		}//����ƶ�
		else {
			pair<int, int>tmp = make_pair(r[i], 0);
			int lp = lower_bound(vl.begin(), vl.end(), tmp) - vl.begin();
			tmp = make_pair(a[l[i]], 0);
			int rp = lower_bound(vl.begin(), vl.end(), tmp) - vl.begin();
			tns = ans + (vs[rp - 1] - vs[lp]);
			tns += (ts[lp] + 1) * vl[lp].first;
			tns -= vl[rp].first * (ts[rp - 1] + 1);
			cout << tns << endl;
		}//��ǰ�ƶ�
}
