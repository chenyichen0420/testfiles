#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
#define int long long
int n, m, ans[2005][2005], av;
struct tree_array {
	int v[2005];
	inline int lb(int p) { return p & ~p + 1; }
	inline void ins(int p, int t) {
		do v[p] += t; while ((p += lb(p)) <= 2 * n + 3);
	}
	inline int que(int p) {
		int t = 0; do t += v[p];
		while (p -= lb(p)); return t;
	}
}ta[2005], tc[2005];
signed main() {
	if (online)
		freopen("xor.in", "r", stdin),
		freopen("xor.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1, x, y, l, t; i <= m; ++i) {
		cin >> x >> y >> l >> t;
		int sx = x, sy = y;
		int ex = x + l - 1, ey = y + l - 1;
		ta[sy - sx + 1000].ins(sx, t);
		ta[sy - sx + 1000].ins(ex + 1, -t);
		tc[sy - 1].ins(sx, t);
		tc[sy - 1].ins(ex + 1, -t);
	}
	for (int i = 1; i <= n; ++i) {
		int tv = 0;
		for (int j = n + i - 1; j >= 1; j--) {
			tv += ta[j - i + 1000].que(i);
			tv -= tc[j].que(i);
			(j <= n) && (av ^= tv);
		}
	}
	cout << av << endl;
}
