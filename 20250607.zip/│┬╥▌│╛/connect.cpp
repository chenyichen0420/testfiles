#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
#define int long long
int t, n, a[10005];
bool isp[40005]; int p[40005], cn;
vector<int>son[40005]; int id[40005];
bitset<40008> vis; int sz, ans, ap;
inline void dsz(int p) {
	vis[p] = 1; sz += (p <= n);
	for (int sp : son[p])
		if (!vis[sp]) dsz(sp);
}
signed main() {
	if (online)
		freopen("connect.in", "r", stdin),
		freopen("connect.out", "w", stdout);
	ios::sync_with_stdio(0);
	for (int i = 2; i <= 3e4; ++i) {
		if (!isp[i]) p[++cn] = i;
		for (int j = 1; j <= cn && i * p[j] <= 3e4; ++j)
			if (isp[i * p[j]] = 1, !(i% p[j])) break;
	}
	for (int i = 4, j = 5000; i <= 3e4; ++i)
		if (isp[i]) id[i] = ++j;
	for (cin >> t; t; t--) {
		cin >> n; ans = 1e9;
		for (int i = 1; i <= n; ++i) {
			cin >> a[i];
			for (int j = 1; j * j <= a[i]; ++j)
				if (a[i] % j == 0) {
					if (isp[j])
						son[id[j]].emplace_back(i),
						son[i].emplace_back(id[j]);
					if (isp[a[i] / j] && j * j != a[i])
						son[id[a[i] / j]].emplace_back(i),
						son[i].emplace_back(id[a[i] / j]);
				}
		}
		for (int i = 1; i <= n; ++i) {
			vis.reset(); ap = 0; vis[i] = 1;
			for (int j = 1; j <= n; ++j)
				if (!vis[j]) 
					sz = 0, dsz(j), 
					ap = max(ap, sz);
			ans = min(ans, ap);
		}
		cout << ans << endl;
		for (int i = 1; i <= n; ++i) son[i].clear();
		for (int i = 1; i <= n; ++i) {
			for (int j = 1; j * j <= a[i]; ++j)
				if (a[i] % j == 0) {
					if (isp[j]) son[id[j]].clear();
					if (isp[a[i] / j]) son[id[a[i] / j]].clear();
				}
		}
	}
}
