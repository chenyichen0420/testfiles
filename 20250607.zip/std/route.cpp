vi G[N], vg[N], vec[N], vtn[N];
 ll f[N], sf[N], g[N], h[N], A[N], B[N], tmp[N];
 ll sum, asr;
 int col[N], dfn[N], nod[N], fa[N], siz[N];
 int dep[N], son[N], top[N];
 int seq[N * 2], stk[N], vf[N], csub[N];
 int n, m, q, cnt;
 ll C2(ll n) {
 return n * (n - 1) / 2;
 }
 bool cmp_dfn(int x, int y) {
 return dfn[x] < dfn[y];
 }
 bool in(int u, int v) {
 return dfn[u] <= dfn[v] && dfn[v] < dfn[u] + siz[u];
 }
void dfs1(int u, int f) {
    siz[u] = 1;
    fa[u] = f;
    dep[u] = dep[f] + 1;
    for(int v : G[u]) {
        if(v == f) continue;
        dfs1(v, u);
        siz[u] += siz[v];
        if(siz[v] > siz[son[u]]) son[u] = v;
    }
 }
 void dfs2(int u, int tf) {
    top[u] = tf;
    dfn[u] = ++ cnt;
    nod[cnt] = u;
    if(son[u]) dfs2(son[u], tf);
    for(int v : G[u])
        if(!dfn[v]) dfs2(v, v);
 }
 int LCA(int x, int y) {
    for(; top[x] != top[y]; y = fa[top[y]])
        if(dep[top[x]] > dep[top[y]]) swap(x, y);
    return dep[x] < dep[y] ? x : y;
 }
 void getfg() {
    per(i, n, 2) {
        int u = nod[i];
        f[fa[u]] += f[u];
        g[fa[u]] += g[u];
    }
    rep(i, 1, n) {
        int u = nod[i];
        A[u] = A[fa[u]] - f[u];
        for(int v : G[u]) if(v != fa[u])
            A[u] += f[v], B[u] += f[v];
        g[u] = asr - f[u] - g[u];
        B[u] += g[u] - A[u] * 2;
    }
 }
 void make_vtree(int c) {
    cnt = 0;
    for(int x : vec[c]) seq[++ cnt] = dfn[x];
    sort(seq + 1, seq + cnt + 1);
    rep(i, 2, cnt) seq[++ cnt] = dfn[LCA(nod[seq[i - 1]], nod[seq[i]])];
    sort(seq + 1, seq + cnt + 1);
    cnt = unique(seq + 1, seq + cnt + 1) - seq - 1;
    rep(i, 1, cnt) vtn[c].pb(nod[seq[i]]);
 }
 void getfa(int c) {
    cnt = 0;
 for(int x : vtn[c]) seq[++ cnt] = x;
    int top = 0, u;
    rep(i, 1, cnt) {
        u = seq[i];
        for(; top && !in(stk[top], u); -- top) ;
        vf[u] = stk[top];
        stk[++ top] = u;
    }
 }
 void solve_1(int c) {
    int all = vec[c].size(), u;
    rep(i, 1, cnt) csub[seq[i]] = 0;
    per(i, cnt, 1) {
        u = seq[i];
        csub[u] += col[u] == c;
        f[u] += C2(csub[u]);
        g[u] += 1ll * csub[u] * (all - csub[u]);
        if(vf[u]) {
            csub[vf[u]] += csub[u];
            f[vf[u]] -= C2(csub[u]);
            g[vf[u]] -= 1ll * csub[u] * (all - csub[u]);
        }
    }
 }
 void solve_2(int c) {
    int u, m = vec[c].size();
    ll sumA = 0;
    if(m == 1) return ;
    rep(i, 1, cnt) {
        u = seq[i];
        csub[u] = tmp[u] = 0;
        if(col[u] == c) sumA += A[u];
    }
    per(i, cnt, 1) {
        u = seq[i];
        csub[u] += col[u] == c;
        if(vf[u]) csub[vf[u]] += csub[u];
    }
    rep(i, 2, cnt) {
        u = seq[i];
        tmp[u] = tmp[vf[u]] + B[vf[u]] * (csub[vf[u]] - csub[u]);
    }
    rep(i, 1, cnt) {
        u = seq[i];
        if(col[u] == c) h[u] = tmp[u] + A[u] * (m - 2) + sumA + B[u] * (csub[u] - 
1);
    }
 }
 signed main() {
    freopen("route.in", "r", stdin);
    freopen("route.out", "w", stdout);
    int x, y;
    n = read(); q = read(); m = read();
rep(i, 1, n) vec[col[i] = read()].pb(i); 
rep(i, 1, m) asr += C2(vec[i].size());
 rep(i, 2, n) {
 x = read(); y = read();
 G[x].pb(y); G[y].pb(x);
 }
 dfs1(1, 0); dfs2(1, 1);
 rep(i, 1, m) make_vtree(i);
 rep(i, 1, m) getfa(i), solve_1(i);
 getfg();
 rep(i, 1, m) getfa(i), solve_2(i);
 rep(i, 1, n) sum += h[i];
 sum /= 4;
 printf("%lld\n", sum);
 while(q --) printf("%lld\n", sum - h[read()]);
 return 0;
}
