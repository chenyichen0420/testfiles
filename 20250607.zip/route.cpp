#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
#define int long long
int n, m, k, c[100005], ans; vector<int>son[100005];
inline bool diff(int a, int b, int c, int d) {
	return a != c && a != d && b != c && b != d;
}
namespace brf {
	int dp[55], f[55]; bool vis[55];
	inline void dfs(int p, int f) {
		dp[p] = dp[f] + 1; brf::f[p] = f;
		for (int sp : son[p]) if (sp != f) dfs(sp, p);
	}
	inline bool chk(int a, int b, int c, int d) {
		memset(vis, 0, sizeof vis);
		if (dp[a] < dp[b]) swap(a, b);
		while (dp[a] != dp[b]) vis[a] = 1, a = f[a];
		while (a != b)
			vis[a] = 1, a = f[a],
			vis[b] = 1, b = f[b];
		vis[b] = 1;
		if (dp[c] < dp[d]) swap(c, d);
		while (dp[c] != dp[d])
			if (vis[c]) return 0;
			else vis[c] = 1, c = f[c];
		while (c != d)
			if (vis[c] || vis[d]) return 0;
			else vis[c] = vis[d] = 1,
				c = f[c], d = f[d];
		if (vis[c]) return 0;
		return 1;
	}
}
namespace dynp {
	int sz[10005], bp; bool hbp[10005], app;
	inline void dfs(int p, int f) {
		int t2 = 0, t3 = 0;
		for (int sp : son[p])
			if (sp != f) {
				dfs(sp, p); hbp[p] |= hbp[sp];
				t3 += t2 * sz[sp];
				t2 += sz[p] * sz[sp];
				sz[p] += sz[sp];
			}
		if (p != bp)
			ans -= t3, sz[p]++,
			ans -= t2 * (n - sz[p] - (!hbp[p] && app));
		else hbp[p] = 1;
	}
}
signed main() {
	if (online)
		freopen("route.in", "r", stdin),
		freopen("route.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n >> m >> k;
	for (int i = 1; i <= n; ++i) cin >> c[i];
	for (int i = 1, l, r; i != n; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	if (n <= 50) {
		using namespace brf; dfs(1, 0);
		for (int i = 1; i <= n; ++i)
			for (int j = i + 1; j <= n; ++j)
				if (c[i] == c[j])
					for (int k = 1; k <= n; ++k)
						for (int l = k + 1; l <= n; ++l)
							if (c[k] == c[l])
								if (diff(i, j, k, l))
									ans += chk(i, j, k, l);
		cout << ans / 2 << endl; ans = 0;
		for (int p = 1, t; p <= m; ++p) {
			cin >> t;
			for (int i = 1; i <= n; ++i)
				for (int j = i + 1; j <= n; ++j)
					if (c[i] == c[j] && i != t && j != t)
						for (int k = 1; k <= n; ++k)
							for (int l = k + 1; l <= n; ++l)
								if (c[k] == c[l] && k != t && l != t)
									if (diff(i, j, k, l))
										ans += chk(i, j, k, l);
			cout << ans / 2 << endl; ans = 0;
		}
		return 0; //�ϸ���������˵���� n^6 �ģ�ֻ�ǳ�������ƫС
	}
	if (k == 1) {
		using namespace dynp;
		ans = n * (n - 1) / 2 * (n - 2) / 3 * (n - 3) / 4;
		dfs(1, 1); cout << ans << endl; app = 1;
		for (int i = 1; i <= m; ++i) {
			cin >> bp; ans = n * (n - 1) / 2 * (n - 2) / 3 * (n - 3) / 4;
			dfs(1, 1); cout << ans << endl;
		}
	}//����ͬһ���ˣ����� DP��
	//û������������һ�� hack
}
/*
10 0 1
1 1 1 1 1 1 1 1 1 1
1 2
2 4
3 4
2 5
5 6
8 6
8 9
6 10
6 7
*/
//161 not 171
