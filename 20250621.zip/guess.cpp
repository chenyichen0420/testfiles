#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 1;
string s; int n; vector<int>ps;
inline int qpow(int a, int b) {
	int ret = 1;
	for (; b; b >>= 1, a *= a)
		(b & 1) && (ret *= a);
	return ret;
}
signed main() {
	if (online)
		freopen("guess.in", "r", stdin),
		freopen("guess.out", "w", stdout);
	ios::sync_with_stdio(0); 
	cin >> s;
	if (s.size() <= 12) {
		int k = 0;
		for (const char &c: s) k = k * 10 + c - '0'; 
		for (n = 1;; ++n)
			if (qpow(n, n) == k)
				return cout << n << endl, 0;
	}
	double lgs = s.size() - 1; lgs += log(s[0] - '0') / log(10);
	for (int i = 11;; ++i) {
		double ll = log(i) / log(10);
		ll *= i;
		if (abs(lgs - ll) <= 1) {
			cout << i << endl;
			return 0;
		}
	}
}
