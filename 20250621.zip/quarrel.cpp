#include<bits/stdc++.h>
using namespace std;
vector<int>son[100005];
int n, m, t[100005]; char o; int v; queue<int>q;
int dp[100005], fa[100005][19];
inline void dfs(int p, int f) {
	fa[p][0] = f; dp[p] = dp[f] + 1;
	for (int i = 1; i <= 18; ++i)
		fa[p][i] = fa[fa[p][i - 1]][i - 1];
	for (int sp : son[p]) if (sp != f) dfs(sp, p);
}
inline int lca(int l, int r) {
	if (dp[l] < dp[r]) swap(l, r);
	for (int i = 18; i >= 0; i--)
		if (dp[fa[l][i]] >= dp[r]) l = fa[l][i];
	if (l == r) return l;
	for (int i = 18; i >= 0; i--)
		if (fa[l][i] != fa[r][i])
			l = fa[l][i], r = fa[r][i];
	return fa[l][0];
}
inline int dit(int l, int r) {
	return dp[l] + dp[r] - 2 * dp[lca(l, r)];
}
inline void merge(int& l, int& r, int p) {
	if (!l) return void(l = p);
	if (!r) return void(r = p);
	int dd = dit(l, r), dl = dit(p, l), dr = dit(p, r);
	int dm = max({ dd,dl,dr }); if (dm == dd) return;
	if (dm == dl) return void(r = p);
	if (dm == dr) return void(l = p);
}
struct seg_tree {
	struct node {
		int l, r; vector<int>h;
	}re[500005 << 2];
	inline void build(int l, int r, int p) {
		re[p].l = l; re[p].r = r;
		if (l == r) return;
		build((l + r >> 1) + 1, r, p << 1 | 1);
		build(l, (l + r >> 1), p << 1);
	}
	inline void ins(int cl, int cr, int cv, int p) {
		if (cl <= re[p].l && cr >= re[p].r)
			return void(re[p].h.emplace_back(cv));
		if (cl <= re[p << 1].r) ins(cl, cr, cv, p << 1);
		if (cr > re[p << 1].r) ins(cl, cr, cv, p << 1 | 1);
	}
	inline void solve(int p = 1, int dl = 0, int dr = 0) {
		if (!q.size() || re[p].r < q.front()) return;
		for (int ap : re[p].h) merge(dl, dr, ap);
		if (re[p].l == re[p].r) {
			if (!dl) cout << "-1\n";
			else if (!dr) cout << "0\n";
			else cout << dit(dl, dr) << endl;
			q.pop(); return;
		}
		solve(p << 1, dl, dr); solve(p << 1 | 1, dl, dr);
	}
}sgt;
signed main() {
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1, a, b; i != n; ++i)
		cin >> a >> b,
		son[a].emplace_back(b), 
		son[b].emplace_back(a);
	cin >> m; dfs(1, 0); sgt.build(0, m + 1, 1);
	for (int i = 1; i <= m; ++i)
		if (cin >> o, o != 'C') q.emplace(i);
		else {
			cin >> v;
			if (~t[v])
				sgt.ins(t[v], i, v, 1),
				t[v] = -1;
			else t[v] = i;
		}
	for (int i = 1; i <= n; ++i)
		if (~t[i]) sgt.ins(t[i], m + 1, i, 1);
	sgt.solve();
}
/*
˼·��ʾ������һ���㣬��Զ�����Ϊֱ����
���ŵ������
1.����
2.y->d.l
3.y->d.r
����ɽ⡣
*/
