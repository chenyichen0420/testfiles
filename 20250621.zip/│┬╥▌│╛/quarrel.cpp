#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
vector<int>son[5005]; char o;
int n, m, md[5005], d[5005], ans; bool cn[5005];
inline void dfa(int p, int fa) {
	d[p] = d[fa] + 1;
	if (!cn[p]) md[p] = d[p];
	for (int sp : son[p]) {
		if (sp != fa) {
			dfa(sp, p);
			ans = max(ans, md[p] + md[sp] - 2 * d[p]);
			md[p] = max(md[p], md[sp]);
		}
	}
}
signed main() {
	if (online)
		freopen("quarrel.in", "r", stdin),
		freopen("quarrel.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1, l, r; i <= m; ++i)
		cin >> l >> r,
		son[l].emplace_back(r),
		son[r].emplace_back(l);
	for (int i = 1, p; i <= m; ++i)
		if (cin >> o, o != 'G')
			cin >> p, cn[p] ^= 1;
		else {
			memset(md, -1, sizeof md); ans = -1;
			dfa(1, 0); cout << ans << endl;
		}
}
