#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 1;
int n, a[105], ans, pid[2005], pc, d[305][305], md[305][305];
#ifndef _MSC_VER
#define __popcnt __builtin_popcount
#endif 
signed main() {
	if (online)
		freopen("choose.in", "r", stdin),
		freopen("choose.out", "w", stdout);
	ios::sync_with_stdio(0); 
	for (int i = 1; i <= 2e3; ++i) {
		for (int j = 2; j * j <= i; ++j) {
			if (i % j == 0) goto ntp;
		}
		pid[i] = ++pc;
	ntp:;
	}
	cin >> n; ans = 1e9; bool les10 = 1;
	for (int i = 1; i <= n; ++i)
		cin >> a[i], les10 &= (a[i] <= 10);
	if (n <= 10 && les10) {
		for (int i = 0; i != n; ++i) a[i] = a[i + 1];
		for (int i = 1; i != 1ll << n; ++i) {
			int v = 1;
			for (int j = 0; j != n; ++j)
				if (i >> j & 1) v *= a[j];
			int sv = sqrt(v);
			if (sv * sv == v) ans = min(ans, (long long)__popcnt(i));
		}
		cout << (ans <= n ? ans : -1) << endl;
		return 0;
	}
	memset(d, 0x0f, sizeof d);
	for (int i = 1; i <= n; ++i) {
		int p1 = 0, p2 = 0;
		for (int j = 2; j * j <= a[i]; ++j)
			if (a[i] % j == 0) {
				int c = 0;
				while (a[i] % j == 0) c ^= 1, a[i] /= j;
				if (c) (p1 ? p2 : p1) = j;
			}
		if (a[i] > 1) (p1 ? p2 : p1) = a[i];
		if (!p1 && !p2) return cout << 1 << endl, 0;
		else if (!p2) p2 = 1;
		p1 = pid[p1]; p2 = pid[p2];
		if (d[p1][p2] == 1) ans = 2;
		else d[p1][p2] = d[p2][p1] = 1;
	}
	if (ans == 2) return cout << 2 << endl, 0;
	memcpy(md, d, sizeof d);
	for (int k = 1; k <= pc; ++k) {
		for (int i = 1; i <= pc; ++i)
			for (int j = 1; j <= pc; ++j)
				ans = min(ans, d[i][k] + d[k][j] + md[j][i]);
		for (int i = 1; i <= pc; ++i)
			for (int j = 1; j <= pc; ++j)
				d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
	}
	cout << ans << endl;
}
