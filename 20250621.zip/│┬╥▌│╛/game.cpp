#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 1;
constexpr int mod = 998244353;
int n, m, v[18], ans, c;
#ifndef _MSC_VER
#define __popcnt __builtin_popcount
#endif
inline int qpow(int a, int b, int p = mod) {
	int ret = 1; a %= p;
	for (; b; b >>= 1, a = a * a % p)
		(b & 1) && (ret = ret * a % p);
	return ret;
}
inline void dfs(int d, int p) {
	if (!d) {
		ans = (ans + c * qpow(p, mod - 2)) % mod;
		return;
	}
	for (int i = 1; i <= n; ++i)
		if (v[i]) {
			int np = p * (n - c);
			if (!--v[i]) c++;
			dfs(d - 1, np);
			if (!v[i]++) c--;
		}
}
signed main() {
	if (online)
		freopen("game.in", "r", stdin),
		freopen("game.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1; i <= n; ++i) cin >> v[i];
	dfs(m, 1); cout << ans << endl;
}
