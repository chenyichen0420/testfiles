#include<bits/stdc++.h>
using namespace std;
#define int long long
constexpr bool online = 0;
struct node {
	int l, r, v;
	node(int li = 0, int ri = 0, int vi = 0) :l(li), r(ri), v(vi) {};
	inline bool operator<(const node& r) {
		return v > r.v;
	}
}e[505 * 505]; int ecn;
int n, mod, a[505], f[505], ans;
inline int qpow(int a, int b) {
	int ret = 1;
	for (; b; b >>= 1, a = a * a % mod)
		(b & 1) && (ret = ret * a % mod);
	return ret;
}
inline int find(int p) {
	return f[p] != p ? f[p] = find(f[p]) : p;
}
inline bool merge(int l, int r) {
	l = find(l); r = find(r);
	if (l == r) return 0;
	return f[l] = r, 1;
}
signed main() {
	if (online)
		freopen("choose.in", "r", stdin),
		freopen("choose.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n >> mod;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	for (int i = 1; i <= n; ++i)
		for (int j = i + 1; j <= n; ++j)
			e[++ecn] = node(i, j, (qpow(a[i], a[j]) + qpow(a[j], a[i])) % mod);
	sort(e + 1, e + ecn + 1);
	for (int i = 1; i <= n; ++i) f[i] = i;
	for (int i = 1; i <= ecn; ++i)
		ans += merge(e[i].l, e[i].r) ? e[i].v : 0;
	cout << ans << endl;
}
