#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 0;
int n, m, f[11][200005], ans;
struct node {
	int l, r;
	node(int li = 0, int ri = 0) :l(li), r(ri) {};
}; vector<node>son[11];
inline int find(int d, int p) {
	return f[d][p] != p ? f[d][p] = find(d, f[d][p]) : p;
}
inline bool merge(int d, int l, int r) {
	l = find(d, l); r = find(d, r);
	if (l == r) return 0;
	return f[d][l] = r, 1;
}
signed main() {
	if (online)
		freopen("query.in", "r", stdin),
		freopen("query.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1, l, r, v; i != n; ++i)
		cin >> l >> r >> v, son[v].emplace_back(l, r);
	for (int i = 1; i <= n; ++i) f[0][i] = i;
	for (int i = 1; i <= 10; ++i) {
		memcpy(f[i], f[i - 1], sizeof f[0]);
		for (const node& sp : son[i])
			ans += merge(i, sp.l, sp.r) ? i : 0;
	}
	for (int i = 1, l, r, v; i <= m; ++i) {
		if (cin >> l >> r >> v, merge(v, l, r)) {
			ans += v;
			for (int j = v + 1; v <= 10; ++j)
				if (!merge(j, l, r)) {
					ans -= j; break;
				}
		}
		cout << ans << endl;
	}
}
