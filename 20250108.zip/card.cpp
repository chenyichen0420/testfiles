#include<bits/stdc++.h>
using namespace std;
#ifdef _WIN32
#define getchar_unlocked _getchar_nolock
#define putchar_unlocked _putchar_nolock
#endif
inline int read() {
	int t(0); char c(getchar_unlocked());
	while (c < '0' || c>'9') c = getchar_unlocked();
	while (c >= '0' && c <= '9') t = t * 10 + (c ^ 48), c = getchar_unlocked();
	return t;
}
inline void write(int v) {
	if (v > 9) write(v / 10);
	putchar_unlocked(v % 10 ^ 48);
}
inline void write(int v, char c) {
	write(v); putchar_unlocked(c);
}
int n, m, l[200005], r[200005], lt, rt;
bool cn[200005];
struct rmss {
	struct cz {
		int p; bool ad;
		cz(int pi = 0, int ai = 0) :p(pi), ad(ai) {};
	}; stack<cz>cs; stack<int>ss;
	int f[200005], h[200005];
	inline void init(int siz) {
		for (int i = 1; i <= siz; ++i)
			h[f[i] = i] = 1;
	}
	inline int find(int p) const {
		return f[p] != p ? find(f[p]) : p;
	}
	inline void merge(int l, int r) {
		l = find(l); r = find(r);
		if (l == r) return;
		cs.emplace(l, h[l] == h[r]);
		h[r] += (h[l] == h[r]); f[l] = r;
	}
	inline void canc(cz c) {
		h[f[c.p]] -= c.ad; f[c.p] = c.p;
	}
	inline void prem() { ss.emplace(cs.size()); }
	inline void trem() {
		while (cs.size() != ss.top())
			canc(cs.top()), cs.pop();
		ss.pop();
	}
	inline bool ok(int p) const {
		return find(p) == find(1);
	}
}rms;
struct pode {
	int l, r;
	pode(int li = 0, int ri = 0) :l(li), r(ri) {};
};
struct seg_tree {
	struct node {
		int l, r; vector<pode>v;
	}re[200005 << 2];
	inline void build(int l, int r, int p) {
		re[p].l = l; re[p].r = r;
		if (l == r) return;
		build(l, (l + r >> 1), p << 1);
		build((l + r >> 1) + 1, r, p << 1 | 1);
	}
	inline void ins(int l, int r, pode v, int p) {
		if (re[p].l >= l && re[p].r <= r)
			return void(re[p].v.emplace_back(v));
		if (l <= re[p << 1].r) ins(l, r, v, p << 1);
		if (r > re[p << 1].r) ins(l, r, v, p << 1 | 1);
	}
	inline void solve(int p) {
		rms.prem();
		for (pode& a : re[p].v) {
			rms.merge(a.l, a.r);
			cn[a.l] |= rms.ok(a.l);
			cn[a.r] |= rms.ok(a.r);
		}
		if (re[p].l != re[p].r)
			solve(p << 1), solve(p << 1 | 1);
		rms.trem();
	}
}sgt;
inline void merge(int a, int b) {
	lt = max(l[a], l[b]); rt = min(r[a], r[b]);
}
signed main() {
	ios::sync_with_stdio(0); n = read(); m = read();
	for (int i = 1; i <= n; ++i) l[i] = read(), r[i] = read();
	sgt.build(1, 5, 1); rms.init(n);
	for (int i = 1, a, b; i <= m; ++i) {
		a = read(), b = read(); merge(a, b);
		if (lt <= rt) sgt.ins(lt, rt, pode(a, b), 1);
	}
	cn[1] = 1; sgt.solve(1);
	for (int i = 1; i <= n; ++i)
		if (cn[i]) write(i, ' ');
}
//˽��è�Ǥ�
//2-250; 4-500
