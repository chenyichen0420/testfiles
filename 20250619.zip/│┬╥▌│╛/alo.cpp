#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 0;
constexpr int vr = (1ll << 30) - 1;
struct zotrie {
	struct node { int s[2], c; }re[100005 * 32]; int cc;
	inline void ins(int v, int d, int c, int lp, int& np) {
		re[np = ++cc] = re[lp]; re[np].c += c; if (d < 0) return;
		ins(v, d - 1, c, re[lp].s[v >> d & 1], re[np].s[v >> d & 1]);
	}
	inline int que(int v, int d, int p) {
		if (d == -1) return 0; int t = (v >> d & 1) ^ 1;
		if (!re[re[p].s[t]].c) return que(v, d - 1, re[p].s[t ^ 1]);
		return que(v, d - 1, re[p].s[t]) | (1ll << d);
	}
}rie;
vector<pair<int, int>>ps; vector<pair<int, int>>::iterator it;
int n, a[50005], lp[50005], rp[50005], rt[50005], ans;
vector<pair<int, int>>cg[50005]; int s[50005], ss;
signed main() {
	if (online)
		freopen("alo.in", "r", stdin),
		freopen("alo.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n; a[0] = a[n + 1] = 1e9 + 7;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	for (int i = 1; i <= n; ++i) {
		pair<int, int>v = make_pair(a[i], i);
		int l = 0, r = ps.size() - 1, mid;
		while (l < r) {
			mid = l + r + 1 >> 1;
			if (ps[mid].first > v.first) r = mid - 1;
			else l = mid;
		}
		if (l != ps.size() && ps[l].first < v.first)l++;
		it = ps.emplace(ps.begin() + l, v);
		if (++it == ps.end()) lp[i] = i;
		else if (++it == ps.end()) lp[i] = 1;
		else {
			lp[i] = it->second + 1; it--;
			lp[i] = min(lp[i], it->second + 1);
		}
	}
	ps.clear();
	for (int i = n; i >= 1; --i) {
		pair<int, int>v = make_pair(a[i], i);
		int l = 0, r = ps.size() - 1, mid;
		while (l < r) {
			mid = l + r + 1 >> 1;
			if (ps[mid].first > v.first) r = mid - 1;
			else l = mid;
		}
		if (l != ps.size() && ps[l].first < v.first)l++;
		it = ps.emplace(ps.begin() + l, v);
		if (++it == ps.end()) rp[i] = i + 1;
		else if (++it == ps.end()) rp[i] = n + 1;
		else {
			rp[i] = it->second; it--;
			rp[i] = max(rp[i], it->second);
		}
	}
	for (int i = 1; i <= n; ++i)
		cg[lp[i]].emplace_back(make_pair(a[i], 1)),
		cg[rp[i]].emplace_back(make_pair(a[i], -1));
	for (int i = 0; i <= n + 1; ++i) {
		if (i) rt[i] = rt[i - 1];
		for (const auto& j : cg[i]) 
			rie.ins(j.first, 29, j.second, rt[i], rt[i]);
	}
	for (int i = 1; i <= n; ++i)
		ans = max(ans, rie.que(a[i], 29, rt[i]));
	cout << ans << endl;
}
