#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 0;
struct seg_tree {
	struct node { int ls, rs, v; }re[80005 * 18]; int cc;
	inline void ins(int cp, int cv, int l, int r, int lp, int& np) {
		re[np = ++cc] = re[lp]; re[np].v = cv;
		if (l == r) return; int mid = l + r >> 1;
		if (cp <= mid) ins(cp, cv, l, mid, re[lp].ls, re[np].ls);
		else ins(cp, cv, mid + 1, r, re[lp].rs, re[np].rs);
	}
	inline int que(int l, int r, int k, int p) {
		if (l == r) return re[p].v; int mid = l + r >> 1;
		if (k <= mid) return que(l, mid, k, re[p].ls);
		else return que(mid + 1, r, k, re[p].rs);
	}
}sgt;
int n, c, rt[80005], ln[80005]; char o;
signed main() {
	if (online)
		freopen("travel.in", "r", stdin),
		freopen("travel.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n;
	sgt.ins(0, -1, 0, n, 0, rt[0]);
	for (int i = 1; i <= n; ++i) {
		if (cin >> o, o == 'a')
			cin >> c, ln[i] = ln[i - 1] + 1,
			sgt.ins(ln[i], c, 0, n, rt[i - 1], rt[i]);
		else if (o == 's') rt[i] = rt[i - 1], ln[i] = ln[i - 1] - 1;
		else cin >> c, rt[i] = rt[c - 1], ln[i] = ln[c - 1];
		cout << sgt.que(0, n, ln[i], rt[i]) << endl;
	}
}
