#include<bits/stdc++.h>
using namespace std;
#ifdef _WIN32
#define getchar_unlocked _getchar_nolock
#define putchar_unlocked _putchar_nolock
#endif
inline int read() {
	int r(0); char c(getchar_unlocked()); while (c < '0' || c>'9') c = getchar_unlocked();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar_unlocked();
	return r;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar_unlocked(x % 10 ^ 48);
}
inline void write(int args, char aot) {
	write(args); putchar_unlocked(aot);
}
int n, m, v[100005];
inline bool lescmp(int l, int r) { return l < r; }
inline bool bigcmp(int l, int r) { return l > r; }
int main() {
	ios::sync_with_stdio(0); n = read(); m = read();
	for (int i = 1; i <= n; ++i) v[i] = read();
	for (int i = 1, a, b, c; i <= m; ++i)
		if (a = read(), b = read(), c = read(), a)
			sort(v + b, v + c + 1, bigcmp);
		else sort(v + b, v + c + 1, lescmp);
	write(v[read()]);
}
