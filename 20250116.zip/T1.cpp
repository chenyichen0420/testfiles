#include<bits/stdc++.h>
using namespace std;
#ifdef _WIN32
#define getchar_unlocked _getchar_nolock
#define putchar_unlocked _putchar_nolock
#endif
inline int read() {
	int r(0); char c(getchar_unlocked()); while (c < '0' || c>'9') c = getchar_unlocked();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar_unlocked();
	return r;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar_unlocked(x % 10 ^ 48);
}
inline void write(int args, char aot) {
	write(args); putchar_unlocked(aot);
}
struct node {
	int a, b;
	node(int ai = 0, int bi = 0) :a(ai), b(bi) {};
	friend bool operator<(node l, node r) {
		return l.a != r.a ? l.a < r.a : l.b < r.b;
	}
};
struct pode {
	int a, b; bool t;
	pode(int ai = 0, int bi = 0, bool ti = 0) :
		a(ai), b(bi), t(ti) { }
}tmp;
vector<int>son[30005];
int n, m, f[30005], d[30005], fa[30005], ret;
set<node>v; stack<pode>q; stack<int>ans;
inline void erase(int a, int b) {
	v.count(node(a, b)) ? v.erase(node(a, b)) : v.erase(node(b, a));
}
inline int find(int p) {
	return f[p] != p ? f[p] = find(f[p]) : p;
}
inline bool merge(int l, int r) {
	l = find(l); r = find(r);
	return (f[l] = r, l == r);
}
inline int que(int l, int r) {
	l = find(l); r = find(r); ret = 0;
	while (l != r) {
		if (d[l] > d[r]) l = find(fa[l]);
		else r = find(fa[r]); ret++;
	}
	return ret;
}
inline void add(int l, int r) {
	l = find(l); r = find(r);
	while (l != r)
		if (d[l] < d[r]) f[r] = l, r = find(fa[r]);
		else f[l] = r, l = find(fa[l]);
}
inline void dfs(int p, int fc) {
	fa[p] = fc; d[p] = d[fc] + 1; f[p] = p;
	for (int sp : son[p]) if (sp != fc) dfs(sp, p);
}
int main() {
	ios::sync_with_stdio(0); n = read(); m = read();
	for (int i = 1, a, b; i <= m; ++i)
		a=read(),b=read(), v.emplace(node(a, b)), v.emplace(node(b, a));
	for (int op, a, b;;)
		if ((op = read()) == -1) break;
		else if (op) q.emplace(read(), read(), 1);
		else erase(a = read(), b = read()), q.emplace(a, b, 0);
	for (int i = 1; i <= n; ++i) f[i] = i;
	for (node ad : v)
		if (merge(ad.a, ad.b))
			q.emplace(ad.a, ad.b, 0);
		else
			son[ad.a].emplace_back(ad.b),
			son[ad.b].emplace_back(ad.a);
	dfs(1, 0);
	while (q.size()) {
		tmp = q.top(), q.pop();
		if (tmp.t) ans.emplace(que(tmp.a, tmp.b));
		else add(tmp.a, tmp.b);
	}
	while (ans.size()) write(ans.top(), '\n'), ans.pop();
}
