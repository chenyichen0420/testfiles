#include<bits/stdc++.h>
using namespace std;
#ifdef _WIN32
#define getchar_unlocked _getchar_nolock
#define putchar_unlocked _putchar_nolock
#endif
inline int read() {
	int r(0); char c(getchar_unlocked()); while (c < '0' || c>'9') c = getchar_unlocked();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar_unlocked();
	return r;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar_unlocked(x % 10 ^ 48);
}
inline void write(int args, char aot) {
	write(args); putchar_unlocked(aot);
}
int n, m, f[200005], d[200005], v[200005], ret, at;
vector<int>son[200005];
inline void dfs(int p) {
	d[p] = d[f[p]] + 1;
	for (int sp : son[p]) dfs(sp);
}
inline void que(int l, int r, int t) {
	ret = at = 0;
	while (d[l] < d[r])
		ret += v[r] < t,
		at++, r = f[r];
	while (d[r] < d[l])
		ret += v[l] < t,
		at++, l = f[l];
	while (l != r)
		ret += v[r] < t,
		at++, r = f[r],
		ret += v[l] < t,
		at++, l = f[l];
	write(at + 1, ' '); 
	write(ret + (v[l] < t), '\n');
}
int main() {
	ios::sync_with_stdio(0); n = read();
	memset(v, 0x3f, sizeof v);
	for (int i = 1; i <= n; ++i)
		son[f[i] = read()].emplace_back(i);
	dfs(1); m = read();
	for (int i = 1, a, b, c, d; i <= m; ++i)
		if ((a = read()) & 1)
			b = read(), c = read(), d = read(), que(b, c, i - d);
		else v[read()] = i;
}
