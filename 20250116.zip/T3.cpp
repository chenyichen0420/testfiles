#include<bits/stdc++.h>
using namespace std;
#ifdef _WIN32
#define getchar_unlocked _getchar_nolock
#define putchar_unlocked _putchar_nolock
#endif
inline int read() {
	int r(0); char c(getchar_unlocked()); while (c < '0' || c>'9') c = getchar_unlocked();
	while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = getchar_unlocked();
	return r;
}
inline void write(int x) {
	if (x > 9) write(x / 10);
	putchar_unlocked(x % 10 ^ 48);
}
inline void write(int args, char aot) {
	write(args); putchar_unlocked(aot);
}
int n, x[100005], y[100005];
vector<int>son[100005];
long double ans[100005];
int dp[100005], md;
long long w[100005];
int main() {
	ios::sync_with_stdio(0); n = read();
	for (int i = 1; i <= n; ++i) x[i] = read(), y[i] = read();
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j < i; ++j)
			if (x[j] >= x[i] && y[j] >= y[i])
				if (dp[j] > dp[i])
					dp[i] = dp[j], son[i].clear(),
					son[i].emplace_back(j), w[i] = w[j];
				else if (dp[j] == dp[i])
					son[i].emplace_back(j), w[i] += w[j];
		if (!dp[i]) w[i] = 1; dp[i]++;
	}
	ans[n + 1] = 1.0;
	for (int i = 1; i <= n; ++i)
		if (dp[i] > md)
			md = dp[i], son[n + 1].clear(),
			son[n + 1].emplace_back(i), w[n + 1] = w[i];
		else if (dp[i] == md)
			son[n + 1].emplace_back(i),
			w[n + 1] += w[i];
	printf("%d\n", md);
	for (int i = n + 1; i >= 1; i--)
		for (int sp : son[i])
			ans[sp] += ans[i] * w[sp] / w[i];
	for (int i = 1; i <= n; ++i)
		printf("%.5Lf ", ans[i]);
}
