#include<bits/stdc++.h>
using namespace std;
int main(int argc,char*args[]){
	if(argc==1){
		ios::sync_with_stdio(0);
		freopen("T4.in","w",stdout);
		cout<<"30000\n";
		for(int i=1;i<=3e4;++i)
		cout<<i-1<<" "; cout<<endl;
		cout<<"30000\n";
		cout<<"2 1\n";
		for(int i=1;i<3e4;++i)
			cout<<"1 1 30000 0\n";
			return 0;
	}
	string t=args[1]; string cmd;
	cmd=R"(E:\20250116\)"+t+".exe < "+R"(E:\20250116\)"+t+".in > "+R"(E:\20250116\)"+t+".out";
	time_t st=clock();
	for(int i=1;i<=10;++i) system(cmd.c_str());
	cout<<(clock()-st)*0.1<<"ms\n";
	cmd=(string)"fc "+R"(E:\20250116\)"+t+".ans "+R"(E:\20250116\)"+t+".out /W";
	system(cmd.c_str());
}
