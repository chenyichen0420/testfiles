#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
vector<int>son[100005];
int n, m, v[100005], f[100005], mi[100005];
int rt, l, r; bool use, cn[100005]; char op;
inline void tmin(int& l, const int& r) {
	(l > r) && (l = r);
}
inline void dfs(int p, int fa) {
	f[p] = fa; mi[p] = v[p]; cn[p] = 1;
	for (int sp : son[p])
		if (sp != fa) dfs(sp, p), tmin(mi[p], mi[sp]);
}
inline int get(int p) {
	if (cn[p]) return mi[p]; mi[p] = v[p];
	for (int sp : son[p])
		if (sp != f[p]) tmin(mi[p], get(sp));
	cn[p] = 1; return mi[p];
}
inline void ref(int p) {
	if (f[p] && cn[p]) ref(f[p]); cn[p] = 0;
}
int main() {
	if (online)
		freopen("tree.in", "r", stdin),
		freopen("tree.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1; i <= n; ++i)
		if (cin >> f[i] >> v[i], !f[i]) rt = i;
		else
			son[f[i]].emplace_back(i),
			son[i].emplace_back(f[i]);
	while (m--)
		if (cin >> op, op == 'V') {
			cin >> l >> r, v[l] = r;
			if (use) ref(l);
		}
		else if (op == 'E') use = 0, cin >> rt;
		else {
			if (!use) dfs(rt, 0); use = 1; cin >> l;
			cout << get(l) << endl;
		}
}
