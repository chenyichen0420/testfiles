#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
struct node {
	int p, v;
	node(int pi = 0, int vi = 0) :p(pi), v(vi) {};
}; vector<node>son[100005];
int n, m, dep[100005], fa[100005], ans;
unordered_map<int, int>ps[100005];
inline void dfs(int p, int f) {
	fa[p] = f; dep[p] = dep[f] + 1;
	for (node sp : son[p])
		if (sp.p != f) dfs(sp.p, p);
}
int main() {
	if (online)
		freopen("colour.in", "r", stdin),
		freopen("colour.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n;
	for (int i = 1, a, b; i < n; ++i)
		cin >> a >> b,
		son[a].emplace_back(node(b, 0)),
		son[b].emplace_back(node(a, 0));
	for (int i = 1; i <= n; ++i)
		for (int j = 0; j != son[i].size(); ++j)
			ps[i][son[i][j].p] = j;
	cin >> m; dfs(1, 0);
	for (int i = 1, t, l, r; i <= m; ++i)
		if (cin >> t >> l >> r, t == 1) {
			if (dep[l] < dep[r]) swap(l, r);
			while (dep[l] != dep[r])
				son[l][ps[l][fa[l]]].v ^= 1,
				son[fa[l]][ps[fa[l]][l]].v ^= 1,
				l = fa[l];
			while (l != r)
				son[l][ps[l][fa[l]]].v ^= 1,
				son[fa[l]][ps[fa[l]][l]].v ^= 1,
				son[r][ps[r][fa[r]]].v ^= 1,
				son[fa[r]][ps[fa[r]][r]].v ^= 1,
				l = fa[l], r = fa[r];
		}
		else if (t == 2) {
			if (dep[l] < dep[r]) swap(l, r);
			while (dep[l] != dep[r]) {
				for (node& sp : son[l])
					sp.v ^= 1, son[sp.p][ps[sp.p][l]].v ^= 1;
				l = fa[l];
			}
			while (l != r) {
				for (node& sp : son[l])
					sp.v ^= 1, son[sp.p][ps[sp.p][l]].v ^= 1;
				for (node& sp : son[r])
					sp.v ^= 1, son[sp.p][ps[sp.p][r]].v ^= 1;
				l = fa[l], r = fa[r];
			}
			for (node& sp : son[l])
				sp.v ^= 1, son[sp.p][ps[sp.p][l]].v ^= 1;
		}
		else {
			if (dep[l] < dep[r]) swap(l, r); ans = 0;
			while (dep[l] != dep[r])
				ans += son[l][ps[l][fa[l]]].v,
				l = fa[l];
			while (l != r)
				ans += son[l][ps[l][fa[l]]].v,
				ans += son[r][ps[r][fa[r]]].v,
				l = fa[l], r = fa[r];
			cout << ans << endl;
		}
}
/*
10
5 9
7 5
6 5
5 8
10 5
3 5
2 9
7 4
6 1
10
2 10 5
1 4 9
3 1 1
3 7 8
3 9 10
1 7 9
3 4 8
1 4 1
2 10 2
2 1 1

*/
