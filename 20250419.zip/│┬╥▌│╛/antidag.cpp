#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
struct node {
	int p, v;
	node(int pi = 0, int vi = 0) :p(pi), v(vi) {};
}; int n, m, rd[100005], tp; queue<int>q;
vector<node>son[100005]; int l, r, mid;
inline bool check(int v) {
	memset(rd, 0, sizeof rd);
	for (int i = 0; i <= n; ++i)
		for (node sp : son[i])
			if (sp.v > v) rd[sp.p]++;
	q.emplace(0);
	while (q.size()) {
		tp = q.front(); q.pop();
		for(node sp:son[tp])
			if (sp.v > v)
				if (!--rd[sp.p])
					q.emplace(sp.p);
	}
	for (int i = 1; i <= n; ++i)
		if (rd[i]) return 0;
	return 1;
}
int main() {
	if (online)
		freopen("antidag.in", "r", stdin),
		freopen("antidag.out", "w", stdout);
	ios::sync_with_stdio(0);
	cin >> n >> m;
	for (int i = 1, a, b, c; i <= m; ++i)
		cin >> a >> b >> c, son[a].emplace_back(node(b, c));
	for (int i = 1; i <= n; ++i) son[0].emplace_back(node(i, 0x3f3f3f3f));
	l = 0, r = 1e9;
	while (l < r)
		if (!check(mid = l + r >> 1)) l = mid + 1;
		else r = mid;
	cout << l << endl;
}
