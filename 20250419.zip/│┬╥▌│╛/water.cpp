#include<bits/stdc++.h>
using namespace std;
constexpr bool online = 1;
int n, m, a[200005], ans, ank, nxp[200005];
inline int cnt(int v) {
	int ret = 0;
	while (v)ret += v & 1, v >>= 1;
	return ret;
}
inline bool check(int cl) {
	if (cnt(cl) > m) return 0;
	int ptr = n, ret = 0, v = 0;
	while (cl & (1ll << ptr - 1)) ptr--;
	v = a[ptr] >> 1;
	while (ptr) {
		while (a[ptr] > v || (cl & (1ll << ptr - 1))) ptr--;
		ret++; v = a[ptr] >> 1;
	}
	if (ret < ans) return ans = ret, 1;
	if (ret > ans) return 0;
	return cnt(cl) < ank;
}
int main() {
	if (online)
		freopen("water.in", "r", stdin),
		freopen("water.out", "w", stdout);
	ios::sync_with_stdio(0); cin >> n >> m;
	for (int i = 1; i <= n; ++i) cin >> a[i];
	sort(a + 1, a + n + 1); ans = 0x3f3f3f3f;
	if (n == m) {
		cout << 0 << " " << n << endl;
		return 0;
	}
	if (n <= 20&&0) {
		for (int i = 0; i < 1ll << n; ++i)
			if (check(i)) ank = cnt(i);
		cout << ans << " " << ank << endl;
		return 0;
	}
	int ptr = n, ret = 0, v = 0;
	for (int i = n; i >= 1; --i) {
		while (a[ptr - 1] > (a[i] >> 1)) ptr--;
		nxp[i] = ptr;
	}
	ptr = n; v = ret = 0; int pv = 0;
	for (int ps = n; ps >= 1;)
		if (nxp[ps] - nxp[ps - 1] > 1 && v < m)
			v++, ps = ps - 1;
		else ps = nxp[ps] - 1;
	if (v != m) {
		pv = v;
		for (int ps = n; ps >= 1;)
			if (nxp[ps] - nxp[ps - 1] == 1 && v < m)
				v++, ps = ps - 1;
			else if (nxp[ps] - nxp[ps - 1] > 1)
				ps = ps - 1;
			else ps = nxp[ps] - 1;
		if (v != m) {
			for (int ps = n; ps >= 1;)
				if (nxp[ps] - nxp[ps - 1] == 0 && v < m)
					v++, ps = ps - 1;
				else if (nxp[ps] - nxp[ps - 1] >= 1)
					ps = ps - 1;
				else ret++, ps = nxp[ps] - 1;
		}
		else {
			v = pv;
			for (int ps = n; ps >= 1;)
				if (nxp[ps] - nxp[ps - 1] >= 1 && v < m)
					v++, ps = ps - 1;
				else ps = nxp[ps] - 1, ret++;
		}
	}
	else {
		v = pv;
		for (int ps = n; ps >= 1;)
			if (nxp[ps] - nxp[ps - 1] > 1 && v < m)
				v++, ps = ps - 1;
			else ps = nxp[ps] - 1, ret++;
	}
	cout << ret << " " << v << endl;
}
