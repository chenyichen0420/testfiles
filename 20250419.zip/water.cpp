#include<bits/stdc++.h>
using namespace std;
//#define int long long
//#define sipt //signed-input
//#define sopt //signed-output
bool acc[128];
struct IO {
#define mxsz (1 << 20)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp;
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
	inline char getc() {
		char c; while (!acc[c = gc()]); return c;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(long long x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(long long x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
constexpr bool online = 1, brf_on = 1;
int n, m, a[200005], ans, lm;
namespace brf {
	bool hs[15];
	inline void solve(int cn) {
		int ret = 0, i = n;
		while (hs[i]) i--;
		while (i) {
			int vr = a[i] / 2 + 1;
			while (a[i] >= vr || hs[i]) i--;
			ret++;
		}
		if (ret < ans) ans = ret, lm = cn;
		else if (ret == ans) lm = min(lm, cn);
	}
	inline void dfs(int p, int c) {
		if (c > m) return;
		if (p == n + 1 || c == m) return solve(c);
		dfs(p + 1, c);
		hs[p] = 1;
		dfs(p + 1, c + 1);
		hs[p] = 0;
	}
}
struct node {
	int l, r;
	node(int li = 0, int ri = 0) :l(li), r(ri) {}
	friend bool operator<(const node& l, const node& r) {
		return l.r != r.r ? l.r > r.r : l.l < r.l;
	}
}v[200005]; priority_queue<node>pq;
signed main() {
	if (online)
		freopen("water.in", "r", stdin),
		freopen("water.out", "w", stdout);
	ios::sync_with_stdio(0); n = io.read(); m = io.read();
	for (int i = 1;i <= n;++i) a[i] = io.read();
	sort(a + 1, a + n + 1);
	if (m == 0) {
		for (int i = n;i;) {
			int vr = a[i] / 2 + 1;
			while (a[i] >= vr) i--;
			ans++;
		}
		cout << ans << " 0\n";
		return 0;
	}
	if (m == n) {
		cout << "0 " << m << endl;
		return 0;
	}
	if (n <= 10 && brf_on) {
		using namespace brf; ans = 114514;
		dfs(1, 0);
		cout << ans << " " << lm << endl;
		return 0;
	}
	/*
	��֪���ǲ������⣬�Ȼ������һ�¡�
	�������Ҷ˵�����������ҽ����Ѷ�������н����Ĳ���ȫ��ɾ����Ż���١�
	�ǲ��ǿ����ö���ά��һ��
	���⣬С������һ����ȷ��
	*/
	for (int i = n;i;) {
		int vr = a[i] / 2 + 1;
		while (a[i] >= vr) i--;
		ans++;
	}
	for (int i = 1;i <= n;++i)
		v[i].l = upper_bound(a + 1, a + n + 1, a[i] / 2) - a,
		v[i].r = i;
	sort(v + 1, v + n + 1); reverse(v + 1, v + n + 1);
	for (int i = n;i;i--) {
		int sp = i, lp = v[i].l;
		while (v[i - 1].r >= lp) i--;
		pq.emplace(node(sp, sp - i + 1));
	}
	while (pq.size() && m >= pq.top().r)
		m -= pq.top().r, ans--, lm += pq.top().r, pq.pop();
	cout << max(ans, 0) << " " << lm << endl;
}
