#include<bits/stdc++.h>
using namespace std;
//#define int long long
//#define sipt //signed-input
//#define sopt //signed-output
bool acc[128];
struct IO {
#define mxsz (1 << 20)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp;
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
	inline char getc() {
		char c; while (!acc[c = gc()]); return c;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(long long x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(long long x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
constexpr bool online = 1;
int n, m; vector<int>son[100005];
int l[100005], r[100005], ps[100005], f[100005], d[100005];
bool col[100005];
inline void dfs(int p, int f) {
	::f[p] = f; d[p] = d[f] + 1;
	for (int sp : son[p]) if (sp != f) dfs(sp, p);
}
inline void flip(int l, int r) {
	if (d[l] < d[r]) swap(l, r);
	while (d[l] > d[r])
		col[l] ^= 1, l = f[l];
	while (l != r)
		col[l] ^= 1, l = f[l],
		col[r] ^= 1, r = f[r];
}
inline void flie(int l, int r) {
	if (d[l] < d[r]) swap(l, r);
	int ll = 0, rr = 0;
	while (d[l] > d[r]) {
		for (int sp : son[l])
			if (sp != ll && sp != f[l])
				col[sp] ^= 1;
		ll = l; l = f[l];
	}
	while (l != r) {
		for (int sp : son[l])
			if (sp != ll && sp != f[l])
				col[sp] ^= 1;
		ll = l; l = f[l];
		for (int sp : son[r])
			if (sp != rr && sp != f[r])
				col[sp] ^= 1;
		rr = r; r = f[r];
	}
	for (int sp : son[l])
		if (sp != ll && sp != rr)
			if (sp != f[l]) col[sp] ^= 1;
			else col[l] ^= 1;
}
inline int cnt(int l, int r) {
	if (d[l] < d[r]) swap(l, r);
	int ret = 0;
	while (d[l] > d[r]) ret += col[l], l = f[l];
	while (l != r)
		ret += col[l], l = f[l],
		ret += col[r], r = f[r];
	return ret;
}
signed main() {
	if (online)
		freopen("colour.in", "r", stdin),
		freopen("colour.out", "w", stdout);
	ios::sync_with_stdio(0); n = io.read();
	for (int i = 1;i != n;++i)
		l[i] = io.read(), r[i] = io.read(),
		son[l[i]].emplace_back(r[i]),
		son[r[i]].emplace_back(l[i]);
	m = io.read(); dfs(1, 0);
	for (int i = 1, o, l, r;i <= m;++i)
		if (o = io.read(), l = io.read(), r = io.read(), o == 1) flip(l, r);
		else if (o == 2) flie(l, r);
		else io.write(cnt(l, r), '\n');
}
