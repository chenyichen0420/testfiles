#include<bits/stdc++.h>
using namespace std;
//#define int long long
//#define sipt //signed-input
//#define sopt //signed-output
struct IO {
#define mxsz (1 << 20)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp;
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(long long x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(long long x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
constexpr bool online = 1;
struct node { int l, r, v; }tmp;
vector<node>e; vector<int>son[100005];
int n, m, l, r, mid, rd[100005]; queue<int>q;
inline bool check(int v) {
	for (int i = 1;i <= n;++i) son[i].clear();
	memset(rd, 0, sizeof rd);
	for (const node& k : e)
		if (k.v > v) rd[k.r]++,
			son[k.l].emplace_back(k.r);
	while (q.size()) q.pop();
	for (int i = 1;i <= n;++i)
		if (!rd[i]) q.emplace(i);
	while (q.size()) {
		int tp = q.front(); q.pop();
		for (int sp : son[tp])
			if (!--rd[sp])
				q.emplace(sp);
	}
	for (int i = 1;i <= n;++i)
		if (rd[i]) return 0;
	return 1;
}
signed main() {
	if (online)
		freopen("antidag.in", "r", stdin),
		freopen("antidag.out", "w", stdout);
	ios::sync_with_stdio(0);
	n = io.read(); m = io.read();
	for (int i = 1;i <= m;++i)
		tmp.l = io.read(), tmp.r = io.read(), tmp.v = io.read(),
		e.emplace_back(tmp);
	l = 0;r = 1e9;
	while (l != r)
		if (check(mid = l + r >> 1)) r = mid;
		else l = mid + 1;
	cout << l << endl;
}
