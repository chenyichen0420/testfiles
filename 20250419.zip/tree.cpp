#include<bits/stdc++.h>
using namespace std;
//#define int long long
//#define sipt //signed-input
//#define sopt //signed-output
bool acc[128];
struct IO {
#define mxsz (1 << 20)
	char buf[mxsz], * p1, * p2;
	char pbuf[mxsz], * pp;
	IO() : p1(buf), p2(buf), pp(pbuf) {}
	~IO() { fwrite(pbuf, 1, pp - pbuf, stdout); }
	inline char gc() {
		if (p1 == p2) p2 = (p1 = buf) + fread(buf, 1, mxsz, stdin);
		return p1 == p2 ? ' ' : *p1++;
	}
	inline char getc() {
		char c; while (!acc[c = gc()]); return c;
	}
#ifndef sipt
	inline int read() {
		int r = 0; char c = gc(); while (c < '0' || c>'9') c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return r;
	}
#else
	inline int read() {
		int r = 0; char c = gc(); bool rev = 0;
		while (c < '0' || c>'9') rev |= (c == '-'), c = gc();
		while (c >= '0' && c <= '9') r = r * 10 + (c ^ 48), c = gc();
		return rev ? ~r + 1 : r;
	}
#endif
	inline void push(const char& c) {
		if (pp - pbuf == mxsz) fwrite(pbuf, 1, mxsz, stdout), pp = pbuf;
		*pp++ = c;
	}
	inline void write(long long x) {
		static char sta[22]; int top = 0;
		do sta[top++] = x % 10, x /= 10; while (x);
		while (top) push(sta[--top] ^ 48);
	}
	inline void write(long long x, char opc) {
#ifdef sopt
		if (x < 0) push('-'), x = ~x + 1;
#endif
		write(x), push(opc);
	}
} io;
constexpr bool online = 1; vector<int>son[100005]; char o; int root;
int n, m, v[100005], d[100005], lid[100005], rid[100005], idx, fa[100005][18];
inline void tmin(int& l, const int r) { (l > r) && (l = r); }
struct seg_tree {
	struct node { int l, r, v; }re[100005 << 2];
	inline void build(int l, int r, int p) {
		re[p].l = l; re[p].r = r; if (l == r) return;
		build((l + r >> 1) + 1, r, p << 1 | 1);
		build(l, (l + r >> 1), p << 1);
	}
	inline void ins(int cp, int cv, int p) {
		if (re[p].l == re[p].r) return void(re[p].v = cv);
		if (cp <= re[p << 1].r) ins(cp, cv, p << 1);
		else  ins(cp, cv, p << 1 | 1);
		re[p].v = min(re[p << 1].v, re[p << 1 | 1].v);
	}
	inline int que(int l, int r, int p) {
		if (re[p].l >= l && re[p].r <= r) return re[p].v;
		int ret = 2e9;
		if (l <= re[p << 1].r) tmin(ret, que(l, r, p << 1));
		if (r > re[p << 1].r) tmin(ret, que(l, r, p << 1 | 1));
		return ret;
	}
}sgt;
inline void dfs(int p) {
	d[p] = d[fa[p][0]] + 1; lid[p] = ++idx;
	for (int i = 1;i <= 17;++i)
		fa[p][i] = fa[fa[p][i - 1]][i - 1];
	for (int sp : son[p]) dfs(sp);
	rid[p] = idx;
}
inline int que(int p) {
	if (p == root) {
//		cerr << "TY0\n";
		return sgt.que(1, n, 1);
	}//�Ҿ��Ǹ�
	//��һ�����ж� root �ڲ���������
	if (lid[root] > lid[p] && lid[root] <= rid[p]) {
		//��������
		int jmp = d[root] - d[p] - 1, tr = root;
		for (int i = 17;i >= 0;i--)
			if (jmp >> i & 1) tr = fa[tr][i];
		// ������Ӧ�������� lid[tr]~rid[tr]
//		cerr << "TY1 " << tr << " " << lid[tr] << " " << rid[tr] << endl;
		int ret = 2e9;
		if (lid[tr] != 1) tmin(ret, sgt.que(1, lid[tr] - 1, 1));
		if (rid[tr] != n) tmin(ret, sgt.que(rid[tr] + 1, n, 1));
		return ret;
	}
	else {
//		cerr << "TY2" << " " << lid[p] << " " << rid[p] << endl;
		return sgt.que(lid[p], rid[p], 1);
	}
	//���������ڣ��ô���~~~
}
signed main() {
	if (online)
		freopen("tree.in", "r", stdin),
		freopen("tree.out", "w", stdout);
	ios::sync_with_stdio(0);
	/*
	�Ȱ���ŷ�������½�����
	ÿһ��������ԭ����Ӧ������һ���������������������䡣
	�������ࣺ��������ԭ����������
	���ںܺ��жϡ���������д�ˡ�
	�ڵĻ�Ҫ�����ҳ����ĸ�����������һ�¡�
	*/
	n = io.read(); m = io.read();
	for (int i = 1;i <= n;++i)
		fa[i][0] = io.read(), v[i] = io.read(),
		son[fa[i][0]].emplace_back(i);
	dfs(1); sgt.build(root = 1, n, 1);
	for (int i = 1;i <= n;++i)
		sgt.ins(lid[i], v[i], 1);
	acc['V'] = acc['E'] = acc['Q'] = 1;
	for (int i = 1, l;i <= m;++i)
		if (o = io.getc(), l = io.read(), o == 'V')
			sgt.ins(lid[l], io.read(), 1);
		else if (o == 'E') root = l;
		else io.write(que(l), '\n');
}
