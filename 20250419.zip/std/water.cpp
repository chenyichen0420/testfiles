﻿#include<bits/stdc++.h>
using namespace std;
const int N = 2e5 + 10;
int n, k, a[N];
int dp[N][40], mx[N];//移走i个,答案为j
int find(int x) { 
	return upper_bound(a + 1, a + n + 1, a[x] / 2) - a; 
}
int main() {
freopen("water.in","r",stdin);
	freopen("water.out","w",stdout);
	scanf("%d%d", &n, &k);
	for (int i = 1; i <= n; i++)
		scanf("%d", &a[i]);
	sort(a + 1, a + n + 1);
	for (int i = 0; i <= k; i++)dp[i][0] = n - i + 1;
	for (int j = 1; j <= 40; j++)
	{
		for (int i = 0; i <= k; i++)
			if (dp[i][j - 1] == 1) { 
				printf("%d %d", j - 1, i); 
				return 0; 
			}
		dp[0][j] = find(dp[0][j - 1] - 1);
		for (int i = 1; i <= k; i++)
			dp[i][j] = min(find(dp[i][j - 1] - 1), dp[i - 1][j] - 1);
	}
	return 0;
}