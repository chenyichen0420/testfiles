#include<bits/stdc++.h>
const int N = 1e5 + 5;
int x[N], y[N], w[N], d[N], P[N], vis[N];
std::vector<int> G[N], V, f;
std::queue<int> q;
int n, m, l, r = 1e9, ans, M;
inline bool check(int p) {
	for (int i = 1; i <= m; i++)
		if (w[i] > p) G[x[i]].push_back(y[i]), d[y[i]]++;
	for (int i = 1; i <= n; i++) if (!d[i]) q.push(i);
	int k = 0; V.clear(); while (!q.empty()) {
		int u = q.front(); q.pop(); P[u] = ++k;
		for (int v : G[u]) if ((--d[v]) == 0) q.push(v);
	}
	for (int i = 1; i <= m; i++)
		if (w[i] <= p && P[x[i]] > P[y[i]]) V.push_back(i);
	for (int i = 1; i <= n; i++) d[i] = 0, G[i].clear(), P[i] = 0;
	return k == n;
}
int main() {
	freopen("antidag.in","r",stdin);
	freopen("antidag.out","w",stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; i++) 
        scanf("%d%d%d", &x[i], &y[i], &w[i]);
	while (l <= r) 
        M = (l + r) >> 1, check(M) ? (r = M - 1, f = V, ans = M) : (l = M + 1);
	printf("%d", ans);
	return 0;
}