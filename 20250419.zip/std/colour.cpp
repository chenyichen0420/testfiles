#include<iostream>
#include<cstdio>
#define N 210000
using namespace std;
int n;
int st[N+1],tot;
struct SEG
{
	int sum[N<<2|1];
	bool tag[N<<2|1];
	void pushup(int p){sum[p]=sum[p<<1]+sum[p<<1|1];}
	void pushdown(int p,int l,int r)
	{
		if(tag[p])
		{
			int mid=(l+r)>>1;
			sum[p<<1]=mid-l+1-sum[p<<1];
			sum[p<<1|1]=r-mid-sum[p<<1|1];
			tag[p<<1]^=1,tag[p<<1|1]^=1;
			tag[p]=false;
		}
	}
	void update(int p,int l,int r,int L,int R)
	{
		if(L<=l&&r<=R)
		{
			sum[p]=r-l+1-sum[p];
			tag[p]^=1;
			return;
		}
		pushdown(p,l,r);
		int mid=(l+r)>>1;
		if(L<=mid)
			update(p<<1,l,mid,L,R);
		if(R>mid)
			update(p<<1|1,mid+1,r,L,R);
		pushup(p);
	}
	int query(int p,int l,int r,int L,int R)
	{
		if(L<=l&&r<=R)
			return sum[p];
		pushdown(p,l,r);
		int mid=(l+r)>>1,res=0;
		if(L<=mid)
			res+=query(p<<1,l,mid,L,R);
		if(R>mid)
			res+=query(p<<1|1,mid+1,r,L,R);
		return res;
	}
};
SEG t1,t2;
struct edge
{
		int to,last;
}e[N<<1|1];
void add(int a,int b)
{
	e[++tot].to=b;
	e[tot].last=st[a];
	st[a]=tot;
}
int siz[N+1],depth[N+1],fa[N+1],son[N+1],top[N+1];
void dfs1(int u,int f)
{
	fa[u]=f,depth[u]=depth[f]+1,siz[u]=1;
	for(int i=st[u];i!=0;i=e[i].last)
	{
		int v=e[i].to;
		if(v==f)
			continue;
		dfs1(v,u);
		siz[u]+=siz[v];
		if(siz[v]>siz[son[u]])
			son[u]=v;
	}
}
int id[N+1],dfn;
void dfs2(int u,int topf)
{
	top[u]=topf,id[u]=++dfn;
	if(!son[u])
		return;
	dfs2(son[u],topf);
	for(int i=st[u];i!=0;i=e[i].last)
	{
		int v=e[i].to;
		if(v==fa[u]||v==son[u])
			continue;
		dfs2(v,v);
	}
}
void update1(int x,int y)
{
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]])
			swap(x,y);
		t1.update(1,1,n,id[top[x]],id[x]);
		x=fa[top[x]];
	}
	if(depth[x]>depth[y])
		swap(x,y);
	if(id[x]!=id[y])
		t1.update(1,1,n,id[x]+1,id[y]);
}
void update2(int x,int y)
{
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]])
			swap(x,y);
		t2.update(1,1,n,id[top[x]],id[x]);
		t1.update(1,1,n,id[top[x]],id[top[x]]);
		if(son[x])
			t1.update(1,1,n,id[son[x]],id[son[x]]);
		x=fa[top[x]];
	}
	if(depth[x]>depth[y])
		swap(x,y);
	t1.update(1,1,n,id[x],id[x]);
	t2.update(1,1,n,id[x],id[y]);
	if(son[y])
		t1.update(1,1,n,id[son[y]],id[son[y]]);
}
int query(int x,int y)
{
	int res=0;
	while(top[x]!=top[y])
	{
		if(depth[top[x]]<depth[top[y]])
			swap(x,y);
		if(top[x]!=x)
			res+=t1.query(1,1,n,id[top[x]]+1,id[x]);
		res+=(t1.query(1,1,n,id[top[x]],id[top[x]])+t2.query(1,1,n,id[fa[top[x]]],id[fa[top[x]]]))&1;
		x=fa[top[x]];
	}
	if(depth[x]>depth[y])
		swap(x,y);
	if(id[x]!=id[y])
		res+=t1.query(1,1,n,id[x]+1,id[y]);
	return res;
}
int main()
{	
freopen("colour.in","r",stdin);
	freopen("colour.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<n;i++)                                        
	{
		int a,b;
		scanf("%d %d",&a,&b);
		add(a,b),add(b,a);
	}
	dfs1(1,0),dfs2(1,1);
	int m;
	scanf("%d",&m);
	for(;m--;)
	{
		int t,a,b;
		scanf("%d %d %d",&t,&a,&b);
		if(t==1)
			update1(a,b);
		else
			if(t==2)
				update2(a,b);
			else
				printf("%d\n",query(a,b));
	}
	return 0;
}